# Admin assign doctor page
# able to assign a doctor to that user in specific date and time

import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
from tkcalendar import Calendar
from tkinter import messagebox
import datetime
from admin.sidebar import Sidebar
from firebase_config import database


# after clicking doctor details, will to assign doctor to an appointment
class AssignDoctorAppointment:
    def __init__(self, app, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')
        self.dc_name = dc_name or self.app.get_shared_data("dc_name")
        self.images = {}
        self.time_buttons = []  # List to store time button instances

        # Create a frame for clinic details
        booking_frame = Frame(self.frame, bg='white')
        booking_frame.pack(side='left', fill='both', expand=True)

        # Clinic name for testing (replace with actual retrieval logic)
        self.clinic_name = self.app.get_shared_data("name")
        clinic_data = self.get_clinic_data(self.clinic_name)
        booking_label = Label(booking_frame, text=f"Assign booking for Dr.{dc_name} in {self.clinic_name}",
                              font=('Helvetica', 18, 'bold'), bg='white')
        booking_label.pack(pady=20)

        # Initialize selected_date and selected_time
        self.selected_date = None
        self.selected_time = None
        self.selected_button_time = None  # Track the currently selected button

        select_date = Label(booking_frame, text="Select date", font=('Helvetica', 14, 'underline'), bg='white')
        select_date.place(x=50, y=80)

        # Embed the calendar directly in the booking_frame
        self.cal = Calendar(booking_frame, selectmode='day', date_pattern='yyyy-mm-dd')
        self.cal.place(x=50, y=120, width=300, height=180)

        # Set the tag color to red for busy dates
        self.cal.tag_config('busy', background='red', foreground='white')

        # Fetch and highlight appointment dates
        appointment_dates = self.fetch_appointment_dates(dc_name)
        self.busy_dates = []
        for date in appointment_dates:
            try:
                year, month, day = map(int, date.split('-'))
                # Highlight the date on the calendar
                self.cal.calevent_create(datetime.date(year, month, day), 'Appointment', 'busy')
                self.busy_dates.append(datetime.date(year, month, day))
            except ValueError as e:
                print(f"Error parsing date {date}: {e}")

        # Retrieve opening and closing times from clinic_data or use default values
        self.opening_time = clinic_data.get('open_time', '00:00')
        self.closing_time = clinic_data.get('close_time', '23:00')

        # Convert open_time and close_time to datetime objects for easier manipulation
        fmt = "%H:%M"  # Format for parsing times like "13:00"
        open_datetime = datetime.datetime.strptime(self.opening_time, fmt)
        close_datetime = datetime.datetime.strptime(self.closing_time, fmt)

        # Initialize an empty array to store current_time values
        current_time = []

        # Start generating times from open_time to close_time with 1-hour intervals
        current = open_datetime  # Use datetime objects for accurate time comparison

        while current < close_datetime:
            current_time.append(current.strftime(fmt))  # Append formatted time string
            current += datetime.timedelta(hours=1)  # Increment current time by 1 hour

        select_time = Label(booking_frame, text="Select time", font=('Helvetica', 14, 'underline'), bg='white')
        select_time.place(x=400, y=80)

        # Calculate current datetime
        current_datetime = datetime.datetime.now()

        # Calculate tomorrow's date
        tomorrow_date = datetime.date.today() + datetime.timedelta(days=1)

        # Determine whether the selected date is today
        def is_today(selected_date):
            return selected_date == datetime.date.today()

        def get_future_times(selected_date):
            # Initialize an empty array to store future times
            future_times = []

            # Start generating times from the clinic's opening time to closing time with 1-hour intervals
            current = open_datetime  # Start from opening time

            while current <= close_datetime:
                future_times.append(current.strftime(fmt))  # Append formatted time string
                current += datetime.timedelta(hours=1)  # Increment current time by 1 hour

            # If selected date is today, filter out times before the current time
            if is_today(selected_date):
                current_time = datetime.datetime.now().time()
                current_hour = current_time.hour
                current_minute = current_time.minute

                # Filter out times before the current time
                future_times = [time_str for time_str in future_times
                                if int(time_str[:2]) > current_hour or
                                   (int(time_str[:2]) == current_hour and int(time_str[3:]) > current_minute)]

            return future_times

        # Handle calendar date selection event
        def on_date_select():
            selected_date_str = self.cal.get_date()

            try:
                self.selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
            except ValueError:
                messagebox.showerror("Error", "Invalid date format. Please select a valid date.")
                return

            update_time_buttons()

        # Bind calendar selection event to on_date_select function
        self.cal.bind("<<CalendarSelected>>", lambda e: on_date_select())

        # Function to update time buttons based on selected date
        def update_time_buttons():
            # Clear existing time buttons
            for button in self.time_buttons:
                button.destroy()

            # Get future times based on the selected date
            future_times = get_future_times(self.selected_date)

            # Create buttons dynamically based on future_times
            button_positions = [
                (400, 120), (480, 120), (560, 120), (640, 120),
                (400, 170), (480, 170), (560, 170), (640, 170),
                (400, 220), (480, 220), (560, 220), (640, 220),
                (400, 270), (480, 270), (560, 270), (640, 270)
            ]

            self.time_buttons = []
            self.button_states = {}

            for idx, time_str in enumerate(future_times):
                if idx < len(button_positions):
                    x, y = button_positions[idx]
                    operating_button = Button(booking_frame, text=time_str,
                                              compound='center', bg='white', fg='black', font=('Helvetica', 10, 'bold'))
                    operating_button.place(x=x, y=y, width=75, height=40)
                    operating_button.config(
                        command=lambda btn=operating_button, time=time_str: self.get_time_and_change_color(btn, time))

                    self.button_states[operating_button] = False  # False for white, True for selected color

                    # Store time buttons in a list for reference if needed
                    self.time_buttons.append(operating_button)

        # Update time buttons initially for today's date
        update_time_buttons()

        select_text = Label(booking_frame, text="Current assign doctor: ", font=('Helvetica', 14, 'underline'),
                            bg='white')
        select_text.place(x=50, y=330)

        enter_username_label = Label(booking_frame, text="Enter patient's username: ",
                                     font=('Helvetica', 14, 'underline'),
                                     bg='white')
        enter_username_label.place(x=50, y=450)

        self.enter_username_entry = Entry(booking_frame, width=130, fg='black', bd=0, font=('Helvetica', 14),
                                          bg='#E5E4E2')
        self.enter_username_entry.place(x=50, y=490, width=300, height=50)

        self.all_doctor_details = database.child('Doctor').get().val()
        if self.all_doctor_details:
            # Filter doctors based on work_clinic attribute
            doctors_in_clinic = [doctor for doctor in self.all_doctor_details.values()
                                 if doctor.get('work_clinic') == clinic_data.get('name', 'N/A')]

            if doctors_in_clinic:
                # Find the doctor whose dc_name matches self.dc_name
                doctor = None
                for d in doctors_in_clinic:
                    if d['dc_name'] == self.dc_name:
                        doctor = d
                        break

                if doctor:
                    doctor_button = Button(booking_frame,
                                           text=f"Doctor Name: {doctor['dc_name']}\nDoctor Email: {doctor['dc_email']}\nDoctor Speciality: {doctor['dc_specialty']}",
                                           bg='white', fg='black', font=('Helvetica', 10, 'bold'),
                                           compound='left')  # Adjust compound as needed
                    doctor_button.place(x=50, y=370, width=300, height=60)  # Adjust width and height as needed
                    doctor_button.config(bg='#ADD8E6')

        desc_text_label = Label(booking_frame, text="Describe problem",
                                font=('Helvetica', 14, 'underline'),
                                bg='white')
        desc_text_label.place(x=400, y=330)

        # Create the Entry widget with a background color matching the Label's background
        self.desc_entry = Text(booking_frame, width=130, fg='black', bd=0, font=('Helvetica', 13), bg='#E5E4E2')
        self.desc_entry.place(x=400, y=370, width=300, height=120)

        button_path = 'pictures/Search Clinic Page/Book Appointment/submit button.png'
        confirm_button_img = Image.open(button_path).resize((200, 50), Image.LANCZOS)
        self.images['button'] = ImageTk.PhotoImage(confirm_button_img)
        confirm_button = Button(booking_frame, image=self.images['button'], command=self.set_date, bg='white',
                                fg='white')

        confirm_button.place(x=470, y=530)

    def get_time_and_change_color(self, button, time_str):
        if self.selected_button_time and self.selected_button_time != button:
            self.selected_button_time.config(bg='white')  # Reset the previous button color
            self.button_states[self.selected_button_time] = False  # Update its state

        current_state = self.button_states[button]

        if current_state:
            button.config(bg='white')
            self.selected_time = None
        else:
            button.config(bg='#ADD8E6')
            self.selected_time = time_str

        self.button_states[button] = not current_state
        self.selected_button_time = button if not current_state else None  # Update the selected button
        return self.selected_time

    def set_date(self):
        selected_date_str = self.cal.get_date()

        try:
            self.selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
            if self.selected_date in self.busy_dates:
                messagebox.showerror("Error", "Doctor is busy on this date. Please select another date.")
                return

        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Please select a valid date.")
            return

        if self.selected_date < datetime.date.today():
            messagebox.showerror("Error", "Please select a date that is not in the past.")
            return

        if not self.selected_time:
            messagebox.showerror("Error", "Please select a time.")
            return

        # Retrieve the entered username
        user_name = self.enter_username_entry.get().strip()

        # Check if the username is entered
        if not user_name:
            messagebox.showerror("Error", "Please enter patient's username.")
            return

        # Check if the entered username exists in the database
        user_data = None
        for user in database.child("User").get().each():
            if user.val()["username"] == user_name:
                user_data = user.val()
                break

        if not user_data:
            messagebox.showerror("Error", "Entered username does not exist in the database.")
            return

        # Retrieve user details
        user = user_data["username"]
        email = user_data["email"]
        phone = user_data["phone"]
        patient_name = user_data["user_display_name"]

        # Get description text
        desc_text = self.desc_entry.get("1.0", "end-1c") if self.desc_entry else None

        # Construct appointment details message
        message = (
            f"Your selected date -> {self.selected_date}\n"
            f"Your selected time -> {self.selected_time}"
        )
        message += f"\nYour selected doctor -> dr.{self.dc_name}"

        message += (
            f"\n\nYour appointment made by\nPatient name -> {user}"
            f"\nPatient contact -> {phone}\nPatient email -> {email}"
            f"\n\nYour appointment location\nClinic name -> {self.clinic_name}"
            f"\nProblem describe -> {desc_text}"
        )

        # Show appointment confirmation message
        messagebox.showinfo("Appointment Successfully Made", message)

        # Get selected time details
        time_parts = self.selected_time.split(':')
        hour = int(time_parts[0])
        minute = int(time_parts[1])
        time_obj = datetime.time(hour, minute)

        # Find the selected doctor and retrieve doctor's ID
        doctor = next((doc_data for doc_id, doc_data in self.all_doctor_details.items() if
                       doc_data.get('dc_name') == self.dc_name), None)

        if not doctor:
            messagebox.showerror("Error", "Selected doctor not found.")
            return

        # Booking time and doctor's ID
        booking_time = datetime.datetime.now().strftime('%H:%M:%S')
        for doc_id, doc_data in self.all_doctor_details.items():
            if doc_data.get('dc_name') == self.dc_name:
                doctor = doc_data
                doctor['key'] = doc_id  # Capture the doctor's key for later use
                break

        if doctor:
            self.doctor_id = doctor['key']

        phone = database.child('User').child(user).child("phone").get().val()
        email = database.child('User').child(user).child("email").get().val()

        # Prepare appointment data
        appointment_data = {
            "appointment_time": self.selected_time,
            "appointment_date": str(self.selected_date),
            "booking_generated_time": booking_time,
            "clinic_Name": str(self.clinic_name),
            "doctor_Name": self.dc_name,
            "doctor_id": self.doctor_id,
            "status": "true",
            "user_name": str(user),
            "patient_name": patient_name,
            "desc_problem": desc_text,
            "email": email,
            "phone": phone
        }

        # Push appointment data to Firebase
        database.child("Appointment").push(appointment_data)
        database.child("Calendar").child(self.dc_name).child("Appointment").child(
            self.selected_date.strftime('%Y-%m-%d')).set(appointment_data)

        # Navigate to booking page
        self.app.show_page("view_doctor_from_admin")

    def get_clinic_data(self, clinic_name):
        try:
            # Replace with your actual database retrieval logic
            clinic_details = database.child('Clinic').child(clinic_name).get().val()
            return clinic_details or {}  # Return empty dictionary if clinic_details is None
        except Exception as e:
            messagebox.showerror("Error", f"Failed to retrieve clinic data: {str(e)}")
            return {}

    def fetch_appointment_dates(self, doctor_name):
        try:
            appointments = database.child("Calendar").child(doctor_name).child("Appointment").get()
            appointment_dates = []
            if appointments.each():
                for appointment in appointments.each():
                    appointment_info = appointment.val()
                    appointment_dates.append(appointment_info['appointment_date'])  # Ensure correct key is used
            return appointment_dates
        except Exception as e:
            print(f"Error fetching appointment dates: {e}")  # Debug statement
            return []
