# Admin add doctor page
# able to add a new doctor

import tkinter as tk
from tkinter import *
from tkinter import messagebox
from firebase_config import database
from admin.sidebar import Sidebar
import re
import random


# after clicking add doctor button, able to add a new doctor
class AddDoctor:
    def __init__(self, app, name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = name

        def on_enter(event):
            event.widget.config(bg="#8EC9F9")

        def on_leave(event):
            event.widget.config(bg="white")

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Settings Page
        add_doctor_frame = Frame(self.frame, bg='white')
        add_doctor_frame.pack(fill='both', expand=True, padx=10)  # Ensure the frame is packed

        settings_label = Label(add_doctor_frame, text="Add new doctor", font=("Poppins", 20, "bold"), bg="white")
        settings_label.place(x=70, y=50)

        # Create a frame for insert doctor_name
        doctor_display_name_label = Label(add_doctor_frame, text="Name", font=("Poppins", 14, "bold"), bg="white")
        doctor_display_name_label.place(x=70, y=120)
        self.doctor_display_name_label = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_display_name_label.place(x=250, y=120, width=300)

        # Create a frame for insert doctor_email
        doctor_email_label = Label(add_doctor_frame, text="Email", font=("Poppins", 14, "bold"), bg="white")
        doctor_email_label.place(x=70, y=160)
        self.doctor_email_entry = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_email_entry.place(x=250, y=160, width=300)

        # Create a frame for insert doctor_phone
        doctor_contact_label = Label(add_doctor_frame, text="Phone Number", font=("Poppins", 14, "bold"), bg="white")
        doctor_contact_label.place(x=70, y=200)
        self.doctor_contact_entry = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_contact_entry.place(x=250, y=200, width=300)

        # Create a frame for insert doctor_age
        doctor_age_label = Label(add_doctor_frame, text="Age", font=("Poppins", 14, "bold"), bg="white")
        doctor_age_label.place(x=70, y=240)
        self.doctor_age_label = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_age_label.place(x=250, y=240, width=300)

        # Create a frame for insert doctor_speciality
        doctor_specialty_label = Label(add_doctor_frame, text="Speciality", font=("Poppins", 14, "bold"), bg="white")
        doctor_specialty_label.place(x=70, y=280)
        self.doctor_specialty_label = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_specialty_label.place(x=250, y=280, width=300)

        # Create a frame for insert doctor_desc_self
        doctor_desc_label = Label(add_doctor_frame, text="Description", font=("Poppins", 14, "bold"), bg="white")
        doctor_desc_label.place(x=70, y=320)
        self.doctor_desc_label = Text(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_desc_label.place(x=250, y=320, width=300, height=50)

        # Create a frame for insert doctor_password
        doctor_password1_label = Label(add_doctor_frame, text="Password", font=("Poppins", 14, "bold"), bg="white")
        doctor_password1_label.place(x=70, y=380)
        self.doctor_password1_label = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_password1_label.place(x=250, y=380, width=300)

        # Create a frame for insert doctor_confirm_password
        doctor_password2_label = Label(add_doctor_frame, text="Confirm Password", font=("Poppins", 14, "bold"),
                                       bg="white")
        doctor_password2_label.place(x=70, y=420)
        self.doctor_password2_label = Entry(add_doctor_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.doctor_password2_label.place(x=250, y=420, width=300)

        def validate_save_button():
            c1 = self.doctor_display_name_label.get()
            c2 = self.doctor_email_entry.get()
            c3 = self.doctor_contact_entry.get()
            c4 = self.doctor_age_label.get()
            c5 = self.doctor_specialty_label.get()
            c6 = self.doctor_desc_label.get("1.0", "end-1c") if self.doctor_desc_label else None
            c7 = self.doctor_password1_label.get()
            c8 = self.doctor_password2_label.get()

            # validate for prompt input
            if any(value == "" for value in [c1, c2, c3, c4, c5, c6, c7, c8]):
                messagebox.showerror("Error", "All fields are required")
            elif not is_valid_email(c2):
                messagebox.showerror("Error", "Invalid email address format")
            elif not (c3.strip().isdigit() and 10 <= len(c3.strip()) <= 11):
                messagebox.showerror("Error", "Invalid contact number format")
            elif not is_valid_numeric(c4):
                messagebox.showerror("Error", "Invalid height format")
            elif (c7 != "" and c8 != "") and (c7 != c8):
                messagebox.showerror("Error", "Both passwords must be the same")
            else:
                # Check if contact number or email already exists
                email_exists = False
                phone_exists = False

                for doctor in database.child("Doctor").get().each():
                    if doctor.val()["dc_email"] == c2:
                        email_exists = True
                    if doctor.val()["dc_phone"] == c3:
                        phone_exists = True

                if email_exists:
                    messagebox.showerror("Error", "Email already existed")
                elif phone_exists:
                    messagebox.showerror("Error", "Contact number already existed")
                else:
                    # Save data to Firebase with a unique key
                    dc_id = ''.join([str(random.randint(0, 9)) for _ in range(12)])

                    new_doctor_data = {
                        "dc_name": c1,
                        "dc_email": c2,
                        "dc_phone": c3,
                        "dc_age": c4,
                        "dc_specialty": c5,
                        "work_clinic": name,
                        "work_desc": c6,
                        "dc_password": c8,
                    }

                    # Create or update the entry with the new username
                    database.child("Doctor").child(dc_id).set(new_doctor_data)
                    messagebox.showinfo("Success", "Updated changes made")
                    self.app.show_page("view_doctor_from_admin")
                    self.clear_entry_fields()  # Clear fields after successful update

        # Function to validate email address
        def is_valid_email(email):
            return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))

        # Function to validate only accept float or int
        def is_valid_numeric(input_str):
            try:
                float_value = float(input_str)
                return True
            except ValueError:
                return False

        save_button_image_path = "pictures/Settings/Save button.png"
        save_button_img = tk.PhotoImage(file=save_button_image_path)
        save_button_label = tk.Label(add_doctor_frame, image=save_button_img, bg='white')
        save_button_label.image = save_button_img

        cancel_button_image_path = "pictures/Settings/Cancel button.png"
        cancel_button_img = tk.PhotoImage(file=cancel_button_image_path)
        cancel_button_label = tk.Label(add_doctor_frame, image=cancel_button_img, bg='white')
        cancel_button_label.image = cancel_button_img

        cancel_button = Button(add_doctor_frame, image=cancel_button_img,
                               command=lambda: self.app.show_page("view_doctor_from_admin"),
                               borderwidth=0, bg='white', activebackground='white')
        cancel_button.place(x=350, y=500)

        save_button = Button(add_doctor_frame, image=save_button_img, command=validate_save_button,
                             borderwidth=0, bg='white', activebackground='white')
        save_button.place(x=450, y=500)

    def clear_entry_fields(self):
        # Clear entry fields
        self.doctor_display_name_label.delete(0, 'end')
        self.doctor_email_entry.delete(0, 'end')
        self.doctor_contact_entry.delete(0, 'end')
        self.doctor_age_label.delete(0, 'end')
        self.doctor_specialty_label.delete(0, 'end')
        self.doctor_desc_label.delete('1.0', 'end')
        self.doctor_password1_label.delete(0, 'end')
        self.doctor_password2_label.delete(0, 'end')
