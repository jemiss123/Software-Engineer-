import unittest
from unittest.mock import patch, MagicMock
from tkinter import Tk, messagebox
from user_handle_login_pages.login import LoginPage
from firebase_config import database

class TestLoginPage(unittest.TestCase):
    def setUp(self):
        self.app = MagicMock()
        self.root = Tk()
        self.root.withdraw()  # Hide the root window
        self.login_page = LoginPage(self.app)
        self.login_page.email_entry = MagicMock()
        self.login_page.password_entry = MagicMock()
        self.login_page.clear_entry_fields = MagicMock()

    def tearDown(self):
        self.root.destroy()  # Cleanup the root window after each test

    @patch("user_handle_login_pages.login.database")
    def test_handle_login_success(self, mock_database):
        mock_database.child().get().each.return_value = [
            MagicMock(val=lambda: {"username": "testuser", "password": "testpassword"})
        ]
        print()
        self.login_page.email_entry.get.return_value = "testuser"
        self.login_page.password_entry.get.return_value = "testpassword"

        with patch("tkinter.messagebox.showerror") as mock_showerror:
            self.login_page.handle_login()

            self.app.set_shared_data.assert_called_once_with("username", "testuser")
            self.app.show_page.assert_called_once_with("home", username="testuser")
            self.login_page.clear_entry_fields.assert_called_once()
            mock_showerror.assert_not_called()

    @patch("user_handle_login_pages.login.database")
    def test_handle_login_wrong_password(self, mock_database):
        mock_database.child().get().each.return_value = [
            MagicMock(val=lambda: {"username": "testuser", "password": "testpassword"})
        ]
        print()
        self.login_page.email_entry.get.return_value = "testuser"
        self.login_page.password_entry.get.return_value = "wrongpassword"

        with patch("tkinter.messagebox.showerror") as mock_showerror:
            self.login_page.handle_login()

            self.app.set_shared_data.assert_not_called()
            self.app.show_page.assert_not_called()
            self.login_page.clear_entry_fields.assert_not_called()
            mock_showerror.assert_called_once_with("Error", "Wrong password entered")

    @patch("user_handle_login_pages.login.database")
    def test_handle_login_user_not_found(self, mock_database):
        mock_database.child().get().each.return_value = []
        print()
        self.login_page.email_entry.get.return_value = "nonexistentuser"
        self.login_page.password_entry.get.return_value = "somepassword"

        with patch("tkinter.messagebox.showerror") as mock_showerror:
            self.login_page.handle_login()

            self.app.set_shared_data.assert_not_called()
            self.app.show_page.assert_not_called()
            self.login_page.clear_entry_fields.assert_not_called()
            mock_showerror.assert_called_once_with("Error", "Username not found")

if __name__ == "__main__":
    unittest.main()
