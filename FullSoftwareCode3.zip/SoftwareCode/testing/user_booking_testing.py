import unittest
from unittest.mock import MagicMock
from datetime import datetime, timedelta
from user_home_pages.booking import Booking


class TestBooking(unittest.TestCase):

    def setUp(self):
        # Mocking necessary dependencies and initial setup
        self.app = MagicMock()
        self.app.root = MagicMock()
        self.app.get_shared_data = MagicMock(return_value="test_username")  # Mocking username retrieval
        self.app.show_page = MagicMock()

        self.username = "test_username"
        self.clinic_name = "Test Clinic"
        self.dc_name = "Test Doctor"
        self.name = "Test User"

        self.booking = Booking(self.app, self.username, self.name, self.dc_name)

    def test_initialization(self):
        # Test initialization of Booking class
        self.assertIsNotNone(self.booking.frame)
        self.assertEqual(self.booking.username, "test_username")
        self.assertEqual(self.booking.dc_name, "Test Doctor")
        self.assertIsNone(self.booking.selected_date)
        self.assertIsNone(self.booking.selected_time)
        self.assertIsNone(self.booking.selected_doctor)
        self.assertIsNone(self.booking.selected_button_time)
        self.assertIsNone(self.booking.selected_button_doctor)

    def test_get_clinic_data(self):
        # Test retrieving clinic data
        clinic_data = self.booking.get_clinic_data(self.clinic_name)
        self.assertIsInstance(clinic_data, dict)

    def test_get_doctor_and_change_color(self):
        # Test selecting a doctor and changing button color
        doctor_button = MagicMock()
        doctor_data = {
            "dc_name": "Test Doctor",
            "dc_email": "test_doctor@example.com",
            "dc_specialty": "Test Specialty"
        }

        selected_doctor = self.booking.get_doctor_and_change_color(doctor_button, doctor_data)
        self.assertEqual(self.booking.selected_doctor, "Test Doctor")
        doctor_button.config.assert_called_once_with(bg='#ADD8E6')  # Assert button color change

    def test_get_time_and_change_color(self):
        # Test selecting a time and changing button color
        time_button = MagicMock()
        selected_time = self.booking.get_time_and_change_color(time_button, "10:00")
        self.assertEqual(self.booking.selected_time, "10:00")
        time_button.config.assert_called_once_with(bg='#ADD8E6')  # Assert button color change

    def test_highlight_busy_dates(self):
        # Test highlighting busy dates on calendar
        doctor_name = "Test Doctor"
        self.booking.highlight_busy_dates(doctor_name)
        # Assert that at least one busy date is highlighted
        self.assertGreater(len(self.booking.cal.get_calevents(tag='busy')), 0)

    def test_set_date_invalid_date_format(self):
        # Test handling invalid date format
        self.booking.cal.get_date = MagicMock(return_value="invalid_date_format")
        self.booking.set_date()
        self.app.show_page.assert_not_called()  # Assert that page transition was not triggered

    def test_set_date_past_date(self):
        # Test handling selection of past date
        past_date = datetime.now() - timedelta(days=1)
        self.booking.cal.get_date = MagicMock(return_value=past_date.strftime('%Y-%m-%d'))
        self.booking.set_date()
        self.app.show_page.assert_not_called()  # Assert that page transition was not triggered

    def test_set_date_no_time_selected(self):
        # Test handling when no time is selected
        self.booking.selected_time = None
        self.booking.set_date()
        self.app.show_page.assert_not_called()  # Assert that page transition was not triggered

    def test_set_date_busy_date_selected(self):
        # Test handling selection of a busy date
        self.booking.selected_date = datetime.now() + timedelta(days=1)
        self.booking.selected_time = "10:00"
        self.booking.fetch_appointment_dates = MagicMock(
            return_value=[(datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')])
        self.booking.set_date()
        self.app.show_page.assert_not_called()  # Assert that page transition was not triggered

    def test_set_date_successful_booking(self):
        # Test successful booking scenario
        self.booking.selected_date = datetime.now() + timedelta(days=1)
        self.booking.selected_time = "10:00"
        self.booking.desc_entry.get = MagicMock(return_value="Test description")
        self.booking.fetch_appointment_dates = MagicMock(return_value=[])
        self.booking.set_date()
        self.app.show_page.assert_called_once_with("booking")  # Assert successful page transition

    def tearDown(self):
        # Clean up any resources if needed
        pass


if __name__ == "__main__":
    unittest.main()

