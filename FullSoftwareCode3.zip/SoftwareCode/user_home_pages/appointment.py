# User appointment page
# This page will show all the appointment that have made from that user with the appointment details

import tkinter as tk
from tkinter import *
from tkinter import messagebox
from user_home_pages.sidebar import Sidebar
from firebase_config import database


class Appointment:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = None
        self.image_references = []  # To hold image references
        self.username = username or self.app.get_shared_data("username")
        self.view_appointment()

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

    def view_appointment(self):
        self.view_appointment_frame = tk.Frame(self.frame, bg='white')
        self.view_appointment_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=50)

        heading_label = tk.Label(self.view_appointment_frame, text=f"Recent Appointment | {self.username}",
                                 font=("Arial", 18, "bold"), bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas_appointment = tk.Canvas(self.view_appointment_frame, bg='white')
        self.canvas_appointment.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar_appointment = tk.Scrollbar(self.view_appointment_frame, orient=tk.VERTICAL,
                                             command=self.canvas_appointment.yview)
        scrollbar_appointment.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas_appointment.configure(yscrollcommand=scrollbar_appointment.set)
        self.canvas_appointment.bind('<Configure>', lambda e: self.canvas_appointment.configure(
            scrollregion=self.canvas_appointment.bbox('all')))

        self.view_appointment_container = tk.Frame(self.canvas_appointment, bg='white')
        self.canvas_appointment.create_window((0, 0), window=self.view_appointment_container, anchor='nw')

        # Update the bind event to handle different operating systems
        self.canvas_appointment.bind_all("<MouseWheel>", self.on_mouse_wheel_appointment)
        self.display_appointment()

    def on_mouse_wheel_appointment(self, event):
        if event.num == 4 or event.delta > 0:
            self.canvas_appointment.yview_scroll(-1, "units")
        elif event.num == 5 or event.delta < 0:
            self.canvas_appointment.yview_scroll(1, "units")

    def fetch_appointment_data(self):
        try:
            appointments_snapshot = database.child('Appointment').get()
            if appointments_snapshot.each():
                # Convert snapshot to list of dictionaries
                appointments_list = [appointment.val() for appointment in appointments_snapshot.each()]
                # Filter appointments by the logged-in username
                matching_appointments = [appointment for appointment in appointments_list if
                                         appointment['user_name'] == self.username]
                return matching_appointments  # Return the list of matching appointments
            else:
                return []  # Return an empty list if there are no appointments
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch appointment data: {e}")
            return []

    def create_view_appointment_rectangle(self, appointment):
        appointment_frame = tk.Frame(self.view_appointment_container, bg='black')
        appointment_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_clinic_path = 'pictures/Search Clinic Page/Rectangle.png'
        Rectangle_for_clinic_img = PhotoImage(file=Rectangle_for_clinic_path)
        self.image_references.append(Rectangle_for_clinic_img)

        #Rectangle_for_clinic_path = 'pictures/Search Clinic Page/Rectangle.png'
        #Rectangle_for_clinic_img = Image.open(Rectangle_for_clinic_path).resize((680, 130), Image.LANCZOS)
        #self.image_references.append(Rectangle_for_clinic_img)

        canvas = tk.Canvas(appointment_frame, width=Rectangle_for_clinic_img.width(),
                           height=Rectangle_for_clinic_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        appointment_date = appointment.get("appointment_date", "N/A")
        appointment_time = appointment.get("appointment_time", "N/A")
        appointment_date_label = tk.Label(canvas,
                                          text=f"{appointment_date} {appointment_time}| {appointment.get('clinic_Name', 'N/A')}",
                                          font=("Work Sans", 16, "bold"),
                                          bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=appointment_date_label)

        patient_name_label = tk.Label(appointment_frame, text=f"Patient Name: {appointment.get('user_name', 'N/A')}",
                                      font=("Arial", 12),
                                      bg='#D9D9D9')
        patient_name_label.place(x=20, y=50)

        patient_status_label = tk.Label(appointment_frame,
                                        text=f"Patient Status: {appointment.get('status', 'N/A')}",
                                        font=("Arial", 12), bg='#D9D9D9')
        patient_status_label.place(x=20, y=80)

        doctor_name_label = tk.Label(appointment_frame, text=f"Doctor Name: Dr.{appointment.get('doctor_Name', 'N/A')}",
                                     font=("Arial", 12), bg='#D9D9D9')
        doctor_name_label.place(x=330, y=50)

        desc_problems_label = tk.Label(appointment_frame,
                                       text=f"Describe problems: {appointment.get('desc_problem', 'N/A')}",
                                       font=("Arial", 12), bg='#D9D9D9')
        desc_problems_label.place(x=330, y=80)

        def prescription():
            # pass
            username = appointment.get('user_name', 'N/A')
            clinic_name = appointment.get('clinic_Name', 'N/A')
            doctor_name = appointment.get('doctor_Name', 'N/A')
            self.app.set_shared_data("username", username)
            self.app.set_shared_data("name", clinic_name)
            self.app.set_shared_data("dc_name", doctor_name)
            self.app.show_page("user_view_prescriptions")

        view_prescription_label = tk.Button(appointment_frame,
                                            text="View prescriptions",  # Use \n for line break
                                            font=("Arial", 10, 'underline'), bg='#D9D9D9',
                                            command=prescription)
        # command=lambda: self.app.show_page("user_view_prescriptions"))  # Center align text
        view_prescription_label.place(x=480, y=10)

    def display_appointment(self):
        appointments = self.fetch_appointment_data()
        if not appointments:
            # Handle no appointment data scenario
            no_appointment_label = tk.Label(self.view_appointment_frame, text="No appointment data found",
                                            font=("Arial", 12),
                                            bg='white')
            no_appointment_label.pack(pady=50)
        else:
            for appointment in appointments:
                self.create_view_appointment_rectangle(appointment)
