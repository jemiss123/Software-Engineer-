# User generate prescription page
# able to show that appointment prescriptions

import tkinter as tk
from tkinter import *
from user_home_pages.sidebar import Sidebar
from firebase_config import database


class UserGeneratePrescriptions:
    def __init__(self, app, username, name, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username if username else ""  # Ensure username is not None
        self.dc_name = dc_name if dc_name else ""  # Ensure dc_name is not None
        self.name = name if name else ""  # Ensure name is not None

        # Initialize attributes with default values
        self.user_display_name = "N/A"
        self.doctor_name = "N/A"
        self.appointment_date = "N/A"
        self.appointment_time = "N/A"
        self.appointment_clinic = "N/A"
        self.desc_problem = "N/A"
        self.medications = "N/A"
        self.instructions = "N/A"

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Settings Page
        generate_prescriptions_frame = Frame(self.frame, bg='white')
        generate_prescriptions_frame.pack(fill='both', expand=True, padx=10)

        settings_label = Label(generate_prescriptions_frame,
                               text=f"Generate Prescriptions of {self.username} at {self.name}",
                               font=("Poppins", 18, "bold"), bg="white")
        settings_label.place(x=50, y=50)

        # Fetch prescription data from Firebase
        ref = database.child("Prescription")
        prescription_data = ref.get()

        if prescription_data:
            for prescription in prescription_data.each():
                if (prescription.val().get("user_name") == self.username and
                        prescription.val().get("clinic_name") == self.name):
                    # Retrieve data from Firebase
                    self.user_display_name = prescription.val().get("patient_name", "")
                    self.doctor_name = prescription.val().get("doctor_name", "")
                    self.appointment_date = prescription.val().get("appointment_date", "")
                    self.appointment_time = prescription.val().get("appointment_time", "")
                    self.appointment_clinic = prescription.val().get("clinic_name", "")
                    self.desc_problem = prescription.val().get("desc_problem", "")
                    self.medications = prescription.val().get("medications", "")
                    self.instructions = prescription.val().get("instructions", "")

                    break  # Stop after finding the matching prescription
            else:
                pass
        else:
            pass

        # Create Entry widgets and populate with fetched data
        user_name_label = Label(generate_prescriptions_frame, text="Patient's username",
                                font=("Poppins", 14, "bold"), bg="white")
        user_name_label.place(x=70, y=120)
        self.user_name_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                     font=('Montserrat', 12))
        self.user_name_entry.place(x=270, y=120, width=300)
        self.user_name_entry.insert(0, self.username)  # Insert username into entry field

        user_display_name_label = Label(generate_prescriptions_frame, text="Patient Name",
                                        font=("Poppins", 14, "bold"), bg="white")
        user_display_name_label.place(x=70, y=160)
        self.user_display_name_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                             font=('Montserrat', 12))
        self.user_display_name_entry.place(x=270, y=160, width=300)
        self.user_display_name_entry.insert(0, self.user_display_name)  # Insert user_display_name into entry field

        dc_name_label = Label(generate_prescriptions_frame, text="Doctor Name",
                              font=("Poppins", 14, "bold"), bg="white")
        dc_name_label.place(x=70, y=200)
        self.dc_name_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                   font=('Montserrat', 12))
        self.dc_name_entry.place(x=270, y=200, width=300)
        self.dc_name_entry.insert(0, self.doctor_name)  # Insert doctor_name into entry field

        appointment_date_label = Label(generate_prescriptions_frame, text="Appointment Date",
                                       font=("Poppins", 14, "bold"), bg="white")
        appointment_date_label.place(x=70, y=240)
        self.appointment_date_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                            font=('Montserrat', 12))
        self.appointment_date_entry.place(x=270, y=240, width=300)
        self.appointment_date_entry.insert(0, self.appointment_date)  # Insert appointment_date into entry field

        appointment_time_label = Label(generate_prescriptions_frame, text="Appointment Time",
                                       font=("Poppins", 14, "bold"), bg="white")
        appointment_time_label.place(x=70, y=280)
        self.appointment_time_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                            font=('Montserrat', 12))
        self.appointment_time_entry.place(x=270, y=280, width=300)
        self.appointment_time_entry.insert(0, self.appointment_time)  # Insert appointment_time into entry field

        appointment_clinic_label = Label(generate_prescriptions_frame, text="Appointment Clinic",
                                         font=("Poppins", 14, "bold"), bg="white")
        appointment_clinic_label.place(x=70, y=320)
        self.appointment_clinic_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                              font=('Montserrat', 12))
        self.appointment_clinic_entry.place(x=270, y=320, width=300)
        self.appointment_clinic_entry.insert(0, self.appointment_clinic)  # Insert clinic_Name into entry field

        desc_problem_label = Label(generate_prescriptions_frame, text="Describe problems",
                                   font=("Poppins", 14, "bold"), bg="white")
        desc_problem_label.place(x=70, y=360)
        self.desc_problem_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                        font=('Montserrat', 12))
        self.desc_problem_entry.place(x=270, y=360, width=300)
        self.desc_problem_entry.insert(0, self.desc_problem)  # Insert desc_problem into entry field

        medications_label = Label(generate_prescriptions_frame, text="Medications", font=("Poppins", 14, "bold"),
                                  bg="white")
        medications_label.place(x=70, y=400)
        self.medications_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                       font=('Montserrat', 12))
        self.medications_entry.place(x=270, y=400, width=300)
        self.medications_entry.insert(0, self.medications)  # Insert medications into entry field

        instructions_label = Label(generate_prescriptions_frame, text="Instructions", font=("Poppins", 14, "bold"),
                                   bg="white")
        instructions_label.place(x=70, y=440)
        self.instructions_entry = Text(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                       font=('Montserrat', 12), wrap=WORD)
        self.instructions_entry.place(x=270, y=440, width=300, height=100)
        self.instructions_entry.insert(1.0, self.instructions)  # Insert instructions into text field
