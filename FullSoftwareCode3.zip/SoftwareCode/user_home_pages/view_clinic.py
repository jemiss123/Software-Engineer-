# User view clinic
# - able to view the details of the clinic

import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
from tkintermapview import TkinterMapView  # Make sure you have installed tkintermapview
from user_home_pages.sidebar import Sidebar
from firebase_config import database


class ViewClinic:
    def __init__(self, app, name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = name

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)  # Replace Sidebar with your Sidebar class
        self.sidebar.pack(side='left', fill='y')
        self.images = {}

        # Create a frame for clinic details
        view_clinic_frame = Frame(self.frame, bg='white')
        view_clinic_frame.pack(side='left', fill='both', expand=True)

        # Clinic image
        self.images['CLINIC V_CARE'] = ImageTk.PhotoImage(
            Image.open('pictures/Search Clinic Page/CLINIC V_CARE.png').resize((280, 250),
                                                                               Image.Resampling.LANCZOS))
        self.images['KLINIK BAYAN MEDIC'] = ImageTk.PhotoImage(
            Image.open('pictures/Search Clinic Page/KLINIK BAYAN MEDIC.png').resize((280, 250),
                                                                                    Image.Resampling.LANCZOS))
        self.images['MD CLINIC'] = ImageTk.PhotoImage(
            Image.open('pictures/Search Clinic Page/MD CLINIC.png').resize((280, 250),
                                                                           Image.Resampling.LANCZOS))
        self.images['BWELL CLINIC'] = ImageTk.PhotoImage(
            Image.open('pictures/Search Clinic Page/BWELL CLINIC.png').resize((280, 250),
                                                                              Image.Resampling.LANCZOS))
        self.images['KLINIK HARI'] = ImageTk.PhotoImage(
            Image.open('pictures/Search Clinic Page/KLINIK HARI.png').resize((280, 250),
                                                                             Image.Resampling.LANCZOS))

        # Retrieve clinic name from shared data
        clinic_name = self.app.get_shared_data("name")
        clinic_details = database.child("Clinic").child(clinic_name).get().val()

        # Fetch clinic details from Firebase
        # try:
        if clinic_name and clinic_name in self.images:
            clinic_img = Label(view_clinic_frame, image=self.images[clinic_name], bg='white')
            clinic_img.place(x=50, y=50)

        if clinic_details:
            # Accessing clinic details
            clinic_data = clinic_details

            # Display clinic details
            name_label = Label(view_clinic_frame, text=f"{clinic_data.get('name', 'N/A')}",
                               font=('Helvetica', 24, 'bold'), bg='white')
            name_label.place(x=400, y=80)

            # Address label with word wrapping
            address_label = Label(view_clinic_frame, text="Address:",
                                  font=('Helvetica', 12, 'bold'), bg='white')
            address_label.place(x=380, y=150)

            address_text = clinic_data.get('address', 'N/A')
            address_value_label = Label(view_clinic_frame, text=f"{address_text}",
                                        font=('Helvetica', 12), bg='white', wraplength=250, justify='left')
            address_value_label.place(x=460, y=150)

            # Operating Hours label in bold
            hours_label = Label(view_clinic_frame, text="Operating Hours:",
                                font=('Helvetica', 12, 'bold'), bg='white')
            hours_label.place(x=380, y=250)

            hours_value_label = Label(view_clinic_frame,
                                      text=f"{clinic_data.get('open_time', 'N/A')} - {clinic_data.get('close_time', 'N/A')}",
                                      font=('Helvetica', 12), bg='white')
            hours_value_label.place(x=520, y=250)

            # Review label in bold
            review_label = Label(view_clinic_frame, text="Review:",
                                 font=('Helvetica', 12, 'bold'), bg='white')
            review_label.place(x=380, y=280)

            review_value_label = Label(view_clinic_frame, text=f"{clinic_data.get('Review', 'N/A')}",
                                       font=('Helvetica', 12), bg='white')
            review_value_label.place(x=460, y=280)

            # Status label in bold
            status_label = Label(view_clinic_frame, text="Status:",
                                 font=('Helvetica', 12, 'bold'), bg='white')
            status_label.place(x=380, y=310)

            status_value_label = Label(view_clinic_frame, text=f"{clinic_data.get('status', 'N/A')}",
                                       font=('Helvetica', 12), bg='white')
            status_value_label.place(x=460, y=310)

            phone_label = Label(view_clinic_frame, text="Phone Number:",
                                font=('Helvetica', 12, 'bold'), bg='white')
            phone_label.place(x=380, y=340)

            phone_value_label = Label(view_clinic_frame, text=f"{clinic_data.get('phone', 'N/A')}",
                                      font=('Helvetica', 12), bg='white')
            phone_value_label.place(x=510, y=340)

            # Add Google Maps widget for the clinic
            gmap_widget = TkinterMapView(view_clinic_frame, width=280, height=250)
            gmap_widget.place(x=50, y=320)

            # Set Google Maps tile server and position based on clinic's latitude and longitude
            gmap_widget.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga",
                                        max_zoom=22)
            gmap_widget.set_position(float(clinic_data.get('latitude', 0.0)),
                                     float(clinic_data.get('longitude', 0.0)))

            # Set marker at specified coordinates
            marker_label_text = clinic_data.get('name', 'Clinic Name')
            marker = gmap_widget.set_marker(float(clinic_data.get('latitude', 0.0)),
                                            float(clinic_data.get('longitude', 0.0)),
                                            marker_label_text,
                                            marker_color_circle="white", marker_color_outside="red")

            # Set the initial zoom level
            gmap_widget.set_zoom(17)

        def make_booking():
            self.app.set_shared_data("name", clinic_name)
            self.app.show_page("booking", name=clinic_name)

        # Button image
        self.images['button'] = ImageTk.PhotoImage(Image.open('pictures/Search Clinic Page/Request doctor button.png').
                                                   resize((250, 50), Image.Resampling.LANCZOS))

        confirm_button = Button(view_clinic_frame, image=self.images['button'], bg='white',
                                command=make_booking, borderwidth=0, activebackground='white')
        confirm_button.place(x=420, y=450)
