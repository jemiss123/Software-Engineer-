# User sidebar page
# Able to show the user sidebar and call in every user pages

import tkinter as tk
from tkinter import *
from tkinter import PhotoImage, Label, Frame


class Sidebar(tk.Frame):
    def __init__(self, parent, app, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.app = app
        self.config(bg='white')

        def on_enter(event):
            event.widget.config(bg="#8EC9F9")

        def on_leave(event):
            event.widget.config(bg="white")

        # Create frame for navigation section
        nav_frame = Frame(self, bg='white', highlightbackground="lightgrey", highlightthickness=1)
        nav_frame.pack(side=LEFT, fill=Y, expand=True)

        # Load and display the navigation heading image
        nav_heading_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation heading.png"
        nav_heading_img = PhotoImage(file=nav_heading_image_path)
        nav_heading_label = Label(nav_frame, image=nav_heading_img, bg='white')
        nav_heading_label.image = nav_heading_img
        nav_heading_label.pack(pady=20)

        # Helper function to create navigation labels
        def create_nav_label(image_path, command):
            img = PhotoImage(file=image_path)
            label = Label(nav_frame, image=img, bg='white')
            label.image = img  # Keep a reference to avoid garbage collection
            label.pack(pady=20, fill=X, expand=True)
            label.bind("<Enter>", on_enter)
            label.bind("<Leave>", on_leave)
            label.bind("<Button-1>", lambda event: command())
            return label

        # Load and display the navigation homepage image
        nav_homepage_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation homepage.png"
        create_nav_label(nav_homepage_image_path, lambda: self.app.show_page("home"))

        # Load and display the navigation search clinic image
        nav_search_clinic_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation search clinic.png"
        create_nav_label(nav_search_clinic_image_path, lambda: self.app.show_page("search_clinic"))

        # Load and display the navigation appointments image
        nav_appointments_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation appointment.png"
        create_nav_label(nav_appointments_image_path, lambda: self.app.show_page("appointment"))

        # Load and display the navigation view doctor image
        nav_view_doctor_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation viewdoctors.png"
        create_nav_label(nav_view_doctor_image_path, lambda: self.app.show_page("view_doctor_from_user"))

        # Load and display the navigation settings image
        nav_settings_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation settings.png"
        create_nav_label(nav_settings_image_path, lambda: self.app.show_page("settings"))

        # Load and display the logout image
        nav_logout_image_path = r"C:\Users\mingl\OneDrive - student.newinti.edu.my\INTI DEGREE\SEM2\Pycharm Source Code\SoftwareCode\pictures\HomePage\navigation logout.png"
        logout_label = create_nav_label(nav_logout_image_path, lambda: self.app.show_page("login"))
        logout_label.pack_configure(side=BOTTOM, pady=(5, 20))  # Positioning at the bottom with padding
