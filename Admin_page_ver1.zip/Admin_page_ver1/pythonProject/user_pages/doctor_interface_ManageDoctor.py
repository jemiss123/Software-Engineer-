import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
from tkinter import ttk
from pathlib import Path
import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyDiA5rKfit9LXKrh35bgQCTqpGi5J2vSUA",
    "authDomain": "softwareass-da7ac.firebaseapp.com",
    "databaseURL": "https://softwareass-da7ac-default-rtdb.firebaseio.com/",
    "projectId": "softwareass-da7ac",
    "storageBucket": "softwareass-da7ac.appspot.com",
    "messagingSenderId": "336658277230",
    "appId": "1:336658277230:web:254e782d894509d680577f",
    "measurementId": "G-T2BN7W9TXT"
}

firebase = pyrebase.initialize_app(firebaseConfig)
database = firebase.database()

# Initialize Tkinter
root = Tk()
root.title('Homepage')
root.geometry('1331x594')  # Adjusted width to accommodate navigation section
root.configure(bg="#fff")
root.resizable(False, False)

# Create frame for navigation section
nav_frame = Frame(root, width=281, height=594, bg='white', highlightbackground="lightgrey", highlightthickness=1)
nav_frame.pack(side=LEFT, fill=Y)

# Load and display the navigation heading image
nav_heading_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation heading.png"
nav_heading_img = PhotoImage(file=nav_heading_image_path)
nav_heading_label = Label(nav_frame, image=nav_heading_img, bg='white')
nav_heading_label.image = nav_heading_img
nav_heading_label.pack(pady=20)

# Load and display the navigation Manage Request button
nav_ManageRequest_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation ManageRequest.png"
nav_ManageRequest_img = PhotoImage(file=nav_ManageRequest_path)
nav_ManageRequest_button = Button(nav_frame, image=nav_ManageRequest_img, borderwidth=0, bg='white', activebackground='white')
nav_ManageRequest_button.image = nav_ManageRequest_img
nav_ManageRequest_button.pack(pady=20)

# Load and display the navigation view Manage Doctor button
nav_ManageDoctor_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation ManageDoctor.png"
nav_ManageDoctor_img = PhotoImage(file=nav_ManageDoctor_image_path)
nav_ManageDoctor_button = Button(nav_frame, image=nav_ManageDoctor_img, borderwidth=0, bg='white', activebackground='white')
nav_ManageDoctor_button.image = nav_ManageDoctor_img
nav_ManageDoctor_button.pack(pady=20)

# Load and display the logout button
nav_logout_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation logout.png"
nav_logout_img = PhotoImage(file=nav_logout_image_path)
nav_logout_button = Button(nav_frame, image=nav_logout_img, borderwidth=0, bg='white', activebackground='white')
nav_logout_button.image = nav_logout_img
nav_logout_button.pack(side=BOTTOM, pady=(5, 20))  # Positioning at the bo

# Function to show a dialog box for status change
def change_status_dialog(item):
    result = messagebox.askquestion(
        "Change Status",
        "Do you want to accept or reject this request?",
        icon='question'
    )

    if result == 'yes':
        result = messagebox.askyesnocancel(
            "Select Action",
            "Do you want to Accept?",
            icon='question'
        )
        if result is True:
            tree.set(item, "Status", "Accepted")
            update_status_in_db(item, True)
        elif result is False:
            tree.set(item, "Status", "Rejected")
            update_status_in_db(item, False)
        else:
            pass  # User cancelled

# Update status in the database
def update_status_in_db(item, status):
    try:
        item_values = tree.item(item, 'values')
        appointment_date = item_values[0]
        appointment_time = item_values[1]

        # Find the correct record in the database and update it
        appointments = database.child('Appointment').get()
        if appointments.each():
            for appointment in appointments.each():
                appointment_data = appointment.val()
                if (appointment_data.get('appointment_date') == appointment_date and
                    appointment_data.get('appointment_time') == appointment_time):
                    database.child('Appointment').child(appointment.key()).update({'status': status})
                    break
    except Exception as e:
        messagebox.showerror("Error", f"Failed to update status: {e}")

# Bind mouse click to handle status change
def on_tree_select(event):
    selected_item = tree.selection()
    if selected_item:
        if tree.identify_region(event.x, event.y) == "cell":
            column = tree.identify_column(event.x)
            if column == "#6":
                change_status_dialog(selected_item[0])

# Function to fetch and insert data into the table
def fetch_and_insert_data():
    try:
        appointments = database.child('Appointment').get()

        if appointments.each():
            for appointment in appointments.each():
                patient_name = appointment.key()  # Get the patient name
                appointment_data = appointment.val()
                status = "Pending" if not appointment_data.get('status', False) else "Accepted"
                row = (
                    appointment_data.get('appointment_date', 'N/A'),
                    appointment_data.get('appointment_time', 'N/A'),
                    patient_name,  # Add patient name to the row
                    appointment_data.get('doctor_Name', 'N/A'),
                    appointment_data.get('clinic_Name', 'N/A'),
                    status,
                )
                tree.insert('', 'end', values=row)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to fetch data: {e}")

# Create a frame for patient records section
request_record_frame = tk.Frame(root, bg='white')
request_record_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

# Add heading
heading_label = tk.Label(request_record_frame, text="Patient Request", font=("Arial", 18, "bold"), bg='white')
heading_label.pack(anchor='w', padx=50, pady=30)

# Table frame
table_frame = tk.Frame(request_record_frame, padx=30, pady=30)
table_frame.pack(fill=tk.BOTH, expand=True)

# Style the Treeview
style = ttk.Style()
style.configure("Treeview",
                background="#F5F5F5",
                foreground="black",
                rowheight=25,
                fieldbackground="#F5F5F5",
                font=('Arial', 12))
style.configure("Treeview.Heading",
                background="#0C7FDA",
                font=('Arial', 12, 'bold'))
style.map('Treeview',
          background=[('selected', '#0C7FDA')])

# Create table
columns = ("Date", "Time", "Patient Name", "Doctor Name", "Clinic Name", "Status")
tree = ttk.Treeview(table_frame, columns=columns, show='headings')
tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Define headings
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=120, anchor=tk.CENTER)

# Scrollbar for the table
scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
tree.configure(yscroll=scrollbar.set)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Bind mouse click to handle status change
tree.bind("<Button-1>", on_tree_select)

# Insert data into the table
fetch_and_insert_data()


# Run the application
root.mainloop()