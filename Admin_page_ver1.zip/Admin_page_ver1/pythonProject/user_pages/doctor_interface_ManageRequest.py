import datetime
import random
import re
from tkcalendar import Calendar

import firebase_admin
from firebase_admin import credentials, db
import firebase_admin
from firebase_admin import firestore
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyDiA5rKfit9LXKrh35bgQCTqpGi5J2vSUA",
    "authDomain": "softwareass-da7ac.firebaseapp.com",
    "databaseURL": "https://softwareass-da7ac-default-rtdb.firebaseio.com/",
    "projectId": "softwareass-da7ac",
    "storageBucket": "softwareass-da7ac.appspot.com",
    "messagingSenderId": "336658277230",
    "appId": "1:336658277230:web:254e782d894509d680577f",
    "measurementId": "G-T2BN7W9TXT"
}

firebase = pyrebase.initialize_app(firebaseConfig)
database = firebase.database()

def setup_navigation(root, show_clinics_view):
    nav_frame = Frame(root, width=281, height=594, bg='white', highlightbackground="lightgrey", highlightthickness=1)
    nav_frame.pack(side=LEFT, fill=Y)

    nav_heading_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation heading.png"
    nav_heading_img = PhotoImage(file=nav_heading_image_path)
    nav_heading_label = Label(nav_frame, image=nav_heading_img, bg='white')
    nav_heading_label.image = nav_heading_img
    nav_heading_label.pack(pady=20)

    nav_ManageRequest_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation ManageRequest.png"
    nav_ManageRequest_img = PhotoImage(file=nav_ManageRequest_path)
    nav_ManageRequest_button = Button(nav_frame, image=nav_ManageRequest_img, borderwidth=0, bg='white', activebackground='white')
    nav_ManageRequest_button.image = nav_ManageRequest_img
    nav_ManageRequest_button.pack(pady=20)

    nav_ManageDoctor_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation ManageDoctor.png"
    nav_ManageDoctor_img = PhotoImage(file=nav_ManageDoctor_image_path)
    nav_ManageDoctor_button = Button(nav_frame, image=nav_ManageDoctor_img, borderwidth=0, bg='white', activebackground='white', command=show_clinics_view)
    nav_ManageDoctor_button.image = nav_ManageDoctor_img
    nav_ManageDoctor_button.pack(pady=20)

    nav_logout_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\navigation logout.png"
    nav_logout_img = PhotoImage(file=nav_logout_image_path)
    nav_logout_button = Button(nav_frame, image=nav_logout_img, borderwidth=0, bg='white', activebackground='white')
    nav_logout_button.image = nav_logout_img
    nav_logout_button.pack(side=BOTTOM, pady=(5, 20))

class ClinicApp:
    def __init__(self, root):
        self.root = root
        self.current_view = None
        self.content_frame = Frame(root, bg='white')
        self.content_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        setup_navigation(root, self.show_clinics_view)
        self.show_clinics_view()

    def clear_frame(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()

    def show_clinics_view(self):
        self.clear_frame()
        ShowClinics(self.content_frame, self.show_doctors_view)

    def show_doctors_view(self, clinic_name):
        print(f"Switching to doctors view for clinic: {clinic_name}")  # Debug statement
        self.clear_frame()
        ShowDoctors(self.content_frame, clinic_name)

class ShowClinics(Frame):
    def __init__(self, root, show_doctors_callback):
        super().__init__(root, bg='white')
        self.root = root
        self.show_doctors_callback = show_doctors_callback
        self.setup_clinic_section()
        self.pack(fill=tk.BOTH, expand=True)

    def setup_clinic_section(self):
        heading_label = tk.Label(self, text="Select Clinic", font=("Arial", 18, "bold"), bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas = tk.Canvas(self, bg='white')
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(self, orient=tk.VERTICAL, command=self.canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))

        self.clinic_container = tk.Frame(self.canvas, bg='white')
        self.canvas.create_window((0, 0), window=self.clinic_container, anchor='nw')

        self.canvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

        self.display_clinics()

    def on_mouse_wheel(self, event):
        self.canvas.yview_scroll(-1 * int((event.delta / 120)), "units")

    def fetch_clinic_data(self):
        try:
            clinics = database.child('Clinic').get()
            if clinics.each():
                return [clinic.val() for clinic in clinics.each()]
            else:
                return []
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data: {e}")
            return []

    def create_clinic_rectangle(self, clinic):
        clinic_frame = tk.Frame(self.clinic_container, bg='white')
        clinic_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_clinic_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\pictures_ManageDoc\Rectangle-show clinic.png"
        Rectangle_for_clinic_img = PhotoImage(file=Rectangle_for_clinic_path)

        canvas = tk.Canvas(clinic_frame, width=Rectangle_for_clinic_img.width(), height=Rectangle_for_clinic_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        name_label = tk.Label(canvas, text=f"{clinic['name']}", font=("Work Sans", 16, "bold"), bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=name_label)

        review_label = tk.Label(clinic_frame, text=f"Review: {clinic['Review']}", font=("Arial", 12), bg='#D9D9D9')
        review_label.place(x=20, y=50)

        time_label = tk.Label(clinic_frame, text=f"Operating Hours:\n{clinic['open_time']} - {clinic['close_time']}", font=("Work Sans", 14, "bold"), bg='#D9D9D9')
        time_label.place(x=300, y=40)

        status_label = tk.Label(clinic_frame, text=f"Status: {clinic['status']}", font=("Arial", 12), bg='#D9D9D9')
        status_label.place(x=20, y=70)

        arrow_button_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\pictures_ManageDoc\circle-chevron-right-solid.png"
        arrow_button_img = PhotoImage(file=arrow_button_image_path)
        arrow_button_button = Button(clinic_frame, image=arrow_button_img, borderwidth=0, bg='#D9D9D9', activebackground='#D9D9D9', command=lambda: self.show_doctors_callback(clinic['name']))
        arrow_button_button.image = arrow_button_img
        arrow_button_button.place(x=550, y=40)

        clinic_frame.image = Rectangle_for_clinic_img

    def display_clinics(self):
        clinics = self.fetch_clinic_data()
        for clinic in clinics:
            self.create_clinic_rectangle(clinic)


class ShowDoctors(Frame):
    def __init__(self, root, clinic_name):
        super().__init__(root, bg='white')
        self.root = root
        self.clinic_name = clinic_name
        self.setup_doctor_section()
        self.pack(fill=tk.BOTH, expand=True)

    def setup_doctor_section(self):
        # Create a frame to hold the heading label and the button
        heading_frame = Frame(self, bg='white')
        heading_frame.pack(anchor='w', padx=50, pady=30, fill=tk.X)

        # Heading label
        heading_label = tk.Label(heading_frame, text=f"Doctors at {self.clinic_name}", font=("Arial", 18, "bold"),
                                 bg='white')
        heading_label.pack(side=tk.LEFT)

        # Add Doctor button
        add_doctor_button_image_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\pictures_ManageDoc\Add Doctor.png"
        add_doctor_button_img = PhotoImage(file=add_doctor_button_image_path)
        add_doctor_button = Button(heading_frame, image=add_doctor_button_img, borderwidth=0, bg='white',
                                   activebackground='white', command=self.add_doctor)
        add_doctor_button.image = add_doctor_button_img
        add_doctor_button.pack(side=tk.RIGHT, padx=0)


        self.canvas = tk.Canvas(self, bg='white')
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(self, orient=tk.VERTICAL, command=self.canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))

        self.doctor_container = tk.Frame(self.canvas, bg='white')
        self.canvas.create_window((0, 0), window=self.doctor_container, anchor='nw')

        self.canvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

        self.display_doctors()

    def on_mouse_wheel(self, event):
        self.canvas.yview_scroll(-1 * int((event.delta / 120)), "units")

    def fetch_doctor_data(self):
        try:
            print(f"Fetching doctors for clinic: {self.clinic_name}")  # Debug statement
            doctors = database.child('Doctor').order_by_child('work_clinic').equal_to(self.clinic_name).get()
            if doctors.each():
                doctor_list = []
                for doctor in doctors.each():
                    doctor_info = doctor.val()
                    doctor_info['key'] = doctor.key()  # Add the key to the doctor info
                    doctor_list.append(doctor_info)
                return doctor_list
            else:
                print("No doctors found")  # Debug statement
                return []
        except Exception as e:
            print(f"Error fetching data: {e}")  # Debug statement
            messagebox.showerror("Error", f"Failed to fetch data: {e}")
            return []

# This function is on calendar, take the doctor_name and check in the database for this doctor appoitment date
    def fetch_appointment_dates(self, doctor_name):
        try:
            print(f"Fetching appointment dates for doctor: {doctor_name}")  # Debug statement
            appointments = database.child("Calendar").child(doctor_name).child("appointments").get()
            appointment_dates = []
            for appointment in appointments.each():
                appointment_info = appointment.val()
                appointment_dates.append(appointment_info['date_appointed'])
            print(f"Appointment dates: {appointment_dates}")  # Debug statement
            return appointment_dates
        except Exception as e:
            print(f"Error fetching appointment dates: {e}")  # Debug statement
            return []


    def show_doctor_detail(self, doctor):
        # Clear the current content
        for widget in self.root.winfo_children():
            widget.destroy()

        detail_frame = tk.Frame(self.root)
        detail_frame.pack(fill="both", expand=True)

        # Create two frames: one for labels and one for buttons
        labels_frame = tk.Frame(detail_frame)
        labels_frame.grid(row=0, column=0, padx=20, pady=20)

        buttons_frame = tk.Frame(detail_frame)
        buttons_frame.grid(row=0, column=1, padx=20, pady=20)

        # Add labels to the labels_frame
        dc_name_label = tk.Label(labels_frame, text=f"Dr. {doctor['dc_name']}", font=("Work Sans", 20, "bold"))
        dc_name_label.pack(anchor='w', pady=5)

        dc_specialty_label = tk.Label(labels_frame, text=f"Specialty: {doctor['dc_specialty']}",
                                      font=("Poppins", 12, "bold"))
        dc_specialty_label.pack(anchor='w', pady=5)

        dc_email_label = tk.Label(labels_frame, text=f"Email: {doctor['dc_email']}", font=("Work Sans", 12, "bold"))
        dc_email_label.pack(anchor='w', pady=5)

        dc_phone_label = tk.Label(labels_frame, text=f"Phone: {doctor['dc_phone']}", font=("Work Sans", 12, "bold"))
        dc_phone_label.pack(anchor='w', pady=5)
        

        def show_calendar():
            calendar = Calendar(buttons_frame,
                                selectmode='none',
                                year=2024, month=6,
                                font=('Arial', 30),
                                background='white',
                                foreground='black',
                                headersbackground='white',
                                headersforeground='black',
                                selectbackground='blue',
                                selectforeground='white')
            calendar.pack(pady=50)

            # Set the tag color to red for busy dates
            calendar.tag_config('busy', background='red', foreground='white')

            # Fetch and highlight appointment dates
            appointment_dates = self.fetch_appointment_dates(doctor['dc_name'])
            print(f"Appointment dates: {appointment_dates}")  # Debug statement
            for date in appointment_dates:
                try:
                    month, day, year = map(int, date.split('/'))
                    if not (1 <= month <= 12):
                        raise ValueError("Month must be in 1..12")
                    if not (1 <= day <= 31):
                        raise ValueError("Day must be in 1..31")
                    # Highlight the date on the calendar
                    calendar.calevent_create(datetime.date(year, month, day), 'Appointment', 'busy')
                except ValueError as e:
                    print(f"Error parsing date {date}: {e}")


        def fetch_user_details(username):
            try:
                user_ref = database.child('User').child(username)
                user_details = user_ref.get()
                if user_details:
                    return user_details.val()
                else:
                    return None
            except Exception as e:
                print(f"Error fetching user details: {e}")
                return None

        def assign_doctor():
            assign_window = tk.Toplevel(detail_frame)
            assign_window.title("Assign Doctor")

            # Create a calendar to show the doctor's busy dates
            calendar = Calendar(assign_window, selectmode='day', year=2024, month=6, day=17, font=('Arial', 20))
            calendar.pack(pady=20)

            # Set the tag color to red for busy dates
            calendar.tag_config('busy', background='red', foreground='white')

            # Fetch and highlight appointment dates
            appointment_dates = self.fetch_appointment_dates(doctor['dc_name'])
            print(f"Appointment dates: {appointment_dates}")  # Debug statement
            busy_dates = []
            for date in appointment_dates:
                try:
                    month, day, year = map(int, date.split('/'))
                    if not (1 <= month <= 12):
                        raise ValueError("Month must be in 1..12")
                    if not (1 <= day <= 31):
                        raise ValueError("Day must be in 1..31")
                    # Highlight the date on the calendar
                    calendar.calevent_create(datetime.date(year, month, day), 'Appointment', 'busy')
                    busy_dates.append(datetime.date(year, month, day))
                except ValueError as e:
                    print(f"Error parsing date {date}: {e}")

            # Automatically fill in the details
            appointment_address_label = tk.Label(assign_window, text="Appointment Address:")
            appointment_address_label.pack()
            appointment_address_entry = tk.Entry(assign_window)
            appointment_address_entry.pack()

            # Automatically get the current time for the appointment time
            current_time = datetime.datetime.now().time().strftime("%H:%M:%S")

            # Use the clinic name from the current doctor details
            clinic_name = doctor['work_clinic']

            # Use the doctor's ID and name from the current doctor details
            doctor_name = doctor['dc_name']
            doctor_id = doctor['key']  # Ensure this is correctly set when fetching doctor details

            user_id_label = tk.Label(assign_window, text="User ID:")
            user_id_label.pack()
            user_id_entry = tk.Entry(assign_window)
            user_id_entry.pack()

            details_label = tk.Label(assign_window, text="Details:")
            details_label.pack()
            details_entry = tk.Entry(assign_window)
            details_entry.pack()

            patient_name_label = tk.Label(assign_window, text="Patient Name:")
            patient_name_label.pack()
            patient_name_entry = tk.Entry(assign_window)
            patient_name_entry.pack()

            def assign_selected_date():
                selected_date = calendar.get_date()
                try:
                    selected_date = datetime.datetime.strptime(selected_date, '%m/%d/%y').date()
                    # Check if the selected date is a busy date
                    if selected_date in busy_dates:
                        messagebox.showerror("Error", "Doctor is busy on this date. Please select another date.")
                        return

                    # Get the appointment data from the admin
                    appointment_address = appointment_address_entry.get()
                    appointment_time = current_time  # Use the current time
                    user_id = user_id_entry.get()
                    user_name = patient_name_entry.get()

                    user_details = fetch_user_details(user_name)
                    if not user_details:
                        messagebox.showerror("Error", "User not found.")
                        return
                    details = details_entry.get()
                    patient_name = patient_name_entry.get()
                    status = False

                    # Create a new appointment in the database
                    appointment_data = {
                        "appointment_address": appointment_address,
                        "appointment_date": str(selected_date),
                        "appointment_time": appointment_time,
                        "clinic_Name": clinic_name,
                        "doctor_Name": doctor_name,
                        "doctor_id": doctor_id,
                        "status": status,
                        "user_id": user_id,
                        "user_name": user_name  # Add user name to the data
                    }
                    appointment_ref = database.child("Appointment").push(appointment_data)

                    # Add the appointment to the doctor's calendar
                    calendar_data = {
                        "date_appointed": selected_date.strftime('%m/%d/%Y'),
                        "details": details,
                        "patient_name": patient_name
                    }
                    database.child("Calendar").child(doctor_name).child("appointments").child(
                        selected_date.strftime('%Y-%m-%d')).set(calendar_data)

                    messagebox.showinfo("Success", f"Doctor assigned to {selected_date} successfully!")
                    assign_window.destroy()
                except Exception as e:
                    print(f"Error: Failed to assign doctor: {e}")
                    messagebox.showerror("Error", f"Failed to assign doctor: {e}")

            assign_button = tk.Button(assign_window, text="Assign Doctor", command=assign_selected_date)
            assign_button.pack(pady=10)

        # calendar_button = tk.Button(buttons_frame, text="Show Calendar", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
        #                             activebackground='white', command=show_calendar)
        # calendar_button.pack(pady=10)


        show_calendar()


        assign_button = tk.Button(buttons_frame, text="Assign Doctor", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                                  activebackground='white', command=assign_doctor)
        assign_button.pack(pady=10)

        # Add a button to go back to the doctor list
        back_button = tk.Button(buttons_frame, text="Back", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                                activebackground='white', command=lambda: self.show_doctor_list(detail_frame))
        back_button.pack(pady=10)



    def show_doctor_list(self, detail_frame):
        # Destroy the detail frame
        detail_frame.destroy()
        # Clear any remaining content in the root
        for widget in self.root.winfo_children():
            widget.destroy()
        # Reinitialize the doctor section
        self.setup_doctor_section()

    def display_doctors(self):
        doctors = self.fetch_doctor_data()
        for doctor in doctors:
            self.create_doctor_rectangle(doctor)


    def confirm_delete(self, doctor):
        confirm = messagebox.askyesno("Confirm Deletion",
                                      f"Do you want to delete Dr. {doctor['dc_name']} from the database?")
        if confirm:
            try:
                # Perform deletion from Firebase using the key
                database.child('Doctor').child(doctor['key']).remove()
                messagebox.showinfo("Success", f"Dr. {doctor['dc_name']} deleted successfully!")
                # Optionally update UI or refresh doctor list
                self.display_doctors()  # Refresh the doctor list after deletion
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete Dr. {doctor['dc_name']}: {e}")


    def add_doctor(self):
        # Clear existing widgets in doctor_container frame
        for widget in self.doctor_container.winfo_children():
            widget.destroy()

        # Helper function to create labeled entry fields
        def create_labeled_entry(parent, label_text, show=None):
            frame = tk.Frame(parent)
            frame.pack(fill='x', padx=10, pady=5)
            label = tk.Label(frame, text=label_text)
            label.pack(side='left')
            entry = tk.Entry(frame, show=show)
            entry.pack(side='left', fill='x', expand=True, padx=10)
            return entry

        # Form fields
        name_entry = create_labeled_entry(self.doctor_container, "Doctor Name:")
        email_entry = create_labeled_entry(self.doctor_container, "Doctor Email:")
        password_entry = create_labeled_entry(self.doctor_container, "Doctor Password:", show="*")
        confirm_password_entry = create_labeled_entry(self.doctor_container, "Confirm Password:", show="*")
        phone_entry = create_labeled_entry(self.doctor_container, "Doctor Phone:")
        specialty_entry = create_labeled_entry(self.doctor_container, "Doctor Specialty:")

        # Clinic name (disabled entry)
        clinic_frame = tk.Frame(self.doctor_container)
        clinic_frame.pack(fill='x', padx=10, pady=5)
        tk.Label(clinic_frame, text="Clinic Name:").pack(side='left')
        clinic_entry = tk.Entry(clinic_frame, state='disabled')
        clinic_entry.insert(0, self.clinic_name)
        clinic_entry.pack(side='left', fill='x', expand=True, padx=10)

        def is_valid_email(email):
            return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))

        def save_doctor():
            # Retrieve data from entries
            dc_name = name_entry.get()
            dc_email = email_entry.get()
            dc_password = password_entry.get()
            dc_confirm_password = confirm_password_entry.get()
            dc_phone = phone_entry.get()
            dc_specialty = specialty_entry.get()
            work_clinic = self.clinic_name

            # Validate if all fields are filled
            if not all([dc_name, dc_email, dc_password, dc_confirm_password, dc_phone, dc_specialty]):
                messagebox.showwarning("Incomplete Data", "Please fill in all fields.")
                return

            if not is_valid_email(dc_email):
                messagebox.showerror("Error", "Invalid email address format.")
                return

            if dc_password != dc_confirm_password:
                messagebox.showerror("Error", "Passwords do not match.")
                return

            if not dc_phone.isdigit() or not (10 <= len(dc_phone) <= 11):
                messagebox.showerror("Error", "Invalid phone number format.")
                return

            # Generate a unique key for the doctor
            dc_id = ''.join([str(random.randint(0, 9)) for _ in range(12)])

            try:
                # Save doctor data to Firebase
                database.child("Doctor").child(dc_id).set({
                    'dc_name': dc_name,
                    'dc_email': dc_email,
                    'dc_password': dc_password,
                    'dc_phone': dc_phone,
                    'dc_specialty': dc_specialty,
                    'work_clinic': work_clinic
                })
                messagebox.showinfo("Success", "Doctor added successfully!")
                self.display_doctors()  # Refresh the doctor list after addition
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add doctor: {e}")

        save_button = tk.Button(self.doctor_container, text="Save", command=save_doctor)
        save_button.pack(padx=10, pady=10)


    def create_doctor_rectangle(self, doctor):
        doctor_frame = tk.Frame(self.doctor_container, bg='white')
        doctor_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_doctor_path = r"C:\Users\ACER\Documents\Sem 2 - Software-Engineer\Assignment\Software-Engineer--main\Admin_page_ver1\pythonProject\images\pictures_ManageDoc\Doctor.png"
        Rectangle_for_doctor_img = PhotoImage(file=Rectangle_for_doctor_path)

        canvas = tk.Canvas(doctor_frame, width=Rectangle_for_doctor_img.width(), height=Rectangle_for_doctor_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_doctor_img)

        name_label = tk.Label(canvas, text=f"Dr. {doctor['dc_name']}", font=("Work Sans", 15, "bold"), bg='#D9D9D9')
        canvas.create_window(20, 2, anchor='nw', window=name_label)

        specialty_label = tk.Label(doctor_frame, text=f"Specialty: {doctor['dc_specialty']}", font=("Poppins", 12), bg='#D9D9D9')
        specialty_label.place(x=20, y=35)

        email_label = tk.Label(doctor_frame, text=f"Doctor Email: {doctor['dc_email']}", font=("Work Sans", 12, "bold"), bg='#E3E2FD')
        email_label.place(x=20, y=80)

        PhoneNum_label = tk.Label(doctor_frame, text=f"Doctor Contact: {doctor['dc_phone']} ", font=("Work Sans", 12, "bold"), bg='#E3E2FD')
        PhoneNum_label.place(x=20, y=100)

        delete_label = Button(doctor_frame, text=f" Delete ", font=("Work Sans", 12, "bold"), bg='#E3E2FD', activebackground='white',
                              command=lambda d=doctor: self.confirm_delete(d))
        delete_label.place(x=20, y=130)

        detail_label = Button(doctor_frame, text=f" Detail ", font=("Work Sans", 12, "bold"), bg='#E3E2FD', activebackground='white', command=lambda d=doctor: self.show_doctor_detail(d))
        detail_label.place(x=240, y=130)

        doctor_frame.image = Rectangle_for_doctor_img





if __name__ == "__main__":
    root = Tk()
    root.title("Clinic Management")
    root.geometry('1331x594')  # Adjusted width to accommodate navigation section
    root.configure(bg="#fff")
    root.resizable(False, False)

    app = ClinicApp(root)
    root.mainloop()
