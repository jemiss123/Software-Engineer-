# User forgot password page
# After user enter the correct username, and email, will show this reset password page, and both the password provide must be the same

from tkinter import *
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from firebase_config import database


# concept: check with username and email address with database
# If successful, jump to reset password page, else showing error
# Jump to here ↓


class ResetPasswordPage:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)

        # Store references to PhotoImage objects
        self.images = {}

        # Load and resize the signup image
        self.images['signup_img'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/register picture.png').resize((598, 594),
                                                                                               Image.Resampling.LANCZOS))
        signup_image_label = Label(self.frame, image=self.images['signup_img'], bg='white')
        signup_image_label.place(x=0, y=0)

        # Frame for ResetPassword Page
        resetPassword_frame = Frame(self.frame, width=450, height=550, bg='white')
        resetPassword_frame.place(x=600, y=30)

        # Load and resize the reset password title image
        self.images['resetPassword_img'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/Reset Password.png').resize((300, 40),
                                                                                             Image.Resampling.LANCZOS))
        self.images['entryfield_img'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/entryfield.png').resize((350, 50),
                                                                                         Image.Resampling.LANCZOS))

        resetPassword_title = Label(resetPassword_frame, image=self.images['resetPassword_img'], bg='white')
        resetPassword_title.place(x=70, y=20)

        self.images['password1_img'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/password text.png').resize((70, 15),
                                                                                            Image.Resampling.LANCZOS))

        self.images['show_photo'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/showpassword.png').resize((20, 20),
                                                                                           Image.Resampling.LANCZOS))
        self.images['hide_photo'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/showpassword.png').resize((20, 20),
                                                                                           Image.Resampling.LANCZOS))

        # Create a Canvas widget to place the image and entry field for Password 1
        password1_canvas = Canvas(self.frame, width=350, height=50, bg='white', highlightthickness=0)
        password1_canvas.create_image(0, 0, anchor=NW, image=self.images['entryfield_img'])
        password1_canvas.place(x=650, y=220)

        # Create the Password 1 entry field and place it over the image on the canvas
        self.password1_entry = Entry(self.frame, width=20, fg='black', border=0, bg='#ffffff',
                                     font=('New Times Roman', 14), show='*')
        self.password1_entry.place(x=670, y=230)  # Adjust the position to align with the image

        # Place the Password 1 text image on top of the entry field
        password1_text_label = Label(self.frame, image=self.images['password1_img'], bg='white')
        password1_text_label.place(x=650, y=200)  # Adjust the position to align with the entry field

        self.images['password2_img'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/ConfirmPassword.png').resize((100, 15),
                                                                                              Image.Resampling.LANCZOS))

        # Create a Canvas widget to place the image and entry field for Password 2
        password2_canvas = Canvas(self.frame, width=350, height=50, bg='white', highlightthickness=0)
        password2_canvas.create_image(0, 0, anchor=NW, image=self.images['entryfield_img'])
        password2_canvas.place(x=650, y=320)

        # Create the Password 2 entry field and place it over the image on the canvas
        self.password2_entry = Entry(self.frame, width=20, fg='black', border=0, bg='#ffffff',
                                     font=('New Times Roman', 14), show='*')
        self.password2_entry.place(x=670, y=330)  # Adjust the position to align with the image

        # Place the Password 2 text image on top of the entry field
        enter_password2_label = Label(self.frame, image=self.images['password2_img'], bg='white')
        enter_password2_label.place(x=650, y=300)  # Adjust the position to align with the entry field

        def toggle_password1():
            if self.password1_entry.cget('show') == '':
                self.password1_entry.config(show='*')
                toggle_button1.config(image=self.images['show_photo'])
            else:
                self.password1_entry.config(show='')
                toggle_button1.config(image=self.images['hide_photo'])

            # Create the toggle button with the show image

        toggle_button1 = Button(self.frame, image=self.images['show_photo'], command=toggle_password1,
                                borderwidth=0, bg='white', activebackground='white')
        toggle_button1.place(x=970, y=230)  # Adjust position as needed

        def toggle_password2():
            if self.password2_entry.cget('show') == '':
                self.password2_entry.config(show='*')
                toggle_button1.config(image=self.images['show_photo'])
            else:
                self.password2_entry.config(show='')
                toggle_button1.config(image=self.images['hide_photo'])

        # Create the toggle button with the show image
        toggle_button2 = Button(self.frame, image=self.images['show_photo'], command=toggle_password2,
                                borderwidth=0, bg='white', activebackground='white')
        toggle_button2.place(x=970, y=330)  # Adjust position as needed

        # Load and resize the confirm button image
        self.images['confirm_button_img'] = ImageTk.PhotoImage(
            Image.open('pictures/Login and Registration Pictures/Confirm.png').resize((250, 50),
                                                                                      Image.Resampling.LANCZOS))

        # Create the confirm button with the image and white background
        confirm_button = Button(resetPassword_frame, image=self.images['confirm_button_img'],
                                command=self.handle_checking_data,
                                borderwidth=0, bg='white', activebackground='white')
        confirm_button.place(x=90, y=440)

        # Back to log in button on ResetPassword Page
        back_to_login = Button(resetPassword_frame, text="Already have an account?", border=0, fg='black', bg='white',
                               cursor='hand2', font=("New Times Roman", 11, "bold"),
                               command=lambda: self.app.show_page("login"))
        back_to_login.place(x=120, y=500)

        # Clear entry fields initially
        self.clear_entry_fields()

    def handle_checking_data(self):
        username = self.app.get_shared_data("username")

        c1 = self.password1_entry.get()
        c2 = self.password2_entry.get()

        if any(value == "" for value in [c1, c2]):
            messagebox.showerror("Error", "All fields are required")
        elif c1 != c2:
            messagebox.showerror("Error", "Both passwords must match")
        else:
            database.child("User").child(username).child("password").set(c1)
            messagebox.showinfo("Success", "Password updated successfully")
            self.app.show_page("login")
            self.clear_entry_fields()  # Clear fields after successful update

    def clear_entry_fields(self):
        # Clear entry fields
        self.password1_entry.delete(0, 'end')
        self.password2_entry.delete(0, 'end')
