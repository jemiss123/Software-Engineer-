# Doctor view patient record
# able to view previous prescription of that user and able to make modify on the medical and instructions

import tkinter as tk
from tkinter import *
from doctor.sidebar import Sidebar
from firebase_config import database
from PIL import Image, ImageTk


class DoctorViewPatientRecord:
    def __init__(self, app, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.dc_name = dc_name
        self.image_references = []  # To hold image references
        self.view_prescription()
        self.edit_mode = False

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

    def view_prescription(self):
        self.view_prescriptions_frame = tk.Frame(self.frame, bg='white')
        self.view_prescriptions_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=50)

        heading_label = Label(self.view_prescriptions_frame, text="Patient Prescription Records",
                              font=("Arial", 18, "bold"), bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas_prescription = tk.Canvas(self.view_prescriptions_frame, bg='white')
        self.canvas_prescription.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar_prescription = tk.Scrollbar(self.view_prescriptions_frame, orient=tk.VERTICAL,
                                              command=self.canvas_prescription.yview)
        scrollbar_prescription.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas_prescription.configure(yscrollcommand=scrollbar_prescription.set)
        self.canvas_prescription.bind('<Configure>', lambda e: self.canvas_prescription.configure(
            scrollregion=self.canvas_prescription.bbox('all')))

        self.view_prescriptions_container = tk.Frame(self.canvas_prescription, bg='white')
        self.canvas_prescription.create_window((0, 0), window=self.view_prescriptions_container, anchor='nw')

        # Update the bind event to handle different operating systems
        self.canvas_prescription.bind_all("<MouseWheel>", self.on_mouse_wheel_prescription)

        self.display_prescriptions()

    def on_mouse_wheel_prescription(self, event):
        if event.num == 4 or event.delta > 0:
            self.canvas_prescription.yview_scroll(-1, "units")
        elif event.num == 5 or event.delta < 0:
            self.canvas_prescription.yview_scroll(1, "units")

    def fetch_prescription_data(self):
        try:
            prescriptions_snapshot = database.child('Prescription').get()
            if prescriptions_snapshot.each():
                # Convert snapshot to list of dictionaries
                prescriptions_list = [prescription.val() for prescription in prescriptions_snapshot.each()]
                # Filter prescriptions by the doctor_Name
                matching_prescriptions = [prescription for prescription in prescriptions_list if
                                          prescription.get('doctor_name') == self.dc_name]
                return prescriptions_snapshot, matching_prescriptions  # Return the list of matching prescriptions along with the snapshot
            else:
                return [], []  # Return an empty list if there are no prescriptions
        except Exception as e:
            print(f"Failed to fetch prescription data: {e}")
            return [], []

    def create_view_prescription_rectangle(self, prescription, key):
        prescription_frame = tk.Frame(self.view_prescriptions_container, bg='white')
        prescription_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_clinic_path = "pictures/Search Clinic Page/Rectangle.png"
        Rectangle_for_clinic_img = ImageTk.PhotoImage(
            Image.open(Rectangle_for_clinic_path).resize((600, 250), Image.LANCZOS))
        self.image_references.append(Rectangle_for_clinic_img)

        canvas = tk.Canvas(prescription_frame, width=Rectangle_for_clinic_img.width(),
                           height=Rectangle_for_clinic_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        appointment_date = prescription.get("appointment_date", "N/A")
        appointment_time = prescription.get("appointment_time", "N/A")
        appointment_date_label = tk.Label(canvas,
                                          text=f"{appointment_date} {appointment_time} | {prescription.get('clinic_name', 'N/A')}",
                                          font=("Work Sans", 16, "bold"),
                                          bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=appointment_date_label)

        patient_name_label = tk.Label(prescription_frame, text=f"Patient Name: {prescription.get('user_name', 'N/A')}",
                                      font=("Arial", 12),
                                      bg='#D9D9D9')
        patient_name_label.place(x=20, y=50)

        patient_email_label = tk.Label(prescription_frame,
                                       text=f"Patient Email: {prescription.get('user_email', 'N/A')}",
                                       font=("Arial", 12), bg='#D9D9D9')
        patient_email_label.place(x=20, y=80)

        patient_phone_label = tk.Label(prescription_frame,
                                       text=f"Patient Contact Number: {prescription.get('user_phone', 'N/A')}",
                                       font=("Arial", 12), bg='#D9D9D9')
        patient_phone_label.place(x=20, y=110)

        desc_problem_label = tk.Label(prescription_frame,
                                      text=f"Describe problems: {prescription.get('desc_problem', 'N/A')}",
                                      font=("Arial", 12), bg='#D9D9D9')
        desc_problem_label.place(x=20, y=140)

        medications_label = tk.Label(prescription_frame,
                                     text=f"Medications Given:",
                                     font=("Arial", 12), bg='#D9D9D9')
        medications_label.place(x=20, y=170)

        instructions_label = tk.Label(prescription_frame,
                                      text=f"Instructions:",
                                      font=("Arial", 12), bg='#D9D9D9')
        instructions_label.place(x=20, y=200)

        # Medications entry
        medications_entry = tk.Entry(prescription_frame, font=("Arial", 12), bg='#D9D9D9', width=50)
        medical = prescription.get('medications', 'N/A')
        medications_entry.insert(0, medical)
        medications_entry.place(x=170, y=170, width=300)
        medications_entry.config(state='disabled')  # Disable after inserting text

        # Instructions entry
        instructions_entry = tk.Entry(prescription_frame, font=("Arial", 12), bg='#D9D9D9', width=50)
        instructions = prescription.get('instructions', 'N/A')
        instructions_entry.insert(0, instructions)
        instructions_entry.place(x=170, y=200, width=300)
        instructions_entry.config(state='disabled')  # Disable after inserting text

        edit_button = tk.Button(prescription_frame, text="Edit", font=("Arial", 12, "underline"), bg='#D9D9D9',
                                command=lambda: self.enable_edit_mode(medications_entry, instructions_entry,
                                                                      prescription, edit_button, key),
                                borderwidth=0, activebackground='white')
        edit_button.place(x=480, y=10)  # Adjust the position as needed

    def display_prescriptions(self):
        snapshots, prescriptions = self.fetch_prescription_data()
        if not prescriptions:
            # Handle no prescription data scenario
            no_prescription_label = tk.Label(self.view_prescriptions_frame, text="No prescription data found",
                                             font=("Arial", 12),
                                             bg='white')
            no_prescription_label.pack(pady=50)
        else:
            for i, prescription in enumerate(prescriptions):
                key = snapshots[i].key()
                self.create_view_prescription_rectangle(prescription, key)

    def enable_edit_mode(self, medications_entry, instructions_entry, prescription, edit_button, key):
        # Enable editing of Medications and Instructions fields
        self.edit_mode = True
        medications_entry.config(state='normal')  # Enable editing
        instructions_entry.config(state='normal')  # Enable editing

        # Change Edit button functionality to Save Changes
        edit_button.config(text="Save Changes",
                           command=lambda: self.save_changes(medications_entry, instructions_entry, prescription,
                                                             edit_button, key))

    def save_changes(self, medications_entry, instructions_entry, prescription, edit_button, key):
        # Retrieve the updated medications and instructions from the Entry widgets
        updated_medications = medications_entry.get()
        updated_instructions = instructions_entry.get()

        # Update the prescription dictionary with new values
        prescription['medications'] = updated_medications
        prescription['instructions'] = updated_instructions

        # Update the database with the new values
        updated_data = {
            'medications': updated_medications,
            'instructions': updated_instructions
        }

        database.child("Prescription").child(key).update(updated_data)

        # Disable editing mode after saving changes
        self.edit_mode = False
        medications_entry.config(state='disabled')
        instructions_entry.config(state='disabled')

        # Change Save Changes button back to Edit
        edit_button.config(text="Edit",
                           command=lambda: self.enable_edit_mode(medications_entry, instructions_entry, prescription,
                                                                 edit_button, key))
