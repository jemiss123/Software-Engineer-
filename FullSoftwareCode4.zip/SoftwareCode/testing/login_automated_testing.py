from unittest import TestCase, mock
from user_handle_login_pages.login import LoginPage
import unittest

class TestLoginPage(TestCase):

    def setUp(self):
        # Mock the database for testing purposes
        self.mock_database = mock.Mock()

        # Example setup for login_page, passing mock database
        self.app = mock.Mock()
        self.login_page = LoginPage(self.app)

    def test_correct_login(self):
        # Simulate correct login scenario
        username = "testuser"
        password = "testpassword"

        # Mock the database response for the test user
        self.mock_database.child.return_value.get.return_value.each.return_value = [
            mock.Mock(val=lambda: {"username": username, "password": password})
        ]

        # Your test assertions here

    def test_incorrect_password(self):
        # Simulate incorrect password scenario
        username = "testuser"
        correct_password = "testpassword"
        incorrect_password = "wrongpassword"

        # Mock the database response for the test user
        self.mock_database.child.return_value.get.return_value.each.return_value = [
            mock.Mock(val=lambda: {"username": username, "password": correct_password})
        ]

        # Your test assertions here

    def test_missing_fields(self):
        # Simulate missing username or password scenario
        username = "testuser"
        password = "testpassword"

        # Example setup for missing fields test
        self.login_page.email_entry.insert(0, username)  # Assuming email_entry is an entry widget in LoginPage

        # Call the handle_login method (simulate button click)
        self.login_page.handle_login()

        # Assert that error message was shown for missing fields
        self.assertTrue(self.login_page.show_error.called)

    def test_username_not_found(self):
        # Simulate username not found scenario
        username = "nonexistentuser"
        password = "testpassword"

        # Mock the database response for no users found
        self.mock_database.child.return_value.get.return_value.each.return_value = []

        # Your test assertions here

if __name__ == "__main__":
    unittest.main()
