import unittest
from unittest.mock import MagicMock
from datetime import date, datetime
from tkinter import Tk  # Mocking tkinter

from user_home_pages.booking import Booking


class TestBooking(unittest.TestCase):

    def setUp(self):
        # Set up a mock App instance (assuming your app structure)
        self.app = MagicMock()
        self.app.root = Tk()
        self.app.get_shared_data.return_value = "mocked_value"

        # Initialize the Booking instance with mocked parameters
        self.booking = Booking(self.app, "mock_username", "mock_name", "mock_dc_name")

    def tearDown(self):
        # Clean up after each test if needed
        pass

    def test_initialization(self):
        # Test initialization of Booking instance
        self.assertIsInstance(self.booking, Booking)
        self.assertEqual(self.booking.selected_date, None)
        self.assertEqual(self.booking.selected_time, None)
        self.assertEqual(self.booking.selected_doctor, None)

    def test_get_clinic_data(self):
        # Mock the database interaction and test the retrieval of clinic data
        self.booking.get_clinic_data = MagicMock(return_value={"name": "Mock Clinic"})
        clinic_data = self.booking.get_clinic_data("Mock Clinic")
        self.assertEqual(clinic_data["name"], "Mock Clinic")

    def test_fetch_appointment_dates(self):
        # Mock the database interaction and test fetching appointment dates
        self.booking.fetch_appointment_dates = MagicMock(return_value=["2024-06-25", "2024-06-28"])
        appointment_dates = self.booking.fetch_appointment_dates("mock_doctor_name")
        self.assertEqual(appointment_dates, ["2024-06-25", "2024-06-28"])

    # Assuming this is part of your test class TestBooking
    def test_set_date(self):
        # Mock required attributes and test setting a date
        self.booking.selected_time = "10:00"
        self.booking.selected_doctor = "mock_doctor_name"
        self.booking.doctor_id = "123456789123"

        # Mock desc_entry correctly
        self.booking.desc_entry = MagicMock()
        self.booking.desc_entry.get.return_value = "Mock description"

        self.booking.show_info = MagicMock()  # Mocking the messagebox.showinfo method
        self.booking.database = MagicMock()  # Mocking the database interaction

        # Call the set_date method
        self.booking.set_date()

        # Assertions to verify if the appointment data is pushed to the database
        self.assertTrue(self.booking.database.child("Appointment").push)

    # Add more test cases as needed


if __name__ == '__main__':
    unittest.main()

