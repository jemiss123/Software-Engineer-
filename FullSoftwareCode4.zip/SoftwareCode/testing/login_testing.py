import unittest
from unittest.mock import patch, MagicMock
from tkinter import Tk
from tkinter import messagebox
from user_handle_login_pages.login import LoginPage  # Assuming LoginPage implementation
from firebase_config import database  # Assuming database access implementation


class TestLoginPage(unittest.TestCase):
    def setUp(self):
        self.app = MagicMock()
        self.root = Tk()
        self.root.withdraw()  # Hide the root window during tests
        self.login_page = LoginPage(self.app)  # Initialize LoginPage instance
        self.login_page.email_entry = MagicMock()
        self.login_page.password_entry = MagicMock()
        self.login_page.clear_entry_fields = MagicMock()

    def tearDown(self):
        self.root.destroy()  # Clean up the root window after each test

    @patch("user_handle_login_pages.login.database")
    def test_handle_login_success(self, mock_database):
        # Mock database response for successful login
        mock_database.child().get().each.return_value = [
            MagicMock(val=lambda: {"username": "testuser", "password": "testpassword"})
        ]

        # Set mock return values for email and password entries
        self.login_page.email_entry.get.return_value = "testuser"
        self.login_page.password_entry.get.return_value = "testpassword"

        with patch.object(self.app, 'set_shared_data') as mock_set_shared_data, \
             patch.object(self.app, 'show_page') as mock_show_page, \
             patch.object(messagebox, 'showerror') as mock_showerror:

            self.login_page.handle_login()  # Call the method under test

            # Assertions
            mock_set_shared_data.assert_called_once_with("username", "testuser")
            mock_show_page.assert_called_once_with("home", username="testuser")
            self.login_page.clear_entry_fields.assert_called_once()
            mock_showerror.assert_not_called()  # Ensure showerror was not called

    @patch("user_handle_login_pages.login.database")
    def test_handle_login_wrong_password(self, mock_database):
        # Mock database response for a valid user with incorrect password
        mock_database.child().get().each.return_value = [
            MagicMock(val=lambda: {"username": "testuser", "password": "testpassword"})
        ]

        # Set mock return values for email and password entries
        self.login_page.email_entry.get.return_value = "testuser"
        self.login_page.password_entry.get.return_value = "wrongpassword"

        with patch.object(self.app, 'set_shared_data') as mock_set_shared_data, \
             patch.object(self.app, 'show_page') as mock_show_page, \
             patch.object(messagebox, 'showerror') as mock_showerror:

            self.login_page.handle_login()  # Call the method under test

            # Assertions
            mock_set_shared_data.assert_not_called()
            mock_show_page.assert_not_called()
            self.login_page.clear_entry_fields.assert_not_called()
            mock_showerror.assert_called_once_with("Error", "Wrong password entered")

    @patch("user_handle_login_pages.login.database")
    def test_handle_login_user_not_found(self, mock_database):
        # Mock database response for no user found
        mock_database.child().get().each.return_value = []

        # Set mock return values for email and password entries
        self.login_page.email_entry.get.return_value = "nonexistentuser"
        self.login_page.password_entry.get.return_value = "somepassword"

        with patch.object(self.app, 'set_shared_data') as mock_set_shared_data, \
             patch.object(self.app, 'show_page') as mock_show_page, \
             patch.object(messagebox, 'showerror') as mock_showerror:

            self.login_page.handle_login()  # Call the method under test

            # Assertions
            mock_set_shared_data.assert_not_called()
            mock_show_page.assert_not_called()
            self.login_page.clear_entry_fields.assert_not_called()
            mock_showerror.assert_called_once_with("Error", "Username not found")


if __name__ == "__main__":
    unittest.main()

