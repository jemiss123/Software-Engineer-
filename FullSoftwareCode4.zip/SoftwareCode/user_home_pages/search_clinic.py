# User search clinic
# - able to show all the clinic

import tkinter as tk
from tkinter import *
from tkinter import messagebox
from user_home_pages.sidebar import Sidebar
from firebase_config import database


class SearchClinic:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = None
        self.image_references = []  # To hold image references
        self.setup_clinic_section()

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

    def setup_clinic_section(self):
        self.request_record_frame = tk.Frame(self.frame, bg='white')
        self.request_record_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=50)

        heading_label = tk.Label(self.request_record_frame, text="Clinic Available", font=("Arial", 18, "bold"),
                                 bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas_search_Clinic = tk.Canvas(self.request_record_frame, bg='white')
        self.canvas_search_Clinic.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar_search_clinic = tk.Scrollbar(self.request_record_frame, orient=tk.VERTICAL,
                                               command=self.canvas_search_Clinic.yview)
        scrollbar_search_clinic.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas_search_Clinic.configure(yscrollcommand=scrollbar_search_clinic.set)
        self.canvas_search_Clinic.bind('<Configure>', lambda e: self.canvas_search_Clinic.configure(
            scrollregion=self.canvas_search_Clinic.bbox('all')))

        self.clinic_container = tk.Frame(self.canvas_search_Clinic, bg='white')
        self.canvas_search_Clinic.create_window((0, 0), window=self.clinic_container, anchor='nw')

        self.canvas_search_Clinic.bind_all("<MouseWheel>", self.on_mouse_wheel_search_clinic)

        self.display_clinics()

    def on_mouse_wheel_search_clinic(self, event):
        if event.num == 4 or event.delta > 0:
            self.canvas_search_Clinic.yview_scroll(-1, "units")
        elif event.num == 5 or event.delta < 0:
            self.canvas_search_Clinic.yview_scroll(1, "units")

    def fetch_clinic_data(self):
        try:
            clinics = database.child('Clinic').get()
            if clinics.each():
                return [clinic.val() for clinic in clinics.each()]
            else:
                return []
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data: {e}")
            return []

    def display_clinics(self):
        clinics = self.fetch_clinic_data()
        for clinic in clinics:
            self.create_clinic_rectangle(clinic)

    def create_clinic_rectangle(self, clinic):
        clinic_frame = tk.Frame(self.clinic_container, bg='black')
        clinic_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_clinic_path = 'pictures/Search Clinic Page/Rectangle.png'
        Rectangle_for_clinic_img = PhotoImage(file=Rectangle_for_clinic_path)
        self.image_references.append(Rectangle_for_clinic_img)

        canvas = tk.Canvas(clinic_frame, width=Rectangle_for_clinic_img.width(),
                           height=Rectangle_for_clinic_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        clinic_name = clinic['name']
        name_label = tk.Label(canvas, text=f"{clinic_name}", font=("Work Sans", 16, "bold"), bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=name_label)

        review_label = tk.Label(clinic_frame, text=f"Review: {clinic['Review']}", font=("Arial", 12), bg='#D9D9D9')
        review_label.place(x=20, y=50)

        time_label = tk.Label(clinic_frame, text=f"Operating Hours:\n{clinic['open_time']} - {clinic['close_time']}",
                              font=("Work Sans", 14, "bold"), bg='#D9D9D9')
        time_label.place(x=300, y=40)

        status_label = tk.Label(clinic_frame, text=f"Status: {clinic['status']}", font=("Arial", 12), bg='#D9D9D9')
        status_label.place(x=20, y=70)

        arrow_button_image_path = 'pictures/Search Clinic Page/Vector.png'
        arrow_button_img = PhotoImage(file=arrow_button_image_path)
        self.image_references.append(arrow_button_img)

        def show_clinic_page():
            self.app.set_shared_data("name", clinic_name)
            self.app.show_page("view_clinic", name=clinic_name)

        arrow_button_button = Button(clinic_frame, image=arrow_button_img, borderwidth=0, bg='#D9D9D9',
                                     activebackground='#D9D9D9', command=show_clinic_page)
        arrow_button_button.image = arrow_button_img
        arrow_button_button.place(x=550, y=40)


