# firebase_config.py

import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyDiA5rKfit9LXKrh35bgQCTqpGi5J2vSUA",
    "authDomain": "softwareass-da7ac.firebaseapp.com",
    "databaseURL": "https://softwareass-da7ac-default-rtdb.firebaseio.com",
    "projectId": "softwareass-da7ac",
    "storageBucket": "softwareass-da7ac.appspot.com",
    "messagingSenderId": "336658277230",
    "appId": "1:336658277230:web:254e782d894509d680577f",
    "measurementId": "G-T2BN7W9TXT"
}

firebase = pyrebase.initialize_app(firebaseConfig)
database = firebase.database()

'''
  apiKey: "AIzaSyDiA5rKfit9LXKrh35bgQCTqpGi5J2vSUA",
  authDomain: "softwareass-da7ac.firebaseapp.com",
  projectId: "softwareass-da7ac",
  storageBucket: "softwareass-da7ac.appspot.com",
  messagingSenderId: "336658277230",
  appId: "1:336658277230:web:254e782d894509d680577f",
  measurementId: "G-T2BN7W9TXT"
  databaseURL: "https://softwareass-da7ac-default-rtdb.firebaseio.com"
'''

'''
# original
    "apiKey": "AIzaSyDH92FCT2_eZozopA67rE6giVtNtPJEzxw",
    "authDomain": "pythontkinter-91f78.firebaseapp.com",
    "databaseURL": "https://pythontkinter-91f78-default-rtdb.firebaseio.com",
    "projectId": "pythontkinter-91f78",
    "storageBucket": "pythontkinter-91f78.appspot.com",
    "messagingSenderId": "483196256806",
    "appId": "1:483196256806:web:27ac629ed5050e6c759ce7",
    "measurementId": "G-VENQ3J95XH"
'''