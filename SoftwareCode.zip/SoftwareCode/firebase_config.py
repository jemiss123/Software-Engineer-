# firebase_config.py

import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyDiA5rKfit9LXKrh35bgQCTqpGi5J2vSUA",
    "authDomain": "softwareass-da7ac.firebaseapp.com",
    "databaseURL": "https://softwareass-da7ac-default-rtdb.firebaseio.com",
    "projectId": "softwareass-da7ac",
    "storageBucket": "softwareass-da7ac.appspot.com",
    "messagingSenderId": "336658277230",
    "appId": "1:336658277230:web:254e782d894509d680577f",
    "measurementId": "G-T2BN7W9TXT"
}

firebase = pyrebase.initialize_app(firebaseConfig)
database = firebase.database()
