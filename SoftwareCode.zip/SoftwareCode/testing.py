for idx, doctor in enumerate(doctor):
    # Determine which canvas to use
    canvas = canvas1 if idx % 2 == 0 else canvas2
    # Doctor details labels on canvas1
    doctor_name = doctor.get("dc_name", "N/A").title()
    name_label = tk.Label(canvas, text=f"Dr. {doctor_name}", font=("Work Sans", 16, "bold"), bg='#D9D9D9')
    canvas.create_window(20, 10 + (idx // 2) * 260, anchor='nw', window=name_label)

    specialty_label = tk.Label(canvas, text=f"Specialty: {doctor.get('dc_specialty', 'N/A')}",
                               font=("Arial", 12), bg='#D9D9D9')
    canvas.create_window(20, 50 + (idx // 2) * 260, anchor='nw', window=specialty_label)

    email_label = tk.Label(canvas, text=f"Email: {doctor.get('dc_email', 'N/A')}", font=("Arial", 12),
                           bg='#D9D9D9')
    canvas.create_window(20, 74 + (idx // 2) * 260, anchor='nw', window=email_label)

    clinic_name = doctor.get('work_clinic', 'N/A')
    clinic_label = tk.Label(canvas, text=f"Working Clinic: {clinic_name}", font=("Arial", 12), bg='#D9D9D9')
    canvas.create_window(20, 98 + (idx // 2) * 260, anchor='nw', window=clinic_label)

    # Description text widget on canvas1
    desc_text = tk.Text(canvas, width=30, height=5, font=("Arial", 13), bg='#D9D9D9', wrap=tk.WORD, bd=0)
    desc_text.insert(tk.END, f"Description: \n{doctor.get('work_desc', 'N/A')}")
    desc_text.config(state=tk.DISABLED)  # Make the text widget read-only
    canvas.create_window(20, 130 + (idx // 2) * 260, anchor='nw', window=desc_text)


    # Bind click event to open doctor's booking page
    def show_clinic_page(event):
        self.app.set_shared_data("dc_name", doctor_name)
        self.app.set_shared_data("name", clinic_name)
        self.app.show_page("view_doctor_booking")


    canvas.tag_bind(name_label, '<Button-1>', show_clinic_page)