from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
from tkinter import ttk
from pathlib import Path
from firebase_config import database
from admin.sidebar import Sidebar


class ManageRequest:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)  # Replace Sidebar with your Sidebar class
        self.sidebar.pack(side='left', fill='y')

        # Function to show a dialog box for status change
        def change_status_dialog(item):
            result = messagebox.askquestion(
                "Change Status",
                "Do you want to accept or reject this request?",
                icon='question'
            )

            if result == 'yes':
                result = messagebox.askyesnocancel(
                    "Select Action",
                    "Do you want to Accept?",
                    icon='question'
                )
                if result is True:
                    tree.set(item, "Status", "Accepted")
                    update_status_in_db(item, True)
                elif result is False:
                    tree.set(item, "Status", "Rejected")
                    update_status_in_db(item, False)
                else:
                    pass  # User cancelled

        # Update status in the database
        def update_status_in_db(item, status):
            try:
                item_values = tree.item(item, 'values')
                appointment_date = item_values[0]
                appointment_time = item_values[1]

                # Find the correct record in the database and update it
                appointments = database.child('Appointment').get()
                if appointments.each():
                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        if (appointment_data.get('appointment_date') == appointment_date and
                            appointment_data.get('appointment_time') == appointment_time):
                            database.child('Appointment').child(appointment.key()).update({'status': status})
                            break
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update status: {e}")

        # Bind mouse click to handle status change
        def on_tree_select(event):
            selected_item = tree.selection()
            if selected_item:
                if tree.identify_region(event.x, event.y) == "cell":
                    column = tree.identify_column(event.x)
                    if column == "#6":
                        change_status_dialog(selected_item[0])

        # Function to fetch and insert data into the table
        def fetch_and_insert_data():
            try:
                appointments = database.child('Appointment').get()

                if appointments.each():
                    for appointment in appointments.each():
                        patient_name = appointment.key()  # Get the patient name
                        appointment_data = appointment.val()
                        status = "Pending" if not appointment_data.get('status', False) else "Accepted"
                        row = (
                            appointment_data.get('appointment_date', 'N/A'),
                            appointment_data.get('appointment_time', 'N/A'),
                            patient_name,  # Add patient name to the row
                            appointment_data.get('doctor_Name', 'N/A'),
                            appointment_data.get('clinic_Name', 'N/A'),
                            status,
                        )
                        tree.insert('', 'end', values=row)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to fetch data: {e}")

        # Create a frame for patient records section
        request_record_frame = tk.Frame(self.frame, bg='white')
        request_record_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Add heading
        heading_label = tk.Label(request_record_frame, text="Patient Request", font=("Arial", 18, "bold"), bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        # Table frame
        table_frame = tk.Frame(request_record_frame, padx=30, pady=30)
        table_frame.pack(fill=tk.BOTH, expand=True)

        # Style the Treeview
        style = ttk.Style()
        style.configure("Treeview",
                        background="#F5F5F5",
                        foreground="black",
                        rowheight=25,
                        fieldbackground="#F5F5F5",
                        font=('Arial', 12))
        style.configure("Treeview.Heading",
                        background="#0C7FDA",
                        font=('Arial', 12, 'bold'))
        style.map('Treeview',
                  background=[('selected', '#0C7FDA')])

        # Create table
        columns = ("Date", "Time", "Patient Name", "Doctor Name", "Clinic Name", "Status")
        tree = ttk.Treeview(table_frame, columns=columns, show='headings')
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Define headings
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120, anchor=tk.CENTER)

        # Scrollbar for the table
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Bind mouse click to handle status change
        tree.bind("<Button-1>", on_tree_select)

        # Insert data into the table
        fetch_and_insert_data()
