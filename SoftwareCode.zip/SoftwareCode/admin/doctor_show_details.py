import datetime
import random
import re
from tkcalendar import Calendar
from firebase_config import database
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
from admin.sidebar import Sidebar
from PIL import Image, ImageTk


class ShowDetails:
    def __init__(self, app, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.dc_name = dc_name or self.app.get_shared_data("dc_name")

        def on_enter(event):
            event.widget.config(bg="#8EC9F9")

        def on_leave(event):
            event.widget.config(bg="white")

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        detail_frame = tk.Frame(self.frame)
        detail_frame.pack(fill="both", expand=True)

        # Create two frames: one for labels and one for buttons
        labels_frame = tk.Frame(detail_frame)
        labels_frame.grid(row=0, column=0, padx=20, pady=20)

        buttons_frame = tk.Frame(detail_frame)
        buttons_frame.grid(row=0, column=1, padx=20, pady=20)

        # Retrieve doctor details from the database
        doctor_db = database.child('Doctor').get().val()
        print(f"Dc_name: {self.dc_name}")

        doctor = None
        for doc_id, doc_data in doctor_db.items():
            if doc_data.get('dc_name') == self.dc_name:
                doctor = doc_data
                doctor['key'] = doc_id  # Capture the doctor's key for later use
                break

        if doctor:
            # Display doctor details
            dc_name_label = tk.Label(labels_frame, text=f"Dr. {doctor['dc_name']}", font=("Work Sans", 20, "bold"))
            dc_name_label.pack(anchor='w', pady=5)

            dc_specialty_label = tk.Label(labels_frame, text=f"Specialty: {doctor['dc_specialty']}",
                                          font=("Poppins", 12, "bold"))
            dc_specialty_label.pack(anchor='w', pady=5)

            dc_email_label = tk.Label(labels_frame, text=f"Email: {doctor['dc_email']}", font=("Work Sans", 12, "bold"))
            dc_email_label.pack(anchor='w', pady=5)

            dc_phone_label = tk.Label(labels_frame, text=f"Phone: {doctor['dc_phone']}", font=("Work Sans", 12, "bold"))
            dc_phone_label.pack(anchor='w', pady=5)

            work_clinic_label = tk.Label(labels_frame, text=f"Clinic: {doctor['work_clinic']}", font=("Work Sans", 12, "bold"))
            work_clinic_label.pack(anchor='w', pady=5)

            def show_calendar():
                calendar_frame = tk.Frame(buttons_frame)
                calendar_frame.pack(padx=20, pady=20)

                calendar = Calendar(calendar_frame,
                                    selectmode='none',
                                    year=2024, month=6,
                                    font=('Arial', 16),
                                    background='white',
                                    foreground='black',
                                    headersbackground='white',
                                    headersforeground='black',
                                    selectbackground='blue',
                                    selectforeground='white')
                calendar.pack(padx=20, pady=20)

                # Set the tag color to red for busy dates
                calendar.tag_config('busy', background='red', foreground='white')

                # Fetch and highlight appointment dates
                appointment_dates = self.fetch_appointment_dates(doctor['dc_name'])
                print(f"Appointment dates: {appointment_dates}")  # Debug statement
                for date in appointment_dates:
                    try:
                        month, day, year = map(int, date.split('/'))
                        if not (1 <= month <= 12):
                            raise ValueError("Month must be in 1..12")
                        if not (1 <= day <= 31):
                            raise ValueError("Day must be in 1..31")
                        # Highlight the date on the calendar
                        calendar.calevent_create(datetime.date(year, month, day), 'Appointment', 'busy')
                    except ValueError as e:
                        print(f"Error parsing date {date}: {e}")

            show_calendar()

            def fetch_user_details(username):
                try:
                    user_ref = database.child('User').child(username)
                    user_details = user_ref.get()
                    if user_details:
                        return user_details.val()
                    else:
                        return None
                except Exception as e:
                    print(f"Error fetching user details: {e}")
                    return None

            def assign_doctor():
                assign_window = tk.Toplevel(detail_frame)
                assign_window.title("Assign Doctor")
                assign_window.geometry("500x500")
                assign_window.resizable(False, False)

                # Create a calendar to show the doctor's busy dates
                calendar = Calendar(assign_window, selectmode='day', year=2024, month=6, day=17, font=('Arial', 20))
                calendar.pack(padx=20, pady=20)

                # Set the tag color to red for busy dates
                calendar.tag_config('busy', background='red', foreground='white')

                # Fetch and highlight appointment dates
                appointment_dates = self.fetch_appointment_dates(doctor['dc_name'])
                print(f"Appointment dates: {appointment_dates}")  # Debug statement
                busy_dates = []
                for date in appointment_dates:
                    try:
                        month, day, year = map(int, date.split('/'))
                        if not (1 <= month <= 12):
                            raise ValueError("Month must be in 1..12")
                        if not (1 <= day <= 31):
                            raise ValueError("Day must be in 1..31")
                        # Highlight the date on the calendar
                        calendar.calevent_create(datetime.date(year, month, day), 'Appointment', 'busy')
                        busy_dates.append(datetime.date(year, month, day))
                    except ValueError as e:
                        print(f"Error parsing date {date}: {e}")

                # Automatically fill in the details
                appointment_address_label = tk.Label(assign_window, text="Appointment Address:")
                appointment_address_label.place(x=100, y=350)
                appointment_address_entry = tk.Entry(assign_window)
                appointment_address_entry.place(x=250, y=350, width=150)

                # Automatically get the current time for the appointment time
                current_time = datetime.datetime.now().time().strftime("%H:%M:%S")

                # Use the clinic name from the current doctor details
                clinic_name = doctor['work_clinic']

                # Use the doctor's ID and name from the current doctor details
                doctor_name = doctor['dc_name']
                doctor_id = doctor['key']

                user_id_label = tk.Label(assign_window, text="User ID:")
                user_id_label.place(x=100, y=380)
                user_id_entry = tk.Entry(assign_window)
                user_id_entry.place(x=250, y=380, width=150)

                details_label = tk.Label(assign_window, text="Details:")
                details_label.place(x=100, y=410)
                details_entry = tk.Entry(assign_window)
                details_entry.place(x=250, y=410, width=150)

                patient_name_label = tk.Label(assign_window, text="Patient Name:")
                patient_name_label.place(x=100, y=440)
                patient_name_entry = tk.Entry(assign_window)
                patient_name_entry.place(x=250, y=440, width=150)

                def assign_selected_date():
                    selected_date = calendar.get_date()
                    try:
                        selected_date = datetime.datetime.strptime(selected_date, '%m/%d/%y').date()
                        # Check if the selected date is a busy date
                        if selected_date in busy_dates:
                            messagebox.showerror("Error", "Doctor is busy on this date. Please select another date.")

                        # Get the appointment data from the admin
                        appointment_address = appointment_address_entry.get()
                        appointment_time = current_time  # Use the current time
                        user_id = user_id_entry.get()
                        user_name = patient_name_entry.get()

                        if any(value == "" for value in [appointment_address, user_id, user_name]):
                            messagebox.showerror("Error", "All fields are required")

                        user_details = fetch_user_details(user_name)
                        if not user_details:
                            messagebox.showerror("Error", "User not found.")

                        details = details_entry.get()
                        patient_name = patient_name_entry.get()
                        status = False

                        # Create a new appointment in the database
                        appointment_data = {
                            "appointment_address": appointment_address,
                            "appointment_date": str(selected_date),
                            "appointment_time": appointment_time,
                            "clinic_Name": clinic_name,
                            "doctor_Name": doctor_name,
                            "doctor_id": doctor_id,
                            "status": status,
                            "user_id": user_id,
                            "user_name": user_name  # Add user name to the data
                        }
                        appointment_ref = database.child("Appointment").push(appointment_data)

                        # Add the appointment to the doctor's calendar
                        calendar_data = {
                            "date_appointed": selected_date.strftime('%m/%d/%Y'),
                            "details": details,
                            "patient_name": patient_name
                        }
                        database.child("Calendar").child(doctor_name).child("appointments").child(
                            selected_date.strftime('%Y-%m-%d')).set(calendar_data)

                        messagebox.showinfo("Success", f"Doctor assigned to {selected_date} successfully!")
                        assign_window.destroy()
                    except Exception as e:
                        print(f"Error: Failed to assign doctor: {e}")
                        messagebox.showerror("Error", f"Failed to assign doctor: {e}")

                assign_button = tk.Button(assign_window, text="Assign Doctor", command=assign_selected_date)
                assign_button.place(x=200, y=470)

            assign_button = tk.Button(buttons_frame, text="Assign Doctor", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                                      activebackground='white', command=assign_doctor)
            assign_button.pack(pady=10)

            # Add a button to go back to the doctor list
            back_button = tk.Button(buttons_frame, text="Back", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                                    activebackground='white', command=lambda: self.app.show_page("show_doctor_after_view"))
            back_button.pack(pady=10)
        else:
            print(f"Doctor {self.dc_name} not found.")

    def fetch_appointment_dates(self, doctor_name):
        try:
            print(f"Fetching appointment dates for doctor: {doctor_name}")  # Debug statement
            appointments = database.child("Calendar").child(doctor_name).child("appointments").get()
            appointment_dates = []
            if appointments:
                for appointment in appointments.each():
                    appointment_info = appointment.val()
                    appointment_dates.append(appointment_info['date_appointed'])
            print(f"Appointment dates: {appointment_dates}")  # Debug statement
            return appointment_dates
        except Exception as e:
            print(f"Error fetching appointment dates: {e}")  # Debug statement
            return []

    def show_doctor_list(self, detail_frame):
        # Destroy the detail frame
        detail_frame.destroy()
        # Clear any remaining content in the root
        for widget in self.frame.winfo_children():
            widget.destroy()
        # Reinitialize the doctor section
        # self.setup_doctor_section()
