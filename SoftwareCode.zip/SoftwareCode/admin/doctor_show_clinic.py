import datetime
import random
import re
from tkcalendar import Calendar
from firebase_config import database
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox, PhotoImage
from admin.sidebar import Sidebar


class ShowClinic_doctor:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)  # Replace Sidebar with your Sidebar class
        self.sidebar.pack(side='left', fill='y')

        # Home page content
        self.show_clinic_doctor_frame = Frame(self.frame, bg='white')
        self.show_clinic_doctor_frame.pack(fill='both', expand=True, padx=20)  # Adjust padding as needed

        heading_label = tk.Label(self.show_clinic_doctor_frame, text="Select Clinic", font=("Arial", 18, "bold"), bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas = tk.Canvas(self.show_clinic_doctor_frame, bg='white')
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(self.show_clinic_doctor_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))

        self.clinic_container = tk.Frame(self.canvas, bg='white')
        self.canvas.create_window((0, 0), window=self.clinic_container, anchor='nw')

        self.canvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

        self.display_clinics()

    def on_mouse_wheel(self, event):
        self.canvas.yview_scroll(-1 * int((event.delta / 120)), "units")

    def fetch_clinic_data(self):
        try:
            clinics = database.child('Clinic').get()
            if clinics.each():
                return [clinic.val() for clinic in clinics.each()]
            else:
                return []
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data: {e}")
            return []

    def create_clinic_rectangle(self, clinic):
        clinic_frame = tk.Frame(self.clinic_container, bg='white')
        clinic_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_clinic_path = "pictures/admin/Rectangle-show clinic.png"
        Rectangle_for_clinic_img = PhotoImage(file=Rectangle_for_clinic_path)

        canvas = tk.Canvas(clinic_frame, width=Rectangle_for_clinic_img.width(),
                           height=Rectangle_for_clinic_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        name_label = tk.Label(canvas, text=f"{clinic['name']}", font=("Work Sans", 16, "bold"), bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=name_label)

        review_label = tk.Label(clinic_frame, text=f"Review: {clinic['Review']}", font=("Arial", 12), bg='#D9D9D9')
        review_label.place(x=20, y=50)

        time_label = tk.Label(clinic_frame, text=f"Operating Hours:\n{clinic['open_time']} - {clinic['close_time']}",
                              font=("Work Sans", 14, "bold"), bg='#D9D9D9')
        time_label.place(x=300, y=40)

        status_label = tk.Label(clinic_frame, text=f"Status: {clinic['status']}", font=("Arial", 12), bg='#D9D9D9')
        status_label.place(x=20, y=70)

        clinic_name = clinic['name']

        def show_clinic_page():
            self.app.set_shared_data("name", clinic_name)
            self.app.show_page("show_doctor_after_view", name=clinic_name)

        arrow_button_image_path = "pictures/admin/circle-chevron-right-solid.png"
        arrow_button_img = PhotoImage(file=arrow_button_image_path)
        arrow_button_button = Button(clinic_frame, image=arrow_button_img, borderwidth=0, bg='#D9D9D9',
                                     activebackground='#D9D9D9',
                                     command=show_clinic_page)
        arrow_button_button.image = arrow_button_img
        arrow_button_button.place(x=550, y=40)

        clinic_frame.image = Rectangle_for_clinic_img

    def display_clinics(self):
        clinics = self.fetch_clinic_data()
        for clinic in clinics:
            self.create_clinic_rectangle(clinic)
