import tkinter as tk
from tkinter import *
from tkintermapview import TkinterMapView  # Make sure you have installed tkintermapview
from tkcalendar import Calendar, DateEntry
from tkinter import messagebox
from tkinter import font
from tkinter import filedialog
from PIL import Image, ImageTk

import datetime


# Function at sidebar
def navigate_to_homepage():
    hide_all_frames()
    homepage_frame.pack(fill=BOTH, expand=True)


# Function at sidebar
def navigate_to_appointments():
    hide_all_frames()
    view_appointment_frame.pack(fill=BOTH, expand=True)


# Function at sidebar
def navigate_to_view_doctor():
    hide_all_frames()
    view_doctor_frame.pack(fill=BOTH, expand=True)


# Function at sidebar
def navigate_to_settings():
    hide_all_frames()
    settings_frame.pack(fill=BOTH, expand=True)


def logout():
    print("Logging out...")  # Placeholder action for demonstration
    root.destroy()  # Close the tkinter window
    import sys;
    sys.exit()  # Stop the code execution


# Search bar at home page
def perform_search():
    query = search_entry.get()
    print(f"Searching for: {query}")  # Placeholder action for demonstration


def navigate_to_search_clinic():
    hide_all_frames()
    search_clinic_frame.pack(fill=BOTH, expand=True)


def navigate_to_VCare():
    hide_all_frames()
    vcare_frame.pack(fill=BOTH, expand=True)


def navigate_to_MD_Clinic():
    hide_all_frames()
    MD_Clinic_frame.pack(fill=BOTH, expand=True)


def navigate_to_doctor1_profile():
    hide_all_frames()
    doctor1_profile_frame.pack(fill=BOTH, expand=True)


def navigate_to_doctor2_profile():
    hide_all_frames()
    doctor2_profile_frame.pack(fill=BOTH, expand=True)


# done copy
def on_enter(event):
    event.widget.config(bg="#8EC9F9")


# done copy
def on_leave(event):
    event.widget.config(bg="white")


def request_doctor():
    print("Requesting doctor...")


def navigate_to_booking_appointment():
    homepage_frame.pack_forget()
    search_clinic_frame.pack_forget()
    vcare_frame.pack_forget()
    MD_Clinic_frame.pack_forget()
    doctor1_profile_frame.pack_forget()
    doctor2_profile_frame.pack_forget()
    booking_appointment_frame.pack(fill=BOTH, expand=True)


def on_enter_button(event):
    request_doctor_button_label.config(bg="#8EC9F9")


def on_leave_button(event):
    request_doctor_button_label.config(bg="white")


def hide_all_frames():
    homepage_frame.pack_forget()
    search_clinic_frame.pack_forget()
    vcare_frame.pack_forget()
    MD_Clinic_frame.pack_forget()
    booking_appointment_frame.pack_forget()
    view_appointment_frame.pack_forget()
    view_doctor_frame.pack_forget()
    settings_frame.pack_forget()
    doctor1_profile_frame.pack_forget()
    doctor2_profile_frame.pack_forget()


# Placeholder Search function
def manage_placeholder(entry, default_text):
    def add_placeholder(event):
        if entry.get() == default_text:
            entry.delete(0, "end")
            entry.config(fg='black')  # Change text color to black

    def remove_placeholder(event):
        if entry.get() == "":
            entry.insert(0, default_text)
            entry.config(fg='gray')  # Change text color to gray

    entry.insert(0, default_text)  # Set initial placeholder text
    entry.bind("<FocusIn>", add_placeholder)
    entry.bind("<FocusOut>", remove_placeholder)
    entry.config(fg='gray')  # Set initial text color to gray

# Here start
root = Tk()
root.title('Homepage')
root.geometry('1331x594')  # Adjusted width to accommodate navigation section
root.configure(bg="#fff")
root.resizable(False, False)

# done copy
# Create frame for navigation section
nav_frame = Frame(root, width=281, height=594, bg='white', highlightbackground="lightgrey", highlightthickness=1)
nav_frame.pack(side=LEFT, fill=Y)

# done copy
# Load and display the navigation heading image
nav_heading_image_path = "pictures/HomePage/navigation heading.png"
nav_heading_img = PhotoImage(file=nav_heading_image_path)
nav_heading_label = Label(nav_frame, image=nav_heading_img, bg='white')
nav_heading_label.image = nav_heading_img
nav_heading_label.pack(pady=20)

# done copy
# Load and display the navigation homepage image
nav_homepage_image_path = "pictures/HomePage/navigation homepage.png"
nav_homepage_img = PhotoImage(file=nav_homepage_image_path)
nav_homepage_label = Label(nav_frame, image=nav_homepage_img, bg='white')
nav_homepage_label.image = nav_homepage_img
nav_homepage_label.pack(pady=20)
nav_homepage_label.bind("<Enter>", on_enter)
nav_homepage_label.bind("<Leave>", on_leave)
nav_homepage_label.bind("<Button-1>", lambda event: navigate_to_homepage())

# done copy
# Load and display the navigation search clinic image
nav_search_clinic_image_path = "pictures/HomePage/navigation search clinic.png"
nav_search_clinic_img = PhotoImage(file=nav_search_clinic_image_path)
nav_search_clinic_label = Label(nav_frame, image=nav_search_clinic_img, bg='white')
nav_search_clinic_label.image = nav_search_clinic_img
nav_search_clinic_label.pack(pady=20)
nav_search_clinic_label.bind("<Enter>", on_enter)
nav_search_clinic_label.bind("<Leave>", on_leave)
nav_search_clinic_label.bind("<Button-1>", lambda event: navigate_to_search_clinic())

# done copy
# Load and display the navigation appointments image
nav_appointments_image_path = "pictures/HomePage/navigation appointment.png"
nav_appointments_img = PhotoImage(file=nav_appointments_image_path)
nav_appointments_label = Label(nav_frame, image=nav_appointments_img, bg='white')
nav_appointments_label.image = nav_appointments_img
nav_appointments_label.pack(pady=20)
nav_appointments_label.bind("<Enter>", on_enter)
nav_appointments_label.bind("<Leave>", on_leave)
nav_appointments_label.bind("<Button-1>", lambda event: navigate_to_appointments())

# done copy
# Load and display the navigation view doctor image
nav_view_doctor_image_path = "pictures/HomePage/navigation viewdoctors.png"
nav_view_doctor_img = PhotoImage(file=nav_view_doctor_image_path)
nav_view_doctor_label = Label(nav_frame, image=nav_view_doctor_img, bg='white')
nav_view_doctor_label.image = nav_view_doctor_img
nav_view_doctor_label.pack(pady=20)
nav_view_doctor_label.bind("<Enter>", on_enter)
nav_view_doctor_label.bind("<Leave>", on_leave)
nav_view_doctor_label.bind("<Button-1>", lambda event: navigate_to_view_doctor())

# done copy
# Load and display the navigation settings image
nav_settings_image_path = "pictures/HomePage/navigation settings.png"
nav_settings_img = PhotoImage(file=nav_settings_image_path)
nav_settings_label = Label(nav_frame, image=nav_settings_img, bg='white')
nav_settings_label.image = nav_settings_img
nav_settings_label.pack(pady=20)
nav_settings_label.bind("<Enter>", on_enter)
nav_settings_label.bind("<Leave>", on_leave)
nav_settings_label.bind("<Button-1>", lambda event: navigate_to_settings())

# done copy
# Load and display the logout image
nav_logout_image_path = "pictures/HomePage/navigation logout.png"
nav_logout_img = PhotoImage(file=nav_logout_image_path)
nav_logout_label = Label(nav_frame, image=nav_logout_img, bg='white')
nav_logout_label.image = nav_logout_img
nav_logout_label.pack(side=BOTTOM, pady=(5, 20))  # Positioning at the bottom with padding
nav_logout_label.bind("<Enter>", on_enter)
nav_logout_label.bind("<Leave>", on_leave)
nav_logout_label.bind("<Button-1>", lambda event: logout())

# done copy
# Create frame for homepage content
homepage_frame = Frame(root, bg='white')

# done copy
# Load and display the homepage search bar image
homepage_search_bar_image_path = "pictures/HomePage/homepage search bar.png"
homepage_search_bar_img = PhotoImage(file=homepage_search_bar_image_path)
homepage_search_bar_label = Label(homepage_frame, image=homepage_search_bar_img, bg='white')
homepage_search_bar_label.image = homepage_search_bar_img
homepage_search_bar_label.place(x=100, y=50)  # Adjust the coordinates as needed

# done copy
# Load and display the homepage search icon image
homepage_search_icon_image_path = "pictures/HomePage/homepage search icon.png"
homepage_search_icon_img = PhotoImage(file=homepage_search_icon_image_path)
homepage_search_icon_label = Label(homepage_frame, image=homepage_search_icon_img, bg='white')
homepage_search_icon_label.image = homepage_search_icon_img
homepage_search_icon_label.place(x=120, y=75)  # Adjust the coordinates as needed

# done copy
# Create the search bar entry field
search_entry = Entry(homepage_search_bar_label, borderwidth=0, bg='#fff', font=('Montserrat', 12, 'bold'))
search_entry.place(x=50, y=20, width=650)  # Adjust position and width as needed

# done copy
# Load and display the search button image
search_button_image_path = "pictures/HomePage/search button.png"
search_button_img = PhotoImage(file=search_button_image_path)
search_button_label = Label(homepage_frame, image=search_button_img, bg='white')
search_button_label.image = search_button_img
search_button_label.place(x=690, y=52.5)  # Adjust the coordinates as needed
search_button_label.bind("<Button-1>", lambda event: perform_search())  # Bind click event to search button

# done copy
homepage_frame.pack(fill=BOTH, expand=True)

# done copy
# Create frame for the search clinic content
search_clinic_frame = Frame(root, bg='white')

# done copy
# Load and display the search clinic entry field image
search_clinic_entry_image_path = "pictures/Search Clinic Page/search clinic entry field.png"
search_clinic_entry_img = PhotoImage(file=search_clinic_entry_image_path)
search_clinic_entry_label = Label(search_clinic_frame, image=search_clinic_entry_img, bg='white')
search_clinic_entry_label.image = search_clinic_entry_img
search_clinic_entry_label.place(x=100, y=50)  # Adjust the coordinates as needed

# done copy
# Create the search bar entry field for search clinic page
search_entry_search_clinic = Entry(search_clinic_entry_label, borderwidth=0, bg='#fff', font=('Montserrat', 12, 'bold'))
search_entry_search_clinic.place(x=30, y=12, width=400)  # Adjust position and width as needed

# done copy
# Apply placeholder functionality to search clinic entry field
manage_placeholder(search_entry_search_clinic, "Search Clinics...")

# Load and display the Clinic Listing information image
VCare_image_path = "pictures/Search Clinic Page/Clinic V care.png"
VCare_image_img = PhotoImage(file=VCare_image_path)
VCare_image_label = Label(search_clinic_frame, image=VCare_image_img, bg='white')
VCare_image_label.image = VCare_image_img
VCare_image_label.place(x=100, y=200)  # Adjust the coordinates as needed
VCare_image_label.bind("<Enter>", on_enter)
VCare_image_label.bind("<Leave>", on_leave)
VCare_image_label.bind("<Button-1>", lambda event: navigate_to_VCare())  # Bind click event to clinic info label

# Load and display the Clinic Listing information image
MD_Clinic_image_path = "pictures/Search Clinic Page/MD Clinic.png"
MD_Clinic_image_img = PhotoImage(file=MD_Clinic_image_path)
MD_Clinic_image_label = Label(search_clinic_frame, image=MD_Clinic_image_img, bg='white')
MD_Clinic_image_label.image = MD_Clinic_image_img
MD_Clinic_image_label.place(x=100, y=400)  # Adjust the coordinates as needed
MD_Clinic_image_label.bind("<Enter>", on_enter)
MD_Clinic_image_label.bind("<Leave>", on_leave)
MD_Clinic_image_label.bind("<Button-1>", lambda event: navigate_to_MD_Clinic())  # Bind click event to clinic info label

search_clinic_frame.pack_forget()

# Create frame for VCare content
vcare_frame = Frame(root, bg='white')

# Load and display the VCare information image
VCare_info_image_path = "pictures/Search Clinic Page/Clinic V care 2.png"
VCare_info_image_img = PhotoImage(file=VCare_info_image_path)
VCare_info_image_label = Label(vcare_frame, image=VCare_info_image_img, bg='white')
VCare_info_image_label.image = VCare_info_image_img
VCare_info_image_label.place(x=100, y=100)  # Adjust the coordinates as needed

# Create and pack the header label
header_label = Label(vcare_frame, text="Clinic V-Care - Penang", font=("Inika", 20, "bold"), bg="white")
header_label.place(x=600, y=100)  # Adjust the coordinates as needed

# Load and display the rating image for VCare clinic
VCare_rating_image_path = "pictures/Search Clinic Page/V Care rating.png"
VCare_rating_img = PhotoImage(file=VCare_rating_image_path)
VCare_rating_label = Label(vcare_frame, image=VCare_rating_img, bg='white')
VCare_rating_label.image = VCare_rating_img
VCare_rating_label.place(x=690, y=150)  # Adjust the coordinates as needed

# Load and display the request doctor button image
request_doctor_button_image_path = "pictures/Search Clinic Page/Request doctor button.png"
request_doctor_button_img = PhotoImage(file=request_doctor_button_image_path)
request_doctor_button_label = Label(vcare_frame, image=request_doctor_button_img, bg='white')
request_doctor_button_label.image = request_doctor_button_img
request_doctor_button_label.place(x=640, y=200)  # Adjust the coordinates as needed
# Bind click event to request doctor button
request_doctor_button_label.bind("<Button-1>", lambda event: navigate_to_booking_appointment())
request_doctor_button_label.bind("<Enter>", on_enter_button)
request_doctor_button_label.bind("<Leave>", on_leave_button)

# Load and display the VCare description image
VCare_description_image_path = "pictures/Search Clinic Page/V care description.png"
VCare_description_image_img = PhotoImage(file=VCare_description_image_path)
VCare_description_image_label = Label(vcare_frame, image=VCare_description_image_img, bg='white')
VCare_description_image_label.image = VCare_description_image_img
VCare_description_image_label.place(x=580, y=280)  # Adjust the coordinates as needed

# Create and pack the TkinterMapView widget for the map
gmap_widget = TkinterMapView(vcare_frame, width=328, height=211)
gmap_widget.place(x=100, y=320)  # Position it below the VCare info image

# Set the tile server to use Google Maps tiles
gmap_widget.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)

# Set the address to be displayed
gmap_widget.set_position(5.3947148, 100.3147779)

# Set marker at specified coordinates
marker = gmap_widget.set_marker(5.3947148, 100.3147779, marker_color_circle="white", marker_color_outside="blue")

# Set the initial zoom level
gmap_widget.set_zoom(19)

vcare_frame.pack_forget()

# Create frame for MD_Clinic content
MD_Clinic_frame = Frame(root, bg='white')

# Load and display the MD Clinic information image
MD_Clinic_info_image_path = "pictures/Search Clinic Page/MD Clinic 2.png"
MD_Clinic_info_image_img = PhotoImage(file=MD_Clinic_info_image_path)
MD_Clinic_info_image_label = Label(MD_Clinic_frame, image=MD_Clinic_info_image_img, bg='white')
MD_Clinic_info_image_label.image = MD_Clinic_info_image_img
MD_Clinic_info_image_label.place(x=100, y=100)  # Adjust the coordinates as needed

# Create and pack the header label
header_label_MD = Label(MD_Clinic_frame, text="MD Clinic Golden Triangle 2", font=("Inika", 20, "bold"), bg="white")
header_label_MD.place(x=600, y=100)  # Adjust the coordinates as needed

# Load and display the rating image for MD Clinic (same as VCare clinic)
MD_Clinic_rating_img = VCare_rating_img  # Reuse the same rating image
MD_Clinic_rating_label = Label(MD_Clinic_frame, image=MD_Clinic_rating_img, bg='white')
MD_Clinic_rating_label.image = MD_Clinic_rating_img
MD_Clinic_rating_label.place(x=720, y=150)  # Adjust the coordinates as needed

# Load and display the request doctor button image (same as VCare clinic)
request_doctor_button_img_MD = request_doctor_button_img  # Reuse the same button image
request_doctor_button_label_MD = Label(MD_Clinic_frame, image=request_doctor_button_img_MD, bg='white')
request_doctor_button_label_MD.image = request_doctor_button_img_MD
request_doctor_button_label_MD.place(x=670, y=200)  # Adjust the coordinates as needed
# Bind click event to request doctor button
request_doctor_button_label_MD.bind("<Button-1>", lambda event: navigate_to_booking_appointment())
request_doctor_button_label_MD.bind("<Enter>", on_enter_button)
request_doctor_button_label_MD.bind("<Leave>", on_leave_button)

# Load and display the MD Clinic description image
MD_Clinic_description_image_path = "pictures/Search Clinic Page/MD Clinic Description.png"
MD_Clinic_description_image_img = PhotoImage(file=MD_Clinic_description_image_path)
MD_Clinic_description_image_label = Label(MD_Clinic_frame, image=MD_Clinic_description_image_img, bg='white')
MD_Clinic_description_image_label.image = MD_Clinic_description_image_img
MD_Clinic_description_image_label.place(x=580, y=280)  # Adjust the coordinates as needed

# Create and pack the TkinterMapView widget for the map (reuse the same settings as VCare clinic)
gmap_widget_MD = TkinterMapView(MD_Clinic_frame, width=328, height=211)
gmap_widget_MD.place(x=100, y=320)  # Position it below the MD Clinic info image

# Set the tile server to use Google Maps tiles
gmap_widget_MD.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)

# Set the address to be displayed
gmap_widget_MD.set_position(5.330240000007691, 100.27488745818847)

# Set marker at specified coordinates
marker_MD = gmap_widget_MD.set_marker(5.330240000007691, 100.27488745818847, marker_color_circle="white",
                                      marker_color_outside="blue")

# Set the initial zoom level
gmap_widget_MD.set_zoom(19)

MD_Clinic_frame.pack_forget()

# Booking Appointment Page

# Global variables to hold the selected date and time
selected_date = None
selected_time = None



# Mapping of time buttons to their respective times
time_mapping = {
    "time1": "9:00am",
    "time2": "9:30am",
    "time3": "10:00am",
    "time4": "10:30am",
    "time5": "11:00am",
    "time6": "2:00pm",
    "time7": "2:30pm",
    "time8": "3:00pm",
    "time9": "3:30pm",
    "time10": "4:00pm",
    "time11": "4:30pm",
    "time12": "5:00pm"
}


# Function to handle date selection and validation
def choose_date():
    top = Toplevel(root)
    cal = Calendar(top, selectmode='day', date_pattern='yyyy-mm-dd')
    cal.pack(padx=20, pady=20)

    def set_date():
        global selected_date
        selected_date_str = cal.get_date()

        try:
            selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Please select a valid date.")
            return

        if selected_date < datetime.date.today():
            messagebox.showerror("Error", "Please select a date that is not in the past.")
            return

        # Update the entry field with the selected date
        date_entry.delete(0, END)
        date_entry.insert(0, selected_date_str)

        top.destroy()

    confirm_button = Button(top, text="OK", command=set_date)
    confirm_button.pack(pady=10)


# Function to handle time selection for appointment
def select_time(time):
    global selected_time
    selected_time = time_mapping.get(time)
    messagebox.showinfo("Time Selected", f"You have selected {selected_time} for your appointment.")


# Function to handle submission of the appointment
def submit_appointment():
    global selected_date, selected_time
    if selected_date is None:
        messagebox.showerror("Error", "Please select a date before submitting.")
        return

    if selected_time is None:
        messagebox.showerror("Error", "Please select a time before submitting.")
        return

    # Process the appointment submission here (e.g., save to database, etc.)
    messagebox.showinfo("Appointment Submitted",
                        f"Appointment for {selected_time} on {selected_date} has been successfully scheduled.")

    # Reset selected date and time after submission
    selected_date = None
    selected_time = None
    date_entry.config(state='normal')
    date_entry.delete(0, END)


# Create frame for Booking Appointment content
booking_appointment_frame = Frame(root, bg='white')

# Add content to the Booking Appointment frame
booking_header_label = Label(booking_appointment_frame, text="Complete your Appointment", font=("Poppins", 20, "bold"),
                             bg="white")
booking_header_label.pack(pady=20)

# Add "Select Date" text
select_date_label = Label(booking_appointment_frame, text="Select Date", font=("Poppins", 14, "bold"), bg="white")
select_date_label.place(x=50, y=100)  # Adjust coordinates as needed

# Entry field for date selection with increased border visibility
date_entry = Entry(booking_appointment_frame, font=("Poppins", 12), highlightthickness=2, highlightbackground="#ccc",
                   bd=0)
date_entry.place(x=50, y=150)  # Adjust coordinates as needed

# Load the calendar icon image
calendar_icon_path = "pictures/Search Clinic Page/Book Appointment/calendar icon.png"
calendar_icon = PhotoImage(file=calendar_icon_path)

# Create the image button
pick_date_button = Button(booking_appointment_frame, image=calendar_icon, command=choose_date, bd=0)
pick_date_button.image = calendar_icon  # Keep a reference to the image
pick_date_button.place(x=240, y=152)

# Label for "Available Time"
available_time_label = Label(booking_appointment_frame, text="Available Time", font=("Poppins", 14, "bold"), bg="white")
available_time_label.place(x=50, y=200)  # Adjust coordinates as needed


# Function to handle hover effects on time buttons
def on_enter(event):
    event.widget.config(bg='#FFD700')  # Change background color on hover


def on_leave(event):
    event.widget.config(bg='SystemButtonFace')  # Restore background color on leave


# Load and configure time buttons
time_button_paths = [
    "pictures/Search Clinic Page/Book Appointment/Time 1.png",
    "pictures/Search Clinic Page/Book Appointment/Time 2.png",
    "pictures/Search Clinic Page/Book Appointment/Time 3.png",
    "pictures/Search Clinic Page/Book Appointment/Time 4.png",
    "pictures/Search Clinic Page/Book Appointment/Time 5.png",
    "pictures/Search Clinic Page/Book Appointment/Time 6.png",
    "pictures/Search Clinic Page/Book Appointment/Time 7.png",
    "pictures/Search Clinic Page/Book Appointment/Time 8.png",
    "pictures/Search Clinic Page/Book Appointment/Time 9.png",
    "pictures/Search Clinic Page/Book Appointment/Time 10.png",
    "pictures/Search Clinic Page/Book Appointment/Time 11.png",
    "pictures/Search Clinic Page/Book Appointment/Time 12.png"
]

# Custom coordinates for each time button
'''time_button_coordinates = [
    (50, 250),  # Time 1
    (180, 250),  # Time 2
    (310, 250),  # Time 3
    (50, 320),  # Time 4
    (180, 320),  # Time 5
    (310, 320),  # Time 6
    (50, 390),  # Time 7
    (180, 390),  # Time 8
    (310, 390),  # Time 9
    (50, 460),  # Time 10
    (180, 460),  # Time 11
    (310, 460)  # Time 12
]'''

# Above was bernie, below was GPT
time_button_coordinates = [
    (10, 20), (50, 20), (90, 20), (130, 20),
    (10, 60), (50, 60), (90, 60), (130, 60),
    (10, 100), (50, 100), (90, 100), (130, 100)
]

# Initialize a list to hold the time buttons
time_buttons = []

# Loop through each time button path and create buttons
'''for i, button_path in enumerate(time_button_paths):
    time_image = PhotoImage(file=button_path)

    # Use custom coordinates for each button
    x_coord, y_coord = time_button_coordinates[i]
    time_button = Button(booking_appointment_frame, image=time_image, bd=0,
                         command=lambda idx=i: select_time(f"time{idx + 1}"))
    time_button.image = time_image
    time_button.place(x=x_coord, y=y_coord)  # Adjust x and y coordinates

    time_button.bind("<Enter>", on_enter)
    time_button.bind("<Leave>", on_leave)

    # Add each button to the list
    time_buttons.append(time_button)'''

# Above was bernie, below was GPT
for i, button_path in enumerate(time_button_paths):
    try:
        time_image = PhotoImage(file=button_path)

        # Use custom coordinates for each button
        x_coord, y_coord = time_button_coordinates[i]
        time_button = Button(booking_appointment_frame, image=time_image, bd=0,
                             command=lambda idx=i: select_time(f"time{idx + 1}"))
        time_button.image = time_image
        time_button.place(x=x_coord, y=y_coord)  # Adjust x and y coordinates

        time_button.bind("<Enter>", on_enter)
        time_button.bind("<Leave>", on_leave)

        # Add each button to the list
        time_buttons.append(time_button)
    except TclError as e:
        print(f"Error loading image at {button_path}: {e}")











# Submit button
submit_button_path = "pictures/Search Clinic Page/Book Appointment/submit button.png"
submit_button_image = PhotoImage(file=submit_button_path)

submit_button = Button(booking_appointment_frame, image=submit_button_image, bd=0, command=submit_appointment)
submit_button.image = submit_button_image
submit_button.place(x=900, y=520)  # Adjust coordinates as needed

# Create a label for input address
address_label = Label(booking_appointment_frame, text="Input your Address", font=("Poppins", 14, "bold"), bg="white")
address_label.place(x=500, y=90)

address_line1_label = Label(booking_appointment_frame, text="Address Line 1", font=("Poppins", 12, "bold"), bg="white")
address_line1_label.place(x=500, y=140)

# Load image for address entry field background
address_entry_field_image_path = "pictures/Search Clinic Page/Book Appointment/Address entry field.png"
address_entry_field_image = PhotoImage(file=address_entry_field_image_path)

# Create label for the address entry field image
address_entry_field_label = Label(booking_appointment_frame, image=address_entry_field_image, bd=0)
address_entry_field_label.image = address_entry_field_image  # Keep a reference to the image to prevent garbage collection
address_entry_field_label.place(x=500, y=170)

# Font configuration for the entry field
entry_font = font.Font(family="Poppins", size=12, weight="bold")


# Entry widget for inputting address
address_entry = Entry(booking_appointment_frame, width=35, bd=0, bg="#D9D9D9", fg="black", font=entry_font)
address_entry.place(x=510, y=180)

# Address Line2 label
address_line2_label = Label(booking_appointment_frame, text="Address Line 2", font=("Poppins", 12, "bold"), bg="white")
address_line2_label.place(x=500, y=210)

# Create label for the address entry field image
address_entry_field_label = Label(booking_appointment_frame, image=address_entry_field_image, bd=0)
address_entry_field_label.image = address_entry_field_image  # Keep a reference to the image to prevent garbage collection
address_entry_field_label.place(x=500, y=240)

# Font configuration for the entry field
entry_font = font.Font(family="Poppins", size=12, weight="bold")

# Entry widget for inputting address
address_entry = Entry(booking_appointment_frame, width=35, bd=0, bg="#D9D9D9", fg="black", font=entry_font)
address_entry.place(x=510, y=250)

# Post Code label
postcode_label = Label(booking_appointment_frame, text="PostCode", font=("Poppins", 12, "bold"), bg="white")
postcode_label.place(x=500, y=290)

# Load image for address entry field background
address_entry_field2_image_path = "pictures/Search Clinic Page/Book Appointment/address entry field 3.png"
address_entry_field2_image = PhotoImage(file=address_entry_field2_image_path)

# Create label for the address entry field image
address_entry_field2_label = Label(booking_appointment_frame, image=address_entry_field2_image, bd=0)
address_entry_field2_label.image = address_entry_field2_image  # Keep a reference to the image to prevent garbage collection
address_entry_field2_label.place(x=500, y=320)  # Change coordinates as needed

# Font configuration for the entry field
postcode_font = font.Font(family="Poppins", size=12, weight="bold")

# Entry widget for inputting postcode
postcode_entry = Entry(booking_appointment_frame, width=10, bd=0, bg="#D9D9D9", fg="black", font=postcode_font)
postcode_entry.place(x=510, y=330)  # Change coordinates as needed

# Load image for address entry field background
address_entry_field3_image_path = "pictures/Search Clinic Page/Book Appointment/address entry field 2.png"
address_entry_field3_image = PhotoImage(file=address_entry_field3_image_path)

# State label
state_label = Label(booking_appointment_frame, text="State", font=("Poppins", 12, "bold"), bg="white")
state_label.place(x=750, y=290)

# Create label for the address entry field image
address_entry_field3_label = Label(booking_appointment_frame, image=address_entry_field3_image, bd=0)
address_entry_field3_label.image = address_entry_field3_image  # Keep a reference to the image to prevent garbage collection
address_entry_field3_label.place(x=750, y=320)  # Change coordinates as needed

# Font configuration for the entry field
state_font = font.Font(family="Poppins", size=12, weight="bold")

# Entry widget for inputting postcode
state_entry = Entry(booking_appointment_frame, width=20, bd=0, bg="#D9D9D9", fg="black", font=state_font)
state_entry.place(x=760, y=330)

# City Label
city_label = Label(booking_appointment_frame, text="City", font=("Poppins", 12, "bold"), bg="white")
city_label.place(x=500, y=370)

# Create label for the address entry field image
address_entry_field3_label = Label(booking_appointment_frame, image=address_entry_field3_image, bd=0)
address_entry_field3_label.image = address_entry_field3_image  # Keep a reference to the image to prevent garbage collection
address_entry_field3_label.place(x=500, y=400)  # Change coordinates as needed

# Font configuration for the entry field
state_font = font.Font(family="Poppins", size=12, weight="bold")

# Entry widget for inputting postcode
state_entry = Entry(booking_appointment_frame, width=20, bd=0, bg="#D9D9D9", fg="black", font=state_font)
state_entry.place(x=510, y=410)

# Description Label
description_label = Label(booking_appointment_frame, text="Describe your problem", font=("Poppins", 12, "bold"),
                          bg="white")
description_label.place(x=500, y=440)

# Load image for Description entry field background
description_entry_field_image_path = "pictures/Search Clinic Page/Book Appointment/description entry field.png"
description_entry_field_image = PhotoImage(file=description_entry_field_image_path)

description_label = Label(booking_appointment_frame, image=description_entry_field_image, bd=0)
description_entry_field_image.image = description_entry_field_image
description_label.place(x=500, y=460)

description_font = font.Font(family="Poppins", size=8, weight="bold")
description_entry = Text(booking_appointment_frame, width=35, height=4, bd=0, bg="#D9D9D9", fg="black", font=state_font,
                         wrap=WORD)
description_entry.place(x=510, y=470)

booking_appointment_frame.pack_forget()














# Appointment Page
view_appointment_frame = Frame(root, bg='white')

# View Doctor Page
view_doctor_frame = Frame(root, bg='white')

# Load and display the search clinic entry field image
search_entry_image_path = "pictures/Search Clinic Page/search clinic entry field.png"
search_entry_img = PhotoImage(file=search_entry_image_path)
search_entry_label = Label(view_doctor_frame, image=search_entry_img, bg='white')
search_entry_label.image = search_entry_img
search_entry_label.place(x=100, y=50)  # Adjust the coordinates as needed

# Create the search bar entry field for view doctor page
search_entry_view_doctor = Entry(view_doctor_frame, borderwidth=0, bg='#fff', font=('Montserrat', 12, 'bold'))
search_entry_view_doctor.place(x=110, y=62, width=400)  # Adjust position and width as needed

# Apply placeholder functionality to view doctor entry field
manage_placeholder(search_entry_view_doctor, "Search Doctors...")

# View Doctor Label
view_doctor_label = Label(view_doctor_frame, text="Doctors Available", font=("Poppins", 14, "bold"), bg="white")
view_doctor_label.place(x=100, y=120)

# View Doctor Information

view_doctor1_image_path = "pictures/View Doctor/Doctor 1.png"
view_doctor1_img = PhotoImage(file=view_doctor1_image_path)
view_doctor1_label = Label(view_doctor_frame, image=view_doctor1_img, bg='white')
view_doctor1_label.image = view_doctor1_img
view_doctor1_label.place(x=100, y=200)
view_doctor1_label.bind("<Enter>", on_enter)
view_doctor1_label.bind("<Leave>", on_leave)
view_doctor1_label.bind("<Button-1>", lambda event: navigate_to_doctor1_profile())

view_doctor2_image_path = "pictures/View Doctor/Doctor 2.png"
view_doctor2_img = PhotoImage(file=view_doctor2_image_path)
view_doctor2_label = Label(view_doctor_frame, image=view_doctor2_img, bg='white')
view_doctor2_label.image = view_doctor2_img
view_doctor2_label.place(x=600, y=200)
view_doctor2_label.bind("<Enter>", on_enter)
view_doctor2_label.bind("<Leave>", on_leave)
view_doctor2_label.bind("<Button-1>", lambda event: navigate_to_doctor2_profile())

# Doctor 1 Profile Page

doctor1_profile_frame = Frame(root, bg='white')

doctor1_label = Label(doctor1_profile_frame, text="Doctor Profile", font=("Poppins", 20, "bold"), bg="white")
doctor1_label.place(x=70, y=50)

doctor1_pfp_image_path = "pictures/View Doctor/Doctor1 pfp.png"
doctor1_pfp_img = PhotoImage(file=doctor1_pfp_image_path)
doctor1_pfp_label = Label(doctor1_profile_frame, image=doctor1_pfp_img, bg='white')
doctor1_pfp_label.image = doctor1_pfp_img
doctor1_pfp_label.place(x=100, y=200)

doctor1_name_label = Label(doctor1_profile_frame, text="Name: Dr. Lai Kai Shein", font=("Poppins", 14, "bold"),
                           bg="white")
doctor1_name_label.place(x=400, y=150)

doctor1_contact_label = Label(doctor1_profile_frame, text="Phone: +60 11 2568 1612", font=("Poppins", 14, "bold"),
                              bg="white")
doctor1_contact_label.place(x=400, y=200)

doctor1_email_label = Label(doctor1_profile_frame, text="Email: idontlikesoftwareengineering@gmail.com",
                            font=("Poppins", 14, "bold"), bg="white")
doctor1_email_label.place(x=400, y=250)

assigned_clinic_label = Label(doctor1_profile_frame, text="Assigned Clinic: MD Clinic", font=("Poppins", 14, "bold"),
                              bg="white")
assigned_clinic_label.place(x=400, y=300)

specialty_label = Label(doctor1_profile_frame, text="Specialty: General Physician", font=("Poppins", 14, "bold"),
                        bg="white")
specialty_label.place(x=400, y=350)

experience_label = Label(doctor1_profile_frame, text="Experience: 22 years", font=("Poppins", 14, "bold"), bg="white")
experience_label.place(x=400, y=400)

request_appointment_button_image_path = "pictures/View Doctor/Request Appointment.png"
request_appointment_button_img = PhotoImage(file=request_appointment_button_image_path)
request_appointment_button_label = Label(doctor1_profile_frame, image=request_appointment_button_img, bg='white')
request_appointment_button_label.image = request_appointment_button_img
request_appointment_button_label.place(x=400, y=450)
request_appointment_button_label.bind("<Enter>", on_enter)
request_appointment_button_label.bind("<Leave>", on_leave)
request_appointment_button_label.bind("<Button-1>", lambda event: navigate_to_booking_appointment())

# Doctor 2 Profile Page

doctor2_profile_frame = Frame(root, bg='white')

doctor2_label = Label(doctor2_profile_frame, text="Doctor Profile", font=("Poppins", 20, "bold"), bg="white")
doctor2_label.place(x=70, y=50)

doctor2_pfp_image_path = "pictures/View Doctor/Doctor2 pfp.png"
doctor2_pfp_img = PhotoImage(file=doctor2_pfp_image_path)
doctor2_pfp_label = Label(doctor2_profile_frame, image=doctor2_pfp_img, bg='white')
doctor2_pfp_label.image = doctor2_pfp_img
doctor2_pfp_label.place(x=100, y=200)

doctor2_name_label = Label(doctor2_profile_frame, text="Name: Dr. Lee Ji Eun", font=("Poppins", 14, "bold"), bg="white")
doctor2_name_label.place(x=400, y=150)

doctor2_contact_label = Label(doctor2_profile_frame, text="Phone: +60 12 360 2770", font=("Poppins", 14, "bold"),
                              bg="white")
doctor2_contact_label.place(x=400, y=200)

doctor2_email_label = Label(doctor2_profile_frame, text="Email: leejieun@gmail.com", font=("Poppins", 14, "bold"),
                            bg="white")
doctor2_email_label.place(x=400, y=250)

assigned_clinic_label = Label(doctor2_profile_frame, text="Assigned Clinic: V-Care Clinic",
                              font=("Poppins", 14, "bold"), bg="white")
assigned_clinic_label.place(x=400, y=300)

specialty_label = Label(doctor2_profile_frame, text="Specialty: Dermatologist", font=("Poppins", 14, "bold"),
                        bg="white")
specialty_label.place(x=400, y=350)

experience_label = Label(doctor2_profile_frame, text="Experience: 31 years", font=("Poppins", 14, "bold"), bg="white")
experience_label.place(x=400, y=400)

request_appointment_button_image_path = "pictures/View Doctor/Request Appointment.png"
request_appointment_button_img = PhotoImage(file=request_appointment_button_image_path)
request_appointment_button_label = Label(doctor2_profile_frame, image=request_appointment_button_img, bg='white')
request_appointment_button_label.image = request_appointment_button_img
request_appointment_button_label.place(x=400, y=450)
request_appointment_button_label.bind("<Enter>", on_enter)
request_appointment_button_label.bind("<Leave>", on_leave)
request_appointment_button_label.bind("<Button-1>", lambda event: navigate_to_booking_appointment())

view_doctor_frame.pack_forget()

# Settings Page
settings_frame = Frame(root, bg='white')

settings_label = Label(settings_frame, text="User Profile", font=("Poppins", 20, "bold"), bg="white")
settings_label.place(x=70, y=50)

first_name_label = Label(settings_frame, text="First Name", font=("Poppins", 14, "bold"), bg="white")
first_name_label.place(x=400, y=120)

first_name_entry = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 16, 'bold'))
first_name_entry.place(x=400, y=160, width=150)

last_name_label = Label(settings_frame, text="Last Name", font=("Poppins", 14, "bold"), bg="white")
last_name_label.place(x=700, y=120)

last_name_entry = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 16, 'bold'))
last_name_entry.place(x=700, y=160, width=150)

user_contact_label = Label(settings_frame, text="Phone Number", font=("Poppins", 14, "bold"), bg="white")
user_contact_label.place(x=400, y=210)

user_contact_entry = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 16, 'bold'))
user_contact_entry.place(x=400, y=250, width=300)

user_email_label = Label(settings_frame, text="Email", font=("Poppins", 14, "bold"), bg="white")
user_email_label.place(x=400, y=290)

user_email_entry = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 16, 'bold'))
user_email_entry.place(x=400, y=330, width=300)

user_address_label = Label(settings_frame, text="Address", font=("Poppins", 14, "bold"), bg="white")
user_address_label.place(x=400, y=370)

user_address_entry = Text(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12, 'bold'), wrap=WORD)
user_address_entry.place(x=400, y=410, width=300, height=100)  # Adjust position, width, and height as needed


def select_and_display_image():
    # Open file dialog to select an image
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg;*.jpeg;*.png;*.gif")])
    if file_path:
        # Load and resize the image
        img = Image.open(file_path)
        img = img.resize((191, 201), Image.ANTIALIAS)
        img_tk = ImageTk.PhotoImage(img)

        # Display the image in the label
        image_label.config(image=img_tk)
        image_label.image = img_tk  # Keep a reference to avoid garbage collection


def delete_image():
    # Remove the image from the label
    image_label.config(image='')
    image_label.image = None  # Clear the reference to the image


# Button to insert picture
insert_picture_button_image_path = "pictures/Settings/Insert Picture button.png"
insert_picture_button_img = tk.PhotoImage(file=insert_picture_button_image_path)
insert_picture_button_label = tk.Label(settings_frame, image=insert_picture_button_img, bg='white')
insert_picture_button_label.image = insert_picture_button_img
insert_picture_button_label.place(x=95, y=450)

# Bind the button click to open file dialog
insert_picture_button_label.bind("<Button-1>", lambda e: select_and_display_image())

# Label to display the selected image
image_label = tk.Label(settings_frame, bg='white')
image_label.place(x=105, y=200, width=190, height=200)  # Adjust position as needed

# Button to delete picture
delete_picture_button_image_path = "pictures/Settings/Delete Picture button.png"
delete_picture_button_img = tk.PhotoImage(file=delete_picture_button_image_path)
delete_picture_button_label = tk.Label(settings_frame, image=delete_picture_button_img, bg='white')
delete_picture_button_label.image = delete_picture_button_img
delete_picture_button_label.place(x=95, y=500)

# Bind the delete button to the delete_image function
delete_picture_button_label.bind("<Button-1>", lambda e: delete_image())

# Cancel button

cancel_button_image_path = "pictures/Settings/Cancel button.png"
cancel_button_img = tk.PhotoImage(file=cancel_button_image_path)
cancel_button_label = tk.Label(settings_frame, image=cancel_button_img, bg='white')
cancel_button_label.image = cancel_button_img
cancel_button_label.place(x=750, y=500)
cancel_button_label.bind("<Enter>", on_enter)
cancel_button_label.bind("<Leave>", on_leave)
cancel_button_label.bind("<Button-1>", lambda event: navigate_to_homepage())

# Submit button

save_button_image_path = "pictures/Settings/Save button.png"
save_button_img = tk.PhotoImage(file=save_button_image_path)
save_button_label = tk.Label(settings_frame, image=save_button_img, bg='white')
save_button_label.image = save_button_img
save_button_label.place(x=900, y=500)
save_button_label.bind("<Enter>", on_enter)
save_button_label.bind("<Leave>", on_leave)
save_button_label.bind("<Button-1>", lambda event: navigate_to_homepage())

root.mainloop()
