import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
from tkcalendar import Calendar
from tkinter import messagebox
import datetime
from user_home_pages.sidebar import Sidebar
from firebase_config import database


class Booking:
    def __init__(self, app, username, name, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = None

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')
        self.username = username or self.app.get_shared_data("username")
        self.dc_name = dc_name or self.app.get_shared_data("dc_name")
        self.name = name
        self.images = {}
        self.time_buttons = []  # List to store time button instances

        # Create a frame for clinic details
        booking_frame = Frame(self.frame, bg='white')
        booking_frame.pack(side='left', fill='both', expand=True)

        # Clinic name for testing (replace with actual retrieval logic)
        self.clinic_name = self.app.get_shared_data("name")
        clinic_data = self.get_clinic_data(self.clinic_name)
        booking_label = Label(booking_frame, text=f"Make Booking at | {clinic_data.get('name', 'N/A')} |",
                              font=('Helvetica', 20, 'bold'), bg='white')
        booking_label.pack(pady=20)

        # Initialize selected_date and selected_time
        self.selected_date = None
        self.selected_time = None
        self.selected_doctor = None
        self.selected_button_time = None  # Track the currently selected button
        self.selected_button_doctor = None

        select_date = Label(booking_frame, text="Select date", font=('Helvetica', 14, 'underline'), bg='white')
        select_date.place(x=50, y=80)

        # Embed the calendar directly in the booking_frame
        self.cal = Calendar(booking_frame, selectmode='day', date_pattern='yyyy-mm-dd')
        self.cal.place(x=50, y=120, width=300, height=180)

        # Retrieve opening and closing times from clinic_data or use default values
        self.opening_time = clinic_data.get('open_time', '00:00')
        self.closing_time = clinic_data.get('close_time', '23:00')

        # Convert open_time and close_time to datetime objects for easier manipulation
        fmt = "%H:%M"  # Format for parsing times like "13:00"
        open_datetime = datetime.datetime.strptime(self.opening_time, fmt)
        close_datetime = datetime.datetime.strptime(self.closing_time, fmt)

        # Initialize an empty array to store current_time values
        current_time = []

        # Start generating times from open_time to close_time with 1-hour intervals
        current = open_datetime  # Use datetime objects for accurate time comparison

        while current < close_datetime:
            current_time.append(current.strftime(fmt))  # Append formatted time string
            current += datetime.timedelta(hours=1)  # Increment current time by 1 hour

        select_time = Label(booking_frame, text="Select time", font=('Helvetica', 14, 'underline'), bg='white')
        select_time.place(x=400, y=80)

        # Create buttons dynamically based on current_time
        button_positions = [
            (400, 120), (480, 120), (560, 120), (640, 120),
            (400, 170), (480, 170), (560, 170), (640, 170),
            (400, 220), (480, 220), (560, 220), (640, 220),
            (400, 270), (480, 270), (560, 270), (640, 270)
        ]

        self.button_states = {}
        for idx, time_str in enumerate(current_time):
            if idx < len(button_positions):
                x, y = button_positions[idx]
                operating_button = Button(booking_frame, text=time_str,
                                          compound='center', bg='white', fg='black', font=('Helvetica', 10, 'bold'))
                operating_button.place(x=x, y=y, width=75, height=40)
                operating_button.config(
                    command=lambda btn=operating_button, time=time_str: self.get_time_and_change_color(btn, time))

                self.button_states[operating_button] = False  # False for white, True for selected color

        # user = self.app.get_shared_data("username")
        self.email = database.child('User').child(username).child('email').get().val()
        self.phone = database.child('User').child(username).child('phone').get().val()

        select_text = Label(booking_frame, text="Select an doctor(optional)", font=('Helvetica', 14, 'underline'),
                            bg='white')
        select_text.place(x=50, y=330)

        all_doctor_details = database.child('Doctor').get().val()
        if all_doctor_details:
            # Filter doctors based on work_clinic attribute
            doctors_in_clinic = [doctor for doctor in all_doctor_details.values()
                                 if doctor.get('work_clinic') == clinic_data.get('name', 'N/A')]
            if doctors_in_clinic:
                y_start = 370

                for idx, doctor in enumerate(doctors_in_clinic):
                    y = y_start + idx * 70

                    doctor_button = Button(booking_frame,
                                           text=f"Doctor Name: {doctor['dc_name']}\nDoctor Email: {doctor['dc_email']}\nDoctor Specialty: {doctor['dc_specialty']}",
                                           bg='white', fg='black', font=('Helvetica', 10, 'bold'),
                                           compound='left')  # Adjust compound as needed
                    doctor_button.place(x=50, y=y, width=300, height=60)  # Adjust width and height as needed
                    doctor_button.config(
                        command=lambda btn=doctor_button, doctor_show=doctor: self.get_doctor_and_change_color(btn,
                                                                                                               doctor_show))
                    self.button_states[doctor_button] = False  # False for white, True for purple
                    # Check if the current doctor button matches self.dc_name and initialize as blue
                    if doctor['dc_name'] == self.dc_name:
                        doctor_button.config(bg='#ADD8E6')
                        self.selected_doctor = self.dc_name
                        self.selected_button_doctor = doctor_button
                        self.button_states[doctor_button] = True
            else:
                print("No doctors found working at this clinic.")
        else:
            print("No doctors found in the database.")

        desc_text_label = Label(booking_frame, text="Describe your problem(optional)",
                                font=('Helvetica', 14, 'underline'),
                                bg='white')
        desc_text_label.place(x=400, y=330)

        # Assuming 'pictures/Search Clinic Page/desc_label.png' is a valid path
        desc_path = 'pictures/Search Clinic Page/desc_label.png'
        desc_entry_img = Image.open(desc_path).resize((300, 120), Image.Resampling.LANCZOS)
        desc_entry_img = ImageTk.PhotoImage(desc_entry_img)  # Corrected line to use the correct format

        # Store the image in a dictionary to prevent garbage collection
        desc_path = 'pictures/Search Clinic Page/desc_label.png'
        desc_entry_img = Image.open(desc_path).resize((300, 120), Image.Resampling.LANCZOS)
        self.images['desc'] = ImageTk.PhotoImage(desc_entry_img)

        desc_img = Label(booking_frame, image=self.images['desc'], bg='white')
        desc_img.place(x=405, y=380)

        # Create the Entry widget with a background color matching the Label's background
        self.desc_entry = Text(booking_frame, width=130, fg='black', bd=0, font=('Helvetica', 9), bg='#E5E4E2')
        self.desc_entry.place(x=420, y=390, width=275, height=100)

        button_path = 'pictures/Search Clinic Page/Book Appointment/submit button.png'
        confirm_button_img = Image.open(button_path).resize((200, 50), Image.LANCZOS)
        self.images['button'] = ImageTk.PhotoImage(confirm_button_img)
        confirm_button = Button(booking_frame, image=self.images['button'], command=self.set_date, bg='white',
                                fg='white')
        #confirm_button = Button(booking_frame, image=self.images['button'], command=lambda doctor_show=doctor, time=time_str: self.set_date(doctor_show,time), bg='white', fg='white')

        confirm_button.place(x=470, y=530)
        # command=lambda btn=doctor_button, doctor_show=doctor: self.get_doctor_and_change_color(btn,doctor_show))

    def get_time_and_change_color(self, button, time_str):
        if self.selected_button_time and self.selected_button_time != button:
            self.selected_button_time.config(bg='white')  # Reset the previous button color
            self.button_states[self.selected_button_time] = False  # Update its state

        current_state = self.button_states[button]

        if current_state:
            button.config(bg='white')
            self.selected_time = None
        else:
            button.config(bg='#ADD8E6')
            self.selected_time = time_str

        self.button_states[button] = not current_state
        self.selected_button_time = button if not current_state else None  # Update the selected button
        return self.selected_time

    # selected_button_doctor
    def get_doctor_and_change_color(self, button, doctor):
        # Reset the previously selected button if it is different from the current one
        if self.selected_button_doctor and self.selected_button_doctor != button:
            self.selected_button_doctor.config(bg='white')  # Reset the previous button color
            self.button_states[self.selected_button_doctor] = False  # Update its state

        current_state = self.button_states[button]

        if current_state:
            button.config(bg='white')
            self.selected_doctor = None  # Deselect the doctor
        else:
            button.config(bg='#ADD8E6')
            self.selected_doctor = doctor["dc_name"]  # Select the doctor

        # Update button state and selected button
        self.button_states[button] = not current_state
        self.selected_button_doctor = button if not current_state else None  # Update the selected button
        return self.selected_doctor

    def set_date(self):
        selected_date_str = self.cal.get_date()

        try:
            self.selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Please select a valid date.")
            return

        if self.selected_date < datetime.date.today():
            messagebox.showerror("Error", "Please select a date that is not in the past.")
            return

        if not self.selected_time:
            messagebox.showerror("Error", "Please select a time.")
            return

        if self.desc_entry:
            desc_text = self.desc_entry.get("1.0", "end-1c")
        else:
            desc_text = None

        message = f"Your selected date -> {self.selected_date}\nYour selected time -> {self.selected_time}"
        if self.selected_doctor:
            message += f"\nYour selected doctor -> dr.{self.selected_doctor}"
        else:
            message += "\nYour selected doctor -> EMPTY"

        now = datetime.datetime.now()
        current_datetime_str = now.strftime("%Y-%m-%d %H:%M:%S")
        message += f"\nAppointment generated date -> {current_datetime_str}"

        message += f"\n\nYour appointment made by\nPatient name -> {self.username}\nPatient contact -> {self.phone}"
        message += f"\n\nYour appointment location\nClinic name -> {self.clinic_name}\nProblem describe -> {desc_text}"

        messagebox.showinfo("Appointment Successful Made", message)

        time_parts = self.selected_time.split(':')
        hour = int(time_parts[0])
        minute = int(time_parts[1])
        time_obj = datetime.time(hour, minute)

        combined_datetime = datetime.datetime.combine(self.selected_date, time_obj)
        combined_date_and_time = combined_datetime.strftime("%Y-%m-%d %H:%M")

        appointment_data = {
            "appointment_date": combined_date_and_time,
            "patient_id": str(self.username),  # Convert to string if necessary
            "patient_email": str(self.email),  # Convert to string if necessary
            "doctor_name": str(self.selected_doctor),  # Convert to string if necessary
            "appointment_generated_date": current_datetime_str,
            "desc_problems": desc_text,  # Convert to string if necessary
            "appointment_clinic": str(self.clinic_name)  # Convert to string if necessary
        }

        database.child("BookAppointment").child(self.username).child(combined_date_and_time).set(appointment_data)
        self.app.show_page("booking")

    def get_clinic_data(self, clinic_name):
        try:
            # Replace with your actual database retrieval logic
            clinic_details = database.child('Clinic').child(clinic_name).get().val()
            return clinic_details or {}  # Return empty dictionary if clinic_details is None
        except Exception as e:
            messagebox.showerror("Error", f"Failed to retrieve clinic data: {str(e)}")
            return {}
