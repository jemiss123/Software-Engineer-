import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
from user_home_pages.sidebar import Sidebar
from firebase_config import database
from tkinter import messagebox
import random


class HomePage:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username or self.app.get_shared_data("username")
        # Create frame for homepage content
        # homepage_frame = Frame(self.frame, bg='white')
        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')
        self.images = {}

        # Home page content
        self.homepage_frame = Frame(self.frame, bg='white')
        self.homepage_frame.pack(fill='both', expand=True, padx=20)  # Adjust padding as needed

        # Load and display the welcome image
        welcome_image_path = "pictures/HomePage/welcome_text.png"
        welcome_image = Image.open(welcome_image_path).resize((680, 150), Image.LANCZOS)
        self.homepage_welcome_text_img = ImageTk.PhotoImage(welcome_image)
        homepage_welcome_text_label = Label(self.homepage_frame, image=self.homepage_welcome_text_img, bg='white')
        homepage_welcome_text_label.place(x=20, y=30)

        # Display upcoming appointment
        showing_recent_appointment = Label(self.homepage_frame, text="Upcoming Appointment",
                                           font=('Helvetica', 14, 'underline'),
                                           bg='white')
        showing_recent_appointment.place(x=20, y=200)

        # Display appointment frame
        display_appointment_path = 'pictures/Search Clinic Page/Rectangle.png'
        display_appointment_image = Image.open(display_appointment_path).resize((680, 100), Image.LANCZOS)
        self.appointment_image = ImageTk.PhotoImage(display_appointment_image)
        appointment_img_label = Label(self.homepage_frame, image=self.appointment_image, bg='white')
        appointment_img_label.place(x=20, y=230)

        # Display appointment information if available
        self.display_appointment()

        # Display self health status
        showing_self_status = Label(self.homepage_frame, text="Current Health Status",
                                    font=('Helvetica', 14, 'underline'),
                                    bg='white')
        showing_self_status.place(x=20, y=350)

        display_status_path = 'pictures/HomePage/show_doctor_frame.png'
        display_status_image = Image.open(display_status_path).resize((300, 170), Image.LANCZOS)
        self.display_status_image = ImageTk.PhotoImage(display_status_image)

        self.canvas = tk.Canvas(self.homepage_frame, width=300, height=170, bg='white', bd=0, highlightthickness=0)
        self.canvas.place(x=20, y=380)  # Place the canvas at the specified coordinates
        self.canvas.create_image(0, 0, anchor='nw', image=self.display_status_image)

        # Create a label with the username and place it on the canvas
        name_label = tk.Label(self.canvas, text=f"Name: {username}", font=("Work Sans", 16, "bold"), bg='#D9D9D9')
        self.canvas.create_window(10, 10, anchor='nw', window=name_label)

        self.update_user_info()

        # Display random doctor
        showing_recent_doctor = Label(self.homepage_frame, text="Doctor Suggestion",
                                      font=('Helvetica', 14, 'underline'),
                                      bg='white')
        showing_recent_doctor.place(x=400, y=350)
        self.selected_button_doctor = None
        self.selected_doctor = None
        self.fetch_doctors_in_clinic()

    def fetch_appointment_data(self):
        try:
            appointments_snapshot = database.child('BookAppointment').child(self.username).get()
            if appointments_snapshot.each():
                # Convert snapshot to list of dictionaries
                appointments_list = [appointment.val() for appointment in appointments_snapshot.each()]
                return appointments_list[0]  # Return the first appointment
            else:
                return None
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch appointment data: {e}")
            return None

    def display_appointment(self):
        appointment_db = self.fetch_appointment_data()

        if appointment_db:
            appointment_date = appointment_db.get("appointment_date", "N/A")
            appointment_date_label = tk.Label(self.homepage_frame,
                                              text=f"{appointment_date} | {appointment_db.get('appointment_clinic', 'N/A')}",
                                              font=("Work Sans", 16, "bold"), bg='#D9D9D9')
            appointment_date_label.place(x=40, y=240)

            patient_name_label = tk.Label(self.homepage_frame,
                                          text=f"Patient Name: {appointment_db.get('patient_id', 'N/A')}",
                                          font=("Arial", 12), bg='#D9D9D9')
            patient_name_label.place(x=40, y=275)

            patient_email_label = tk.Label(self.homepage_frame,
                                           text=f"Patient Email: {appointment_db.get('patient_email', 'N/A')}",
                                           font=("Arial", 12), bg='#D9D9D9')
            patient_email_label.place(x=40, y=300)

            doctor_name_label = tk.Label(self.homepage_frame,
                                         text=f"Doctor Name: Dr.{appointment_db.get('doctor_name', 'N/A')}",
                                         font=("Arial", 12), bg='#D9D9D9')
            doctor_name_label.place(x=330, y=275)

            desc_problems_label = tk.Label(self.homepage_frame,
                                           text=f"Describe problems: {appointment_db.get('desc_problems', 'N/A')}",
                                           font=("Arial", 12), bg='#D9D9D9')
            desc_problems_label.place(x=330, y=300)

            view_more_label = tk.Button(self.homepage_frame,
                                        text="View more appointment",  # Use \n for line break
                                        font=("Arial", 10, 'underline'), bg='#D9D9D9',
                                        command=lambda: self.app.show_page("appointment"))  # Center align text
            view_more_label.place(x=540, y=240)

        else:
            # Display a message or handle no appointment data scenario
            no_appointment_label = tk.Label(self.homepage_frame, text="No appointment data found", font=("Arial", 12),
                                            bg='white')
            no_appointment_label.pack(pady=50)

    def fetch_doctors_in_clinic(self):
        # Assuming self.homepage_frame is defined somewhere in your class or method
        self.button_states = {}
        all_doctor_details = database.child('Doctor').get().val()
        if all_doctor_details:
            all_doctors_list = list(all_doctor_details.values())

            random_doctors = []
            for _ in range(3):  # Select 3 random doctors
                doctor = random.choice(all_doctors_list)
                random_doctors.append(doctor)
                all_doctors_list.remove(doctor)

            y_start = 380

            for idx, doctor in enumerate(random_doctors):
                y = y_start + idx * 70

                doctor_button = Button(self.homepage_frame,
                                       text=f"Doctor Name: {doctor['dc_name']}\nDoctor Email: {doctor['dc_email']}\nDoctor Specialty: {doctor['dc_specialty']}",
                                       bg='white', fg='black', font=('Helvetica', 10, 'bold'),
                                       compound='left')  # Adjust compound as needed
                doctor_button.place(x=400, y=y, width=300, height=60)  # Adjust width and height as needed
                doctor_button.config(
                    command=lambda btn=doctor_button, doc=doctor: self.get_doctor_and_change_color(btn, doc))
                self.button_states[doctor_button] = False  # False for white, True for purple
        else:
            print("No doctors found in the database.")

    def get_doctor_and_change_color(self, button, doctor):
        # Reset the previously selected button if it is different from the current one
        if self.selected_button_doctor and self.selected_button_doctor != button:
            self.selected_button_doctor.config(bg='white')  # Reset the previous button color
            self.button_states[self.selected_button_doctor] = False  # Update its state

        current_state = self.button_states.get(button, False)

        if current_state:
            button.config(bg='white')

        else:
            button.config(bg='#ADD8E6')

        # Update button state and selected button
        self.button_states[button] = not current_state
        self.selected_button_doctor = button if not current_state else None  # Update the selected button
        self.selected_doctor = doctor['dc_name']
        clinic_name = doctor['work_clinic']
        messagebox.showinfo("Confirmation", f"Made a appointment with Dr.{self.selected_doctor}?")
        self.app.set_shared_data("dc_name", self.selected_doctor)
        self.app.set_shared_data("name", clinic_name)
        self.app.show_page("booking")

    def update_user_info(self):
        # Fetch data from the database and handle potential None values
        height_cm = database.child('User').child(self.username).child('height_CM').get().val()
        weight_kg = database.child('User').child(self.username).child('weight_KG').get().val()
        print(f"height: {height_cm}, weight: {weight_kg}")

        if height_cm is not None and weight_kg is not None:
            try:
                height_cm = float(height_cm)  # Convert height_cm to float
                weight_kg = float(weight_kg)  # Convert weight_kg to float

                height_m = height_cm / 100

                bmi = weight_kg / (height_m ** 2)
                bmi_category = self.get_bmi_category(bmi)

                # Update labels with retrieved data and BMI category
                weight_label = tk.Label(self.canvas, text=f"Current Weight: {weight_kg} kg", font=("Work Sans", 12),
                                        bg='#D9D9D9')
                self.canvas.create_window(10, 50, anchor='nw', window=weight_label)

                height_label = tk.Label(self.canvas, text=f"Current Height: {height_cm} cm", font=("Work Sans", 12),
                                        bg='#D9D9D9')
                self.canvas.create_window(10, 80, anchor='nw', window=height_label)

                bmi_label = tk.Label(self.canvas, text=f"Current BMI: {bmi:.2f}", font=("Work Sans", 12),
                                     bg='#D9D9D9')
                self.canvas.create_window(10, 110, anchor='nw', window=bmi_label)

                bmi_category_label = tk.Label(self.canvas, text=f"Current BMI Category: {bmi_category}",
                                              font=("Work Sans", 12),
                                              bg='#D9D9D9')
                self.canvas.create_window(10, 140, anchor='nw', window=bmi_category_label)

            except ValueError as e:
                print(f"Error converting weight or height: {e}")
        else:
            print("Height or weight data not found in the database.")
            # Optionally handle the case where height or weight data is not available

    def get_bmi_category(self, bmi):
        if bmi < 18.5:
            return "Underweight"
        elif 18.5 <= bmi <= 24.9:
            return "Normal weight"
        elif 25.0 <= bmi <= 29.9:
            return "Overweight"
        else:
            return "Obese"
