import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
from user_home_pages.sidebar import Sidebar
from firebase_config import database


class HomePage:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username or self.app.get_shared_data("username")
        # Create frame for homepage content
        # homepage_frame = Frame(self.frame, bg='white')
        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Home page content
        homepage_frame = Frame(self.frame, bg='white')
        homepage_frame.pack(fill='both', expand=True, padx=20)  # Adjust padding as needed

        # Load and display the homepage search bar image
        # homepage_search_bar_image_path = "pictures/HomePage/homepage search bar.png"
        # homepage_search_bar_img = PhotoImage(file=homepage_search_bar_image_path)
        #         search_clinic_entry_img = ImageTk.PhotoImage(Image.open('pictures/Search Clinic Page/search clinic entry field.png').resize((200, 50),
        #                                                                                     Image.Resampling.LANCZOS))
        homepage_search_bar_img = ImageTk.PhotoImage(
            Image.open('pictures/Search Clinic Page/search clinic entry field.png').resize((450, 70),
                                                                                           Image.Resampling.LANCZOS))
        homepage_search_bar_label = Label(homepage_frame, image=homepage_search_bar_img, bg='white')
        homepage_search_bar_label.image = homepage_search_bar_img
        homepage_search_bar_label.place(x=100, y=50)  # Adjust the coordinates as needed

        # Load and display the homepage search icon image
        homepage_search_icon_image_path = "pictures/HomePage/homepage search icon.png"
        homepage_search_icon_img = PhotoImage(file=homepage_search_icon_image_path)
        homepage_search_icon_label = Label(homepage_frame, image=homepage_search_icon_img, bg='white')
        homepage_search_icon_label.image = homepage_search_icon_img
        homepage_search_icon_label.place(x=120, y=75)  # Adjust the coordinates as needed

        # Create the search bar entry field
        search_entry = Entry(homepage_search_bar_label, borderwidth=0, bg='#fff', font=('Montserrat', 12, 'bold'))
        search_entry.place(x=80, y=25, width=320)  # Adjust position and width as needed

        # Load and display the search button image
        search_button_img = ImageTk.PhotoImage(
            Image.open('pictures/HomePage/search button.png').resize((110, 50), Image.Resampling.LANCZOS))
        # search_button_image_path = "pictures/HomePage/search button.png"
        # search_button_img = PhotoImage(file=search_button_image_path)
        search_button_label = Label(homepage_frame, image=search_button_img, bg='white')
        search_button_label.image = search_button_img
        search_button_label.place(x=560, y=60)  # Adjust the coordinates as needed
        # search_button_label.bind("<Button-1>", lambda event: perform_search())  # Bind click event to search button
        search_button_label.bind("<Button-1>")

        # Display username

        username_label = Label(homepage_frame, text=f"Welcome, {username}", font=('Helvetica', 14), bg='white')
        username_label.pack(pady=10)

        data = database.child('User').child(username).child('password').get().val()
        username_label = Label(homepage_frame, text=f"Welcome, {data}", font=('Helvetica', 14), bg='white')
        username_label.pack(pady=20)

        homepage_frame.pack(fill=BOTH, expand=True)

