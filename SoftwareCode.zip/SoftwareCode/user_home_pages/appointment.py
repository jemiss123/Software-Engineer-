import tkinter as tk
from tkinter import *
from tkinter import messagebox

from PIL import Image, ImageTk
from user_home_pages.sidebar import Sidebar
from firebase_config import database


# Unable to scroll the page
class Appointment:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = None
        self.image_references = []  # To hold image references
        self.username = username or self.app.get_shared_data("username")

        self.view_appointment()
        print(username)

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

    def view_appointment(self):
        self.view_appointment_frame = tk.Frame(self.frame, bg='white')
        self.view_appointment_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=50)

        heading_label = tk.Label(self.view_appointment_frame, text=f"Recent Appointment | {self.username}",
                                 font=("Arial", 18, "bold"), bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas_appointment = tk.Canvas(self.view_appointment_frame, bg='white')
        self.canvas_appointment.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar_appointment = tk.Scrollbar(self.view_appointment_frame, orient=tk.VERTICAL, command=self.canvas_appointment.yview)
        scrollbar_appointment.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas_appointment.configure(yscrollcommand=scrollbar_appointment.set)
        self.canvas_appointment.bind('<Configure>', lambda e: self.canvas_appointment.configure(scrollregion=self.canvas_appointment.bbox('all')))

        self.view_appointment_container = tk.Frame(self.canvas_appointment, bg='white')
        self.canvas_appointment.create_window((0, 0), window=self.view_appointment_container, anchor='nw')

        # Update the bind event to handle different operating systems
        self.canvas_appointment.bind_all("<MouseWheel>", self.on_mouse_wheel_appointment)
        # self.canvas.bind_all("<Button-4>", self.on_mouse_wheel)
        # self.canvas.bind_all("<Button-5>", self.on_mouse_wheel)

        self.display_appointment()

    def on_mouse_wheel_appointment(self, event):
        if event.num == 4 or event.delta > 0:
            self.canvas_appointment.yview_scroll(-1, "units")
        elif event.num == 5 or event.delta < 0:
            self.canvas_appointment.yview_scroll(1, "units")

    def fetch_appointment_data(self):
        try:
            # appointments = database.child('BookAppointment').get()
            appointments = database.child('BookAppointment').child(self.username).get()
            if appointments.each():
                return [appointments.val() for appointments in appointments.each()]
            else:
                return []
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data: {e}")
            return []

    def create_view_appointment_rectangle(self, appointment):
        appointment_frame = tk.Frame(self.view_appointment_container, bg='black')
        appointment_frame.pack(padx=10, pady=10, fill=tk.X)

        Rectangle_for_clinic_path = 'pictures/Search Clinic Page/Rectangle.png'
        Rectangle_for_clinic_img = PhotoImage(file=Rectangle_for_clinic_path)
        self.image_references.append(Rectangle_for_clinic_img)

        canvas = tk.Canvas(appointment_frame, width=Rectangle_for_clinic_img.width(),
                           height=Rectangle_for_clinic_img.height(), bg='white', bd=0, highlightthickness=0)
        canvas.pack()

        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        appointment_date = appointment.get("appointment_date", "N/A")
        appointment_date_label = tk.Label(canvas, text=f"{appointment_date} | {appointment.get('appointment_clinic', 'N/A')}", font=("Work Sans", 16, "bold"),
                                          bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=appointment_date_label)

        patient_name_label = tk.Label(appointment_frame, text=f"Patient Name: {appointment.get('patient_id', 'N/A')}",
                                      font=("Arial", 12),
                                      bg='#D9D9D9')
        patient_name_label.place(x=20, y=50)

        patient_email_label = tk.Label(appointment_frame,
                                       text=f"Patient Email: {appointment.get('patient_email', 'N/A')}",
                                       font=("Arial", 12), bg='#D9D9D9')
        patient_email_label.place(x=20, y=80)

        doctor_name_label = tk.Label(appointment_frame, text=f"Doctor Name: Dr.{appointment.get('doctor_name', 'N/A')}",
                                     font=("Arial", 12), bg='#D9D9D9')
        doctor_name_label.place(x=330, y=50)

        desc_problems_label = tk.Label(appointment_frame, text=f"Describe problems: {appointment.get('desc_problems', 'N/A')}",
                                     font=("Arial", 12), bg='#D9D9D9')
        desc_problems_label.place(x=330, y=80)

    def display_appointment(self):
        appointments = self.fetch_appointment_data()
        for appointment in appointments:
            self.create_view_appointment_rectangle(appointment)
