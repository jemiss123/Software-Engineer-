import tkinter as tk
from tkinter import *
from tkinter import messagebox
from doctor.sidebar import Sidebar
from firebase_config import database


class GeneratePrescriptions:
    def __init__(self, app, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.dc_name = dc_name
        self.image_references = []  # To hold image references

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Settings Page
        generate_prescriptions_frame = Frame(self.frame, bg='white')
        generate_prescriptions_frame.pack(fill='both', expand=True, padx=10)  # Ensure the frame is packed

        # Retrieve doctor details from the database
        doctor_db = database.child('Doctor').get().val()

        doctor = None
        for doc_id, doc_data in doctor_db.items():
            if doc_data.get('dc_name') == self.dc_name:
                doctor = doc_data
                doctor['key'] = doc_id  # Capture the doctor's key for later use
                self.doc_id = doctor['key']
                break

        if doctor:
            self.clinic_name = doctor['work_clinic']
            # Use the fetched clinic in the heading label
            settings_label = Label(generate_prescriptions_frame,
                                   text=f"Generate Prescriptions by Dr.{dc_name} | {self.clinic_name}",
                                   font=("Poppins", 18, "bold"), bg="white")
            settings_label.place(x=50, y=50)

            user_name_label = Label(generate_prescriptions_frame, text="Patient's username",
                                    font=("Poppins", 14, "bold"), bg="white")
            user_name_label.place(x=70, y=120)
            self.user_name_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                         font=('Montserrat', 12))
            self.user_name_entry.place(x=270, y=120, width=300)
            self.user_name_entry.bind("<FocusOut>", self.fetch_appointment_date)  # Fetch date when focus is lost
            self.user_name_entry.bind("<Return>", self.fetch_appointment_date)  # Fetch date when Enter is pressed

            user_display_name_label = Label(generate_prescriptions_frame, text="Patient Name",
                                            font=("Poppins", 14, "bold"), bg="white")
            user_display_name_label.place(x=70, y=160)
            self.user_display_name_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                                 font=('Montserrat', 12))
            self.user_display_name_entry.place(x=270, y=160, width=300)

            appointment_date_label = Label(generate_prescriptions_frame, text="Appointment Date",
                                           font=("Poppins", 14, "bold"), bg="white")
            appointment_date_label.place(x=70, y=200)
            self.appointment_date_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                                font=('Montserrat', 12))
            self.appointment_date_entry.place(x=270, y=200, width=300)

            appointment_time_label = Label(generate_prescriptions_frame, text="Appointment Time",
                                           font=("Poppins", 14, "bold"), bg="white")
            appointment_time_label.place(x=70, y=240)
            self.appointment_time_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                                font=('Montserrat', 12))
            self.appointment_time_entry.place(x=270, y=240, width=300)

            appointment_clinic_label = Label(generate_prescriptions_frame, text="Appointment Clinic",
                                             font=("Poppins", 14, "bold"), bg="white")
            appointment_clinic_label.place(x=70, y=280)
            self.appointment_clinic_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                                  font=('Montserrat', 12))
            self.appointment_clinic_entry.place(x=270, y=280, width=300)

            desc_problem_label = Label(generate_prescriptions_frame, text="Describe problems",
                                       font=("Poppins", 14, "bold"), bg="white")
            desc_problem_label.place(x=70, y=320)
            self.desc_problem_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                            font=('Montserrat', 12))
            self.desc_problem_entry.place(x=270, y=320, width=300)

            medications_label = Label(generate_prescriptions_frame, text="Medications", font=("Poppins", 14, "bold"),
                                      bg="white")
            medications_label.place(x=70, y=360)
            self.medications_entry = Entry(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                           font=('Montserrat', 12))
            self.medications_entry.place(x=270, y=360, width=300)

            instructions_label = Label(generate_prescriptions_frame, text="Instructions", font=("Poppins", 14, "bold"),
                                       bg="white")
            instructions_label.place(x=70, y=400)
            self.instructions_entry = Text(generate_prescriptions_frame, borderwidth=1, bg='#E5E5E5',
                                           font=('Montserrat', 12), wrap=WORD)
            self.instructions_entry.place(x=270, y=400, width=300, height=100)

        def validate_save_button():
            c1 = self.user_name_entry.get()
            c2 = self.user_display_name_entry.get()
            c3 = self.medications_entry.get()
            c4 = self.instructions_entry.get("1.0", "end-1c") if self.instructions_entry else None
            phone = database.child("User").child(c1).child("phone").get().val()
            email = database.child("User").child(c1).child("email").get().val()

            # Validate input fields
            if any(value == "" for value in [c1, c2, c3, c4]):
                messagebox.showerror("Error", "All fields are required")
            else:
                prescription_data = {
                    "patient_name": c2,
                    "user_name": c1,
                    "medications": c3,
                    "instructions": c4,
                    "appointment_date": self.appointment_date,
                    "appointment_time": self.appointment_time,
                    "clinic_name": self.clinic_name,
                    "doctor_name": self.dc_name,
                    "doctor_id": self.doc_id,
                    "user_email": email,
                    "user_phone": phone,
                    "desc_problem": self.desc_problem
                }
                database.child("Prescription").push(prescription_data)
                self.app.show_page("generate_prescriptions")
                self.clear_entry_fields()

        save_button_image_path = "pictures/Settings/Save button.png"
        save_button_img = tk.PhotoImage(file=save_button_image_path)
        save_button_label = tk.Label(generate_prescriptions_frame, image=save_button_img, bg='white')
        save_button_label.image = save_button_img

        cancel_button_image_path = "pictures/Settings/Cancel button.png"
        cancel_button_img = tk.PhotoImage(file=cancel_button_image_path)
        cancel_button_label = tk.Label(generate_prescriptions_frame, image=cancel_button_img, bg='white')
        cancel_button_label.image = cancel_button_img

        cancel_button = Button(generate_prescriptions_frame, image=cancel_button_img,
                               command=lambda: self.app.show_page("generate_prescriptions"),
                               borderwidth=0, bg='white', activebackground='white')
        cancel_button.place(x=350, y=520)

        save_button = Button(generate_prescriptions_frame, image=save_button_img, command=validate_save_button,
                             borderwidth=0, bg='white', activebackground='white')
        save_button.place(x=450, y=520)

    def fetch_appointment_date(self, event):
        username = self.user_name_entry.get()
        ref = database.child("Appointment")
        appointment_data = ref.get()

        # Clear the entries by default
        self.appointment_date_entry.delete(0, tk.END)
        self.appointment_date_entry.insert(0, "N/A")
        self.appointment_time_entry.delete(0, tk.END)
        self.appointment_time_entry.insert(0, "N/A")
        self.appointment_clinic_entry.delete(0, tk.END)
        self.appointment_clinic_entry.insert(0, "N/A")
        self.desc_problem_entry.delete(0, tk.END)
        self.desc_problem_entry.insert(0, "N/A")

        if username and self.clinic_name and appointment_data.each():
            for appointment in appointment_data.each():
                if appointment.val().get("user_name") == username and appointment.val().get(
                        "clinic_Name") == self.clinic_name:
                    self.appointment_date = appointment.val().get("appointment_date", "")
                    self.appointment_time = appointment.val().get("appointment_time", "")
                    self.appointment_clinic = appointment.val().get("clinic_Name", "")
                    self.desc_problem = appointment.val().get("desc_problem", "")

                    self.appointment_date_entry.delete(0, tk.END)
                    self.appointment_date_entry.insert(0, self.appointment_date)
                    self.appointment_time_entry.delete(0, tk.END)
                    self.appointment_time_entry.insert(0, self.appointment_time)
                    self.appointment_clinic_entry.delete(0, tk.END)
                    self.appointment_clinic_entry.insert(0, self.appointment_clinic)
                    self.desc_problem_entry.delete(0, tk.END)
                    self.desc_problem_entry.insert(0, self.desc_problem)
                    break

    # Function to clear all inputs
    def clear_entry_fields(self):
        # Clear entry fields
        self.user_name_entry.delete(0, 'end')
        self.user_display_name_entry.delete(0, 'end')
        self.medications_entry.delete(0, 'end')
        self.appointment_date_entry.delete(0, 'end')
        self.appointment_time_entry.delete(0, 'end')
        self.appointment_clinic_entry.delete(0, 'end')
        self.instructions_entry.delete('1.0', 'end')
