'''import tkinter as tk
from tkinter import ttk, messagebox
from firebase_config import database
from admin.sidebar import Sidebar
from datetime import datetime, time


# after login, will show home page
class Admin_HomePage:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Function to show a dialog box for status change
        def change_status_dialog(item):
            result = messagebox.askquestion(
                "Change Status",
                "Do you want to accept or reject this request?",
                icon='question'
            )

            if result == 'yes':
                result = messagebox.askyesnocancel(
                    "Select Action",
                    "Do you want to Accept?",
                    icon='question'
                )
                if result is True:
                    tree.set(item, "Status", "Accepted")
                    update_status_in_db(item, True)
                elif result is False:
                    tree.set(item, "Status", "Rejected")
                    update_status_in_db(item, False)
                else:
                    pass  # User cancelled

        # Update status in the database
        def update_status_in_db(item, status):
            try:
                item_values = tree.item(item, 'values')
                combined_date_and_time = item_values[0]

                # Split the combined datetime into date and time
                appointment_date, appointment_time = combined_date_and_time.split()

                # Find the correct record in the database and update it
                appointments = database.child('Appointment').get()
                if appointments.each():
                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        if (appointment_data.get('appointment_date') == appointment_date and
                                appointment_data.get('appointment_time') == appointment_time):
                            database.child('Appointment').child(appointment.key()).update({'status': status})
                            break
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update status: {e}")

        # Bind mouse click to handle status change
        def on_tree_select(event):
            selected_item = tree.selection()
            if selected_item:
                if tree.identify_region(event.x, event.y) == "cell":
                    column = tree.identify_column(event.x)
                    if column == "#5":  # Ensure this corresponds to the Status column
                        change_status_dialog(selected_item[0])

        def fetch_and_insert_data():
            try:
                appointments = database.child('Appointment').get()

                if appointments.each():
                    appointment_rows = []

                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        status = "Pending" if not appointment_data.get('status', False) else "Accepted"

                        # Parse the date and time strings
                        appointment_date_str = appointment_data.get('appointment_date', 'N/A')
                        booking_time_str = appointment_data.get('appointment_time', 'N/A')

                        if appointment_date_str != 'N/A' and booking_time_str != 'N/A':
                            try:
                                # Parse the date
                                appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%d').date()

                                # Parse the time
                                time_parts = booking_time_str.split(':')
                                if len(time_parts) == 2:  # Handle HH:MM format
                                    hour = int(time_parts[0])
                                    minute = int(time_parts[1])
                                    appointment_time = datetime.combine(appointment_date, time(hour, minute))
                                elif len(time_parts) == 3:  # Handle HH:MM:SS format
                                    hour = int(time_parts[0])
                                    minute = int(time_parts[1])
                                    second = int(time_parts[2])
                                    appointment_time = datetime.combine(appointment_date, time(hour, minute, second))
                                else:
                                    raise ValueError(f"Invalid booking time format: {booking_time_str}")

                                # Store the appointment with its combined datetime
                                row = (
                                    appointment_time,
                                    appointment_data.get('user_name', 'N/A'),
                                    appointment_data.get('doctor_Name', 'N/A'),
                                    appointment_data.get('clinic_Name', 'N/A'),
                                    status,
                                )
                                appointment_rows.append(row)
                            except ValueError as e:
                                messagebox.showerror("Error", f"Failed to parse date or time: {e}")
                        else:
                            messagebox.showerror("Error", "Invalid appointment date or time.")

                    # Sort appointments by the combined datetime (first element of tuple 'row')
                    appointment_rows.sort(key=lambda x: x[0])

                    # Insert sorted rows into your GUI component (assuming 'tree' is defined elsewhere)
                    for row in appointment_rows:
                        combined_date_and_time = row[0].strftime("%Y-%m-%d %H:%M:%S")
                        tree.insert('', 'end', values=(combined_date_and_time, row[1], row[2], row[3], row[4]))

            except Exception as e:
                messagebox.showerror("Error at doctor manage request", f"Failed to fetch data: {e}")

        # Create a frame for patient records section
        request_record_frame = tk.Frame(self.frame, bg='white')
        request_record_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Add heading
        heading_label = tk.Label(request_record_frame, text=f"Welcome back {username}", font=("Arial", 20, "bold"),
                                 bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        heading2_label = tk.Label(request_record_frame, text="Patient Request", font=("Arial", 18, "bold"),
                                  bg='white')
        heading2_label.pack(anchor='w', padx=50, pady=10)

        # Table frame
        table_frame = tk.Frame(request_record_frame, padx=30, pady=30)
        table_frame.pack(fill=tk.BOTH, expand=True)

        # Style the Treeview
        style = ttk.Style()
        style.configure("Treeview",
                        background="#F5F5F5",
                        foreground="black",
                        rowheight=25,  # Set the row height here
                        fieldbackground="#F5F5F5",
                        font=('Arial', 12))
        style.configure("Treeview.Heading",
                        background="#0C7FDA",
                        font=('Arial', 12, 'bold'))
        style.map('Treeview',
                  background=[('selected', '#0C7FDA')])

        # Create table
        columns = ("Appointment Date&Time", "Patient Name", "Doctor Name", "Clinic Name", "Status")
        tree = ttk.Treeview(table_frame, columns=columns, show='headings', style="Treeview")
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Define column widths
        column_widths = [200, 120, 120, 180, 100]

        # Define headings and set column widths
        for col, width in zip(columns, column_widths):
            tree.heading(col, text=col)
            tree.column(col, width=width, anchor=tk.CENTER)

        # Scrollbar for the table
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Bind mouse click to handle status change
        tree.bind("<Button-1>", on_tree_select)

        # Insert data into the table
        fetch_and_insert_data()

'''

'''
import tkinter as tk
from tkinter import ttk, messagebox
from firebase_config import database
from admin.sidebar import Sidebar
from datetime import datetime, time


# after login, will show home page
class Admin_HomePage:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Function to show a dialog box for status change
        def change_status_dialog(item):
            result = messagebox.askquestion(
                "Change Status",
                "Do you want to accept or reject this request?",
                icon='question'
            )

            if result == 'yes':
                result = messagebox.askyesnocancel(
                    "Select Action",
                    "Do you want to Accept?",
                    icon='question'
                )
                if result is True:
                    tree.set(item, "Status", "Accepted")
                    update_status_in_db(item, True)
                elif result is False:
                    tree.set(item, "Status", "Rejected")
                    update_status_in_db(item, False)
                else:
                    pass  # User cancelled

        # Update status in the database
        def update_status_in_db(item, status):
            try:
                item_values = tree.item(item, 'values')
                combined_date_and_time = item_values[0]

                # Split the combined datetime into date and time
                appointment_date, appointment_time = combined_date_and_time.split()

                # Find the correct record in the database and update it
                appointments = database.child('Appointment').get()
                if appointments.each():
                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        if (appointment_data.get('appointment_date') == appointment_date and
                                appointment_data.get('appointment_time') == appointment_time):
                            database.child('Appointment').child(appointment.key()).update({'status': status})
                            break
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update status: {e}")

        # Bind mouse click to handle status change
        def on_tree_select(event):
            selected_item = tree.selection()
            if selected_item:
                if tree.identify_region(event.x, event.y) == "cell":
                    column = tree.identify_column(event.x)
                    if column == "#4":  # Ensure this corresponds to the Status column
                        change_status_dialog(selected_item[0])

        def fetch_and_insert_data():
            try:
                appointments = database.child('Appointment').get()

                if appointments.each():
                    appointment_rows = []

                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        status = "Pending" if not appointment_data.get('status', False) else "Accepted"

                        # Parse the date and time strings
                        appointment_date_str = appointment_data.get('appointment_date', 'N/A')
                        booking_time_str = appointment_data.get('appointment_time', 'N/A')

                        if appointment_date_str != 'N/A' and booking_time_str != 'N/A':
                            try:
                                # Parse the date
                                appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%d').date()

                                # Parse the time
                                time_parts = booking_time_str.split(':')
                                if len(time_parts) == 2:  # Handle HH:MM format
                                    hour = int(time_parts[0])
                                    minute = int(time_parts[1])
                                    appointment_time = datetime.combine(appointment_date, time(hour, minute))
                                elif len(time_parts) == 3:  # Handle HH:MM:SS format
                                    hour = int(time_parts[0])
                                    minute = int(time_parts[1])
                                    second = int(time_parts[2])
                                    appointment_time = datetime.combine(appointment_date, time(hour, minute, second))
                                else:
                                    raise ValueError(f"Invalid booking time format: {booking_time_str}")

                                # Store the appointment with its combined datetime
                                row = (
                                    appointment_time,
                                    appointment_data.get('user_name', 'N/A'),
                                    appointment_data.get('doctor_Name', 'N/A'),
                                    appointment_data.get('clinic_Name', 'N/A'),
                                    status,
                                )
                                appointment_rows.append(row)
                            except ValueError as e:
                                messagebox.showerror("Error", f"Failed to parse date or time: {e}")
                        else:
                            messagebox.showerror("Error", "Invalid appointment date or time.")

                    # Sort appointments by the combined datetime (first element of tuple 'row')
                    appointment_rows.sort(key=lambda x: x[0])

                    # Insert sorted rows into your GUI component (assuming 'tree' is defined elsewhere)
                    for row in appointment_rows:
                        combined_date_and_time = row[0].strftime("%Y-%m-%d %H:%M:%S")
                        tree.insert('', 'end', values=(combined_date_and_time, row[1], row[2], row[3], row[4]))

            except Exception as e:
                messagebox.showerror("Error at doctor manage request", f"Failed to fetch data: {e}")

        # Create a frame for patient records section
        request_record_frame = tk.Frame(self.frame, bg='white')
        request_record_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Add heading
        heading_label = tk.Label(request_record_frame, text=f"Welcome back {username}", font=("Arial", 20, "bold"),
                                 bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        heading2_label = tk.Label(request_record_frame, text="Patient Request", font=("Arial", 18, "bold"),
                                  bg='white')
        heading2_label.pack(anchor='w', padx=50, pady=10)

        # Table frame
        table_frame = tk.Frame(request_record_frame, padx=30, pady=30)
        table_frame.pack(fill=tk.BOTH, expand=True)

        # Style the Treeview
        style = ttk.Style()
        style.configure("Treeview",
                        background="#F5F5F5",
                        foreground="black",
                        rowheight=25,  # Set the row height here
                        fieldbackground="#F5F5F5",
                        font=('Arial', 12))
        style.configure("Treeview.Heading",
                        background="#0C7FDA",
                        font=('Arial', 12, 'bold'))
        style.map('Treeview',
                  background=[('selected', '#0C7FDA')])

        # Create table
        columns = ("Appointment Date&Time", "Patient Name", "Doctor Name", "Clinic Name", "Status")
        tree = ttk.Treeview(table_frame, columns=columns, show='headings', style="Treeview")
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Define column widths
        column_widths = [200, 120, 120, 180, 100]

        # Define headings and set column widths
        for col, width in zip(columns, column_widths):
            tree.heading(col, text=col)
            tree.column(col, width=width, anchor=tk.CENTER)

        # Scrollbar for the table
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Bind mouse click to handle status change
        tree.bind("<Button-1>", on_tree_select)

        # Insert data into the table
        fetch_and_insert_data()
'''

import tkinter as tk
from tkinter import ttk, messagebox
from firebase_config import database
from admin.sidebar import Sidebar
from datetime import datetime, time


# after login, will show home page
class Admin_HomePage:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Function to show a dialog box for status change
        def change_status_dialog(item):
            result = messagebox.askquestion(
                "Change Status",
                "Do you want to accept or reject this request?",
                icon='question'
            )

            if result == 'yes':
                result = messagebox.askyesnocancel(
                    "Select Action",
                    "Do you want to Accept?",
                    icon='question'
                )
                if result is True:
                    tree.set(item, "Status", "Accepted")
                    update_status_in_db(item, True)
                elif result is False:
                    tree.set(item, "Status", "Rejected")
                    update_status_in_db(item, False)
                else:
                    pass  # User cancelled

        # Update status in the database
        def update_status_in_db(item, status):
            try:
                item_values = tree.item(item, 'values')
                combined_date_and_time = item_values[0]

                # Split the combined datetime into date and time
                appointment_date, appointment_time = combined_date_and_time.split()

                # Find the correct record in the database and update it
                appointments = database.child('Appointment').get()
                if appointments.each():
                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        if (appointment_data.get('appointment_date') == appointment_date and
                                appointment_data.get('appointment_time') == appointment_time):
                            # Update the status in the database
                            database.child('Appointment').child(appointment.key()).update(
                                {'status': 'true' if status else 'false'})
                            break
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update status: {e}")

        # Bind mouse click to handle status change
        def on_tree_select(event):
            selected_item = tree.selection()
            if selected_item:
                if tree.identify_region(event.x, event.y) == "cell":
                    column = tree.identify_column(event.x)
                    if column == "#5":
                        change_status_dialog(selected_item[0])

        '''        
        def fetch_and_insert_data():
            try:
                appointments = database.child('Appointment').get()

                if appointments.each():

                    for appointment in appointments.each():
                        appointment_data = appointment.val()

                        appointment_date_str = appointment_data.get('appointment_date', 'N/A')
                        booking_time_str = appointment_data.get('appointment_time', 'N/A')

                        if appointment_date_str != 'N/A' and booking_time_str != 'N/A':
                            try:
                                # Parse the date
                                appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%d').date()

                                # Parse the time
                                time_parts = booking_time_str.split(':')
                                if len(time_parts) == 2:  # Handle HH:MM format
                                    hour = int(time_parts[0])
                                    minute = int(time_parts[1])
                                    appointment_time = datetime.combine(appointment_date, time(hour, minute))
                                elif len(time_parts) == 3:  # Handle HH:MM:SS format
                                    hour = int(time_parts[0])
                                    minute = int(time_parts[1])
                                    second = int(time_parts[2])
                                    appointment_time = datetime.combine(appointment_date, time(hour, minute, second))
                                else:
                                    raise ValueError(f"Invalid booking time format: {booking_time_str}")

                                if 'status' in appointment_data and appointment_data['status'] == 'true':
                                    status = "Accepted"
                                elif 'status' in appointment_data and appointment_data['status'] == 'false':
                                    status = "Rejected"
                                else:
                                    status = "Pending"
                                # Store the appointment with its combined datetime
                                row = (
                                    appointment_time,
                                    appointment_data.get('user_name', 'N/A'),
                                    appointment_data.get('doctor_Name', 'N/A'),
                                    appointment_data.get('clinic_Name', 'N/A'),
                                    status,
                                )
                                tree.insert('', 'end', values=row)
                            except ValueError as e:
                                messagebox.showerror("Error", f"Failed to parse date or time: {e}")
                        else:
                            messagebox.showerror("Error", "Invalid appointment date or time.")

            except Exception as e:
                messagebox.showerror("Error at doctor manage request", f"Failed to fetch data: {e}")
'''

        def fetch_and_insert_data():
            try:
                appointments = database.child('Appointment').get()

                if appointments.each():
                    for appointment in appointments.each():
                        appointment_data = appointment.val()
                        # status = "Pending" if not appointment_data.get('status', False) else "Accepted"
                        if 'status' in appointment_data and appointment_data['status'] == 'true':
                            status = "Accepted"
                        elif 'status' in appointment_data and appointment_data['status'] == 'false':
                            status = "Rejected"
                        else:
                            status = "Pending"
                        # Combine date and time into a single string
                        date_time_str = f"{appointment_data.get('appointment_date', 'N/A')} {appointment_data.get('appointment_time', 'N/A')}"

                        row = (
                            date_time_str,
                            appointment_data.get('user_name', 'N/A'),  # Add patient name to the row
                            appointment_data.get('doctor_Name', 'N/A'),
                            appointment_data.get('clinic_Name', 'N/A'),
                            status,
                        )
                        tree.insert('', 'end', values=row)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to fetch data: {e}")

        # Create a frame for patient records section
        request_record_frame = tk.Frame(self.frame, bg='white')
        request_record_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Add heading
        heading_label = tk.Label(request_record_frame, text=f"Welcome back {username}", font=("Arial", 20, "bold"),
                                 bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        heading2_label = tk.Label(request_record_frame, text="Patient Request", font=("Arial", 18, "bold"),
                                  bg='white')
        heading2_label.pack(anchor='w', padx=50, pady=10)

        # Table frame
        table_frame = tk.Frame(request_record_frame, padx=30, pady=30)
        table_frame.pack(fill=tk.BOTH, expand=True)

        # Style the Treeview
        style = ttk.Style()
        style.configure("Treeview",
                        background="#F5F5F5",
                        foreground="black",
                        rowheight=25,  # Set the row height here
                        fieldbackground="#F5F5F5",
                        font=('Arial', 12))
        style.configure("Treeview.Heading",
                        background="#0C7FDA",
                        font=('Arial', 12, 'bold'))
        style.map('Treeview',
                  background=[('selected', '#0C7FDA')])

        # Create table
        columns = ("Appointment Date&Time", "Patient Name", "Doctor Name", "Clinic Name", "Status")
        tree = ttk.Treeview(table_frame, columns=columns, show='headings', style="Treeview")
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Define column widths
        column_widths = [200, 120, 120, 180, 100]

        # Define headings and set column widths
        for col, width in zip(columns, column_widths):
            tree.heading(col, text=col)
            tree.column(col, width=width, anchor=tk.CENTER)

        # Scrollbar for the table
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Bind mouse click to handle status change
        tree.bind("<Button-1>", on_tree_select)

        # Insert data into the table
        fetch_and_insert_data()

# Usage example
# app = YourAppClass()  # Initialize your application class
# Admin_HomePage(app, "admin_username")
