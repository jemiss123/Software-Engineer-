import datetime
from tkcalendar import Calendar
from firebase_config import database
import tkinter as tk
from admin.sidebar import Sidebar


# after clicking doctor details, will list out all the related details
class ShowDetails:
    def __init__(self, app, dc_name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.dc_name = dc_name or self.app.get_shared_data("dc_name")

        def on_enter(event):
            event.widget.config(bg="#8EC9F9")

        def on_leave(event):
            event.widget.config(bg="white")

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        detail_frame = tk.Frame(self.frame)
        detail_frame.pack(fill="both", expand=True)

        # Create two frames: one for labels and one for buttons
        labels_frame = tk.Frame(detail_frame)
        labels_frame.grid(row=0, column=0, padx=20, pady=20)

        buttons_frame = tk.Frame(detail_frame)
        buttons_frame.grid(row=0, column=1, padx=20, pady=20)

        # Retrieve doctor details from the database
        doctor_db = database.child('Doctor').get().val()

        doctor = None
        for doc_id, doc_data in doctor_db.items():
            if doc_data.get('dc_name') == self.dc_name:
                doctor = doc_data
                doctor['key'] = doc_id  # Capture the doctor's key for later use
                break

        if doctor:
            # Display doctor details
            doctor_name = doctor['dc_name']
            dc_name_label = tk.Label(labels_frame, text=f"Dr. {doctor_name}", font=("Work Sans", 20, "bold"))
            dc_name_label.pack(anchor='w', pady=5)

            dc_specialty_label = tk.Label(labels_frame, text=f"Speciality: {doctor['dc_specialty']}",
                                          font=("Poppins", 12, "bold"))
            dc_specialty_label.pack(anchor='w', pady=5)

            dc_email_label = tk.Label(labels_frame, text=f"Email: {doctor['dc_email']}", font=("Work Sans", 12, "bold"))
            dc_email_label.pack(anchor='w', pady=5)

            dc_phone_label = tk.Label(labels_frame, text=f"Phone: {doctor['dc_phone']}", font=("Work Sans", 12, "bold"))
            dc_phone_label.pack(anchor='w', pady=5)

            work_clinic_label = tk.Label(labels_frame, text=f"Clinic: {doctor['work_clinic']}",
                                         font=("Work Sans", 12, "bold"))
            work_clinic_label.pack(anchor='w', pady=5)

            def show_calendar():
                calendar_frame = tk.Frame(buttons_frame)
                calendar_frame.pack(padx=20, pady=20)

                calendar = Calendar(calendar_frame,
                                    selectmode='none',
                                    year=2024, month=6,
                                    font=('Arial', 16),
                                    background='white',
                                    foreground='black',
                                    headersbackground='white',
                                    headersforeground='black',
                                    selectbackground='blue',
                                    selectforeground='white')
                calendar.pack(padx=20, pady=20)

                # Set the tag color to red for busy dates
                calendar.tag_config('busy', background='red', foreground='white')

                # Fetch and highlight appointment dates
                appointment_dates = self.fetch_appointment_dates(dc_name)
                self.busy_dates = []
                for date in appointment_dates:
                    try:
                        year, month, day = map(int, date.split('-'))
                        # Highlight the date on the calendar
                        calendar.calevent_create(datetime.date(year, month, day), 'Appointment', 'busy')
                        self.busy_dates.append(datetime.date(year, month, day))
                    except ValueError as e:
                        print(f"Error parsing date {date}: {e}")

            show_calendar()

            def assign_doctor_share():
                self.app.set_shared_data("dc_name", doctor['dc_name'])
                self.app.show_page("admin_assign_doctor")

            assign_button = tk.Button(buttons_frame, text="Assign Doctor", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                                      activebackground='white', command=assign_doctor_share)
            assign_button.pack(pady=10)

            # Add a button to go back to the doctor list
            back_button = tk.Button(buttons_frame, text="Back", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                                    activebackground='white',
                                    command=lambda: self.app.show_page("view_doctor_from_admin"))
            back_button.pack(pady=10)

    def fetch_user_details(username):
        try:
            user_ref = database.child('User').child(username)
            user_details = user_ref.get()
            if user_details:
                return user_details.val()
            else:
                return None
        except Exception as e:
            print(f"Error fetching user details: {e}")
            return None

    def fetch_appointment_dates(self, doctor_name):
        try:
            appointments = database.child("Calendar").child(doctor_name).child("appointments").get()
            appointment_dates = []
            if appointments:
                for appointment in appointments.each():
                    appointment_info = appointment.val()
                    appointment_dates.append(appointment_info['date_appointed'])
            return appointment_dates
        except Exception as e:
            print(f"Error fetching appointment dates: {e}")  # Debug statement
            return []

    def show_doctor_list(self, detail_frame):
        # Destroy the detail frame
        detail_frame.destroy()
        # Clear any remaining content in the root
        for widget in self.frame.winfo_children():
            widget.destroy()
