from firebase_config import database
from tkinter import *
import tkinter as tk
from tkinter import messagebox, PhotoImage
from admin.sidebar import Sidebar
from PIL import Image, ImageTk


class ShowDoctorAfterViewing:
    def __init__(self, app, name):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.clinic_name = name
        self.image_references = []

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)  # Replace Sidebar with your Sidebar class
        self.sidebar.pack(side='left', fill='y')

        # Create a frame to hold the heading label and the button
        heading_frame = Frame(self.frame, bg='white')
        heading_frame.pack(anchor='w', padx=50, pady=30, fill=tk.X)

        # Heading label
        heading_label = tk.Label(heading_frame, text=f"Doctors at {self.clinic_name}", font=("Arial", 18, "bold"),
                                 bg='white')
        heading_label.pack(side=tk.LEFT)

        def add_new_doctor():
            self.app.set_shared_data("name", self.clinic_name)
            self.app.show_page("add_doctor")

        # Add Doctor button
        add_doctor_button_image_path = "pictures/admin/Add Doctor.png"
        add_doctor_button_img = PhotoImage(file=add_doctor_button_image_path)
        add_doctor_button = Button(heading_frame, image=add_doctor_button_img, borderwidth=0, bg='white',
                                   activebackground='white', command=add_new_doctor)
        add_doctor_button.image = add_doctor_button_img
        add_doctor_button.pack(side=tk.RIGHT, padx=0)

        self.canvas = tk.Canvas(self.frame, bg='white')
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))

        self.doctor_container = tk.Frame(self.canvas, bg='white')
        self.canvas.create_window((0, 0), window=self.doctor_container, anchor='nw')

        self.canvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

        self.display_doctors()

    def on_mouse_wheel(self, event):
        self.canvas.yview_scroll(-1 * int((event.delta / 120)), "units")

    def fetch_doctor_data(self):
        try:
            doctors = database.child('Doctor').order_by_child('work_clinic').equal_to(self.clinic_name).get()
            if doctors.each():
                doctor_list = []
                for doctor in doctors.each():
                    doctor_info = doctor.val()
                    doctor_info['key'] = doctor.key()  # Add the key to the doctor info
                    doctor_list.append(doctor_info)
                return doctor_list
            else:
                return []
        except Exception as e:
            print(f"Error fetching data: {e}")  # Debug statement
            return []

        # This function is on calendar, take the doctor_name and check in the database for this doctor appoitment date

    def fetch_appointment_dates(self, doctor_name):
        try:
            appointments = database.child("Calendar").child(doctor_name).child("appointments").get()
            appointment_dates = []
            for appointment in appointments.each():
                appointment_info = appointment.val()
                appointment_dates.append(appointment_info['date_appointed'])
            return appointment_dates
        except Exception as e:
            print(f"Error fetching appointment dates: {e}")  # Debug statement
            return []

    def display_doctors(self):
        doctors = self.fetch_doctor_data()
        for idx, doctor in enumerate(doctors):
            self.create_doctor_rectangles(doctor, idx)

    # Asking for deletion of that doctors in that clinic
    def confirm_delete(self, doctor):
        confirm = messagebox.askyesno("Confirm Deletion",
                                      f"Do you want to delete Dr. {doctor['dc_name']} from the database?")
        if confirm:
            try:
                # Perform deletion from Firebase using the key
                database.child('Doctor').child(doctor['key']).remove()
                messagebox.showinfo("Success", f"Dr. {doctor['dc_name']} deleted successfully!")
                # Optionally update UI or refresh doctor list
                self.display_doctors()  # Refresh the doctor list after deletion
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete Dr. {doctor['dc_name']}: {e}")

    # Display out all the doctors have in that clinic
    def create_doctor_rectangles(self, doctor, idx):

        Rectangle_for_doctor_path = "pictures/admin/Doctor.png"
        Rectangle_for_doctor_img = ImageTk.PhotoImage(
            Image.open(Rectangle_for_doctor_path).resize((310, 170), Image.Resampling.LANCZOS))
        self.image_references.append(Rectangle_for_doctor_img)

        row = idx // 2
        col = idx % 2

        doctor_frame = tk.Frame(self.doctor_container, bg='white')
        doctor_frame.grid(row=row, column=col, padx=20, pady=5, sticky='w')

        canvas = tk.Canvas(doctor_frame, width=310, height=250, bg='white', bd=0, highlightthickness=0)
        canvas.pack(padx=(0, 10) if col == 0 else (10, 0))  # Add spacing between canvas1 and canvas2
        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_doctor_img)

        doctor_name = doctor.get("dc_name", "N/A")
        name_label = tk.Label(canvas, text=f"Dr. {doctor_name}", font=("Work Sans", 15, "bold"), bg='#D9D9D9')
        canvas.create_window(20, 2, anchor='nw', window=name_label)

        specialty_label = tk.Label(canvas, text=f"Speciality: {doctor.get('dc_specialty', 'N/A')}",
                                   font=("Poppins", 12), bg='#D9D9D9')
        canvas.create_window(20, 35, anchor='nw', window=specialty_label)

        email_label = tk.Label(canvas, text=f"Doctor Email: {doctor.get('dc_email', 'N/A')}",
                               font=("Work Sans", 12, "bold"), bg='#E3E2FD')
        canvas.create_window(20, 65, anchor='nw', window=email_label)

        PhoneNum_label = tk.Label(canvas, text=f"Doctor Contact: {doctor.get('dc_phone', 'N/A')} ",
                                  font=("Work Sans", 12, "bold"), bg='#E3E2FD')
        canvas.create_window(20, 95, anchor='nw', window=PhoneNum_label)

        delete_label = Button(doctor_frame, text=f" Delete ", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                              activebackground='white', command=lambda d=doctor: self.confirm_delete(d))
        delete_label.place(x=20, y=130)

        def show_details():
            self.app.set_shared_data("dc_name", doctor_name)
            self.app.show_page("show_details")

        detail_label = Button(doctor_frame, text=f" Detail ", font=("Work Sans", 12, "bold"), bg='#E3E2FD',
                              activebackground='white', command=show_details)
        detail_label.place(x=240, y=130)

        doctor_frame.image = Rectangle_for_doctor_img
