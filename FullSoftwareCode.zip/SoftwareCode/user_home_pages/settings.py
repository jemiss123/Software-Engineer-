import tkinter as tk
from tkinter import *
from tkinter import messagebox
from firebase_config import database
from user_home_pages.sidebar import Sidebar
import re


class Settings:
    def __init__(self, app, username):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.username = username or self.app.get_shared_data("username")

        def on_enter(event):
            event.widget.config(bg="#8EC9F9")

        def on_leave(event):
            event.widget.config(bg="white")

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

        # Settings Page
        settings_frame = Frame(self.frame, bg='white')
        settings_frame.pack(fill='both', expand=True, padx=10)  # Ensure the frame is packed

        settings_label = Label(settings_frame, text="User Profile", font=("Poppins", 20, "bold"), bg="white")
        settings_label.place(x=70, y=50)

        user_display_name_label = Label(settings_frame, text="Name", font=("Poppins", 14, "bold"), bg="white")
        user_display_name_label.place(x=70, y=120)
        self.user_display_name_label = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_display_name_label.place(x=250, y=120, width=300)

        user_contact_label = Label(settings_frame, text="Phone Number", font=("Poppins", 14, "bold"), bg="white")
        user_contact_label.place(x=70, y=160)
        self.user_contact_entry = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_contact_entry.place(x=250, y=160, width=300)

        user_email_label = Label(settings_frame, text="Email", font=("Poppins", 14, "bold"), bg="white")
        user_email_label.place(x=70, y=200)
        self.user_email_entry = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_email_entry.place(x=250, y=200, width=300)

        user_height_label = Label(settings_frame, text="Height (in CM)", font=("Poppins", 14, "bold"), bg="white")
        user_height_label.place(x=70, y=240)
        self.user_height_label = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_height_label.place(x=250, y=240, width=300)

        user_weight_label = Label(settings_frame, text="Weight (in KG)", font=("Poppins", 14, "bold"), bg="white")
        user_weight_label.place(x=70, y=280)
        self.user_weight_label = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_weight_label.place(x=250, y=280, width=300)

        user_age_label = Label(settings_frame, text="Age", font=("Poppins", 14, "bold"), bg="white")
        user_age_label.place(x=70, y=320)
        self.user_age_label = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_age_label.place(x=250, y=320, width=300)

        user_allergy_label = Label(settings_frame, text="Allergy", font=("Poppins", 14, "bold"), bg="white")
        user_allergy_label.place(x=70, y=360)
        self.user_allergy_label = Entry(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12))
        self.user_allergy_label.place(x=250, y=360, width=300)

        user_address_label = Label(settings_frame, text="Address", font=("Poppins", 14, "bold"), bg="white")
        user_address_label.place(x=70, y=400)
        self.user_address_entry = Text(settings_frame, borderwidth=1, bg='#E5E5E5', font=('Montserrat', 12), wrap=WORD)
        self.user_address_entry.place(x=250, y=400, width=300, height=100)

        # Function to validate email address
        def is_valid_email(email):
            return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))

        def is_valid_numeric(input_str):
            try:
                float_value = float(input_str)
                return True
            except ValueError:
                return False

        def validate_save_button():
            c1 = self.user_display_name_label.get()
            c2 = self.user_contact_entry.get()
            c3 = self.user_email_entry.get()
            c4 = self.user_height_label.get()
            c5 = self.user_weight_label.get()
            c6 = self.user_age_label.get()
            c7 = self.user_allergy_label.get()
            c8 = self.user_address_entry.get("1.0", "end-1c") if self.user_address_entry else None

            # Validate input fields
            if c2 != "" and not (c2.strip().isdigit() and 10 <= len(c2.strip()) <= 11):
                messagebox.showerror("Error", "Invalid contact number format")
                return
            elif c3 != "" and not is_valid_email(c3):
                messagebox.showerror("Error", "Invalid email address format")
                return
            elif c4 != "" and not is_valid_numeric(c4):
                messagebox.showerror("Error", "Invalid height format")
                return
            elif c5 != "" and not is_valid_numeric(c5):
                messagebox.showerror("Error", "Invalid weight format")
                return
            elif c6 != "" and not is_valid_numeric(c6):
                messagebox.showerror("Error", "Invalid age format")
                return

            # Retrieve current gender and password from database
            gender = database.child('User').child(username).child('gender').get().val()
            password = database.child('User').child(username).child('password').get().val()

            # Prepare data to update
            user_data = {
                "username": username,
                "gender": gender,
                "password": password
            }

            # Add non-empty fields to user_data
            if c1:
                user_data["user_display_name"] = c1
            if c2:
                user_data["phone"] = c2
            if c3:
                user_data["email"] = c3
            if c4:
                user_data["height_CM"] = c4
            if c5:
                user_data["weight_KG"] = c5
            if c6:
                user_data["age"] = c6
            if c7:
                user_data["allergy"] = c7
            if c8:
                user_data["address"] = c8

            # Update the database
            database.child("User").child(username).update(user_data)

            messagebox.showinfo("Success", "Updated changes made")
            self.app.show_page("settings")
            self.clear_entry_fields()  # Clear fields after successful update

        save_button_image_path = "pictures/Settings/Save button.png"
        save_button_img = tk.PhotoImage(file=save_button_image_path)
        save_button_label = tk.Label(settings_frame, image=save_button_img, bg='white')
        save_button_label.image = save_button_img

        cancel_button_image_path = "pictures/Settings/Cancel button.png"
        cancel_button_img = tk.PhotoImage(file=cancel_button_image_path)
        cancel_button_label = tk.Label(settings_frame, image=cancel_button_img, bg='white')
        cancel_button_label.image = cancel_button_img

        cancel_button = Button(settings_frame, image=cancel_button_img, command=lambda: self.app.show_page("home"),
                               borderwidth=0, bg='white', activebackground='white')
        cancel_button.place(x=350, y=520)

        save_button = Button(settings_frame, image=save_button_img, command=validate_save_button,
                             borderwidth=0, bg='white', activebackground='white')
        save_button.place(x=450, y=520)

    def clear_entry_fields(self):
        # Clear entry fields
        self.user_display_name_label.delete(0, 'end')
        self.user_contact_entry.delete(0, 'end')
        self.user_contact_entry.delete(0, 'end')
        self.user_height_label.delete(0, 'end')
        self.user_weight_label.delete(0, 'end')
        self.user_age_label.delete(0, 'end')
        self.user_allergy_label.delete(0, 'end')
        self.user_address_entry.delete('1.0', 'end')
