import tkinter as tk
from tkinter import *
from user_home_pages.sidebar import Sidebar
from firebase_config import database
from tkinter import messagebox
from PIL import Image, ImageTk


class ViewDoctors:
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(self.app.root, bg='white')
        self.frame.pack(fill='both', expand=True)
        self.name = None
        self.image_references = []  # To hold image references
        self.view_doctor()

        # Add the sidebar
        self.sidebar = Sidebar(self.frame, self.app)
        self.sidebar.pack(side='left', fill='y')

    def view_doctor(self):
        self.view_doctor_frame = tk.Frame(self.frame, bg='white')
        self.view_doctor_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=50)

        heading_label = tk.Label(self.view_doctor_frame, text="Doctor Available", font=("Arial", 18, "bold"),
                                 bg='white')
        heading_label.pack(anchor='w', padx=50, pady=30)

        self.canvas = tk.Canvas(self.view_doctor_frame, bg='white')
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(self.view_doctor_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))

        self.view_doctor_container = tk.Frame(self.canvas, bg='white')
        self.canvas.create_window((0, 0), window=self.view_doctor_container, anchor='nw')

        # Update the bind event to handle different operating systems
        self.canvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

        self.display_doctors()

    def on_mouse_wheel(self, event):
        if event.delta > 0:
            self.canvas.yview_scroll(-1, "units")
        elif event.delta < 0:
            self.canvas.yview_scroll(1, "units")

    def fetch_doctor_data(self):
        try:
            doctors = database.child('Doctor').get()
            if doctors.each():
                return [doctor.val() for doctor in doctors.each()]
            else:
                return []
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch data: {e}")
            return []

    def create_view_doctor_rectangle(self, doctor, idx):
        row = idx // 2
        col = idx % 2

        doctor_frame = tk.Frame(self.view_doctor_container, bg='white')
        doctor_frame.grid(row=row, column=col, padx=5, pady=10, sticky='w')

        # Load the image for the doctor's frame
        Rectangle_for_clinic_path ="pictures/admin/Doctor.png"
        Rectangle_for_clinic_img = ImageTk.PhotoImage(
            Image.open(Rectangle_for_clinic_path).resize((310, 250), Image.LANCZOS))
        self.image_references.append(Rectangle_for_clinic_img)

        # Create canvas for the image
        canvas = tk.Canvas(doctor_frame, width=310, height=250, bg='white', bd=0, highlightthickness=0)
        canvas.pack(padx=(0, 10) if col == 0 else (10, 0))  # Add spacing between canvas1 and canvas2
        canvas.create_image(0, 0, anchor='nw', image=Rectangle_for_clinic_img)

        # Doctor details labels on the canvas
        doctor_name = doctor.get("dc_name", "N/A")
        name_label = tk.Label(canvas, text=f"Dr. {doctor_name}", font=("Work Sans", 16, "bold"), bg='#D9D9D9')
        canvas.create_window(20, 10, anchor='nw', window=name_label)

        specialty_label = tk.Label(canvas, text=f"Speciality: {doctor.get('dc_specialty', 'N/A')}",
                                   font=("Arial", 12), bg='#D9D9D9')
        canvas.create_window(20, 40, anchor='nw', window=specialty_label)

        email_label = tk.Label(canvas, text=f"Email: {doctor.get('dc_email', 'N/A')}", font=("Arial", 12),
                               bg='#D9D9D9')
        canvas.create_window(20, 64, anchor='nw', window=email_label)

        clinic_name = doctor.get('work_clinic', 'N/A')

        # Description text widget on the canvas
        desc_text = tk.Text(canvas, width=30, height=5, font=("Arial", 13), bg='#E6E6FA', wrap=tk.WORD, bd=0)
        desc_text.insert(tk.END, f"Description: \n{doctor.get('work_desc', 'N/A')}")
        desc_text.config(state=tk.DISABLED)  # Make the text widget read-only
        canvas.create_window(20, 100, anchor='nw', window=desc_text)

        # Bind click event to open doctor's booking page
        def show_clinic_page(event):
            self.app.set_shared_data("dc_name", doctor_name)
            self.app.set_shared_data("name", clinic_name)
            self.app.show_page("booking")

        name_label.bind('<Button-1>', show_clinic_page)

    def display_doctors(self):
        doctors = self.fetch_doctor_data()
        for idx, doctor in enumerate(doctors):
            self.create_view_doctor_rectangle(doctor, idx)
