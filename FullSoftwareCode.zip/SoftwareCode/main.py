import tkinter as tk
# User login page
from user_handle_login_pages.login import LoginPage
from user_handle_login_pages.register import RegisterPage
from user_handle_login_pages.forgotPassword import ForgotPasswordPage
from user_handle_login_pages.resetPassword import ResetPasswordPage

# User home page
from user_home_pages.home import HomePage
from user_home_pages.appointment import Appointment
from user_home_pages.search_clinic import SearchClinic
from user_home_pages.booking import Booking
from user_home_pages.settings import Settings
from user_home_pages.view_doctor import ViewDoctors
from user_home_pages.view_clinic import ViewClinic
from user_home_pages.showPrescriptions import UserGeneratePrescriptions

# Admin home page
from admin.admin_add_doctor import AddDoctor
from admin.admin_assign_doctor import AssignDoctorAppointment
from admin.admin_home_page import Admin_HomePage
from admin.admin_show_clinic import ShowClinic_doctor
from admin.admin_show_doctor_details import ShowDetails
from admin.admin_view_doctor_in_clinic import ShowDoctorAfterViewing

# Doctor home page
from doctor.doctor_homepage import DoctorHomePage
from doctor.doctor_generate_prescriptions import GeneratePrescriptions
from doctor.doctor_view_patient_record import DoctorViewPatientRecord

class App:
    def __init__(self, root):
        self.shared_data = {}  # Initialize shared_data as a dictionary
        self.root = root
        self.root.title("Call Dr.")
        self.root.geometry("1050x594")
        self.root.configure(bg="white")
        self.root.resizable(False, False)
        self.pages = {}

        # User Login Pages stuff
        self.pages["login"] = LoginPage(self)
        self.pages["register"] = RegisterPage(self)
        self.pages["forgotpassword"] = ForgotPasswordPage(self)
        self.pages["resetpassword"] = ResetPasswordPage(self)

        # User Home Pages stuff
        self.pages["home"] = HomePage(self, username=None)
        self.pages["appointment"] = Appointment(self, username=None)
        self.pages["search_clinic"] = SearchClinic(self)
        self.pages["view_clinic"] = ViewClinic(self, name=None)
        self.pages["booking"] = Booking(self, username=None, name=None, dc_name=None)
        self.pages["settings"] = Settings(self, username=None)
        self.pages["view_doctor_from_user"] = ViewDoctors(self)
        self.pages["user_view_prescriptions"] = UserGeneratePrescriptions(self, username=None, name=None, dc_name=None)

        # Admin Home Pages stuff
        self.pages["homepage"] = Admin_HomePage(self, username=None)
        self.pages["admin_show_clinic"] = ShowClinic_doctor(self)
        self.pages["view_doctor_from_admin"] = ShowDoctorAfterViewing(self, name=None)
        self.pages["show_details"] = ShowDetails(self, dc_name=None)
        self.pages["admin_assign_doctor"] = AssignDoctorAppointment(self, dc_name=None)
        self.pages["add_doctor"] = AddDoctor(self, name=None)

        # Doctor Home Pages stuff
        self.pages["doctor_homepage"] = DoctorHomePage(self, dc_name=None)
        self.pages["generate_prescriptions"] = GeneratePrescriptions(self, dc_name=None)
        self.pages["view_patient_records"] = DoctorViewPatientRecord(self, dc_name=None)


        self.show_page("login")

    def show_page(self, page_name, username=None, name=None):
        for page in self.pages.values():
            page.frame.pack_forget()

        if username:
            self.set_shared_data("username", username)
        if name:
            self.set_shared_data("name", name)

        # User, Doctor, Admin
        if page_name == "home":
            self.pages["home"] = HomePage(self, username=self.get_shared_data("username"))

        # User part
        if page_name == "appointment":
            self.pages["appointment"] = Appointment(self, username=self.get_shared_data("username"))
        if page_name == "view_clinic":
            self.pages["view_clinic"] = ViewClinic(self, name=self.get_shared_data("name"))
        if page_name == "booking":
            self.pages["booking"] = Booking(self, username=self.get_shared_data("username"),
                                            name=self.get_shared_data("name"),
                                            dc_name=self.get_shared_data("dc_Name"))
        if page_name == "settings":
            self.pages["settings"] = Settings(self, username=self.get_shared_data("username"))
        if page_name == "user_view_prescriptions":
            self.pages["user_view_prescriptions"] = UserGeneratePrescriptions(self,
                                                                              username=self.get_shared_data("username"),
                                                                              name=self.get_shared_data("name"),
                                                                              dc_name=self.get_shared_data("dc_Name"))

        # Admin part
        if page_name == "homepage":
            self.pages["homepage"] = Admin_HomePage(self, username=self.get_shared_data("username"))
        if page_name == "admin_assign_doctor":
            self.pages["admin_assign_doctor"] = AssignDoctorAppointment(self, dc_name=self.get_shared_data("dc_name"))
        if page_name == "add_doctor":
            self.pages["add_doctor"] = AddDoctor(self, name=self.get_shared_data("name"))
        if page_name == "view_doctor_from_admin":
            self.pages["view_doctor_from_admin"] = ShowDoctorAfterViewing(self, name=self.get_shared_data("name"))
        if page_name == "show_details":
            self.pages["show_details"] = ShowDetails(self, dc_name=self.get_shared_data("dc_name"))

        # Doctor part
        if page_name == "doctor_homepage":
            self.pages["doctor_homepage"] = DoctorHomePage(self, dc_name=self.get_shared_data("dc_name"))
        if page_name == "generate_prescriptions":
            self.pages["generate_prescriptions"] = GeneratePrescriptions(self, dc_name=self.get_shared_data("dc_name"))
        if page_name == "view_patient_records":
            self.pages["view_patient_records"] = DoctorViewPatientRecord(self, dc_name=self.get_shared_data("dc_name"))

        self.pages[page_name].frame.pack(fill='both', expand=True)

    def add_page(self, page_name, frame):
        self.pages[page_name] = frame

    def set_shared_data(self, key, value):
        self.shared_data[key] = value

    def get_shared_data(self, key):
        return self.shared_data.get(key, None)


def main():
    root = tk.Tk()
    app = App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
